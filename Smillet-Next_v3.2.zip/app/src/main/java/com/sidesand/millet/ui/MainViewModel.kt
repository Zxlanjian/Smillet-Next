package com.sidesand.millet.ui

import android.app.Application
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.PowerManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sidesand.millet.data.InstalledAppItem
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.data.RunningAppItem
import com.sidesand.millet.ipc.BinderBridge
import com.sidesand.millet.ipc.ISystemCallback
import com.sidesand.millet.ipc.SystemInterface
import com.sidesand.millet.util.ProcessScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val prefsManager = PrefsManager.fromContext(application)

    private val _config = MutableStateFlow(prefsManager.snapshot())
    val config: StateFlow<MilletConfigSnapshot> = _config.asStateFlow()

    private val _isLspActivated = MutableStateFlow(PrefsManager.isModuleActivatedInLsp(application))
    val isLspActivated: StateFlow<Boolean> = _isLspActivated.asStateFlow()

    private val _isRootGranted = MutableStateFlow(true)
    val isRootGranted: StateFlow<Boolean> = _isRootGranted.asStateFlow()

    private val _isSystemActive = MutableStateFlow(false)
    val isSystemActive: StateFlow<Boolean> = _isSystemActive.asStateFlow()

    private val _isPowerKeeperActive = MutableStateFlow(false)
    val isPowerKeeperActive: StateFlow<Boolean> = _isPowerKeeperActive.asStateFlow()

    private val _runningApps = MutableStateFlow<List<RunningAppItem>>(emptyList())
    val runningApps: StateFlow<List<RunningAppItem>> = _runningApps.asStateFlow()

    private val _isScanningRunning = MutableStateFlow(false)
    val isScanningRunning: StateFlow<Boolean> = _isScanningRunning.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppItem>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppItem>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _diagnosticDialogText = MutableStateFlow<Pair<String, String>?>(null)
    val diagnosticDialogText: StateFlow<Pair<String, String>?> = _diagnosticDialogText.asStateFlow()

    @Volatile
    private var systemInterface: SystemInterface? = null

    private val uiCallback = object : ISystemCallback.Stub() {
        override fun onConfigChanged(key: String) {}
        override fun requestCheckFreezeReason(packageName: String) {}
        override fun onFreezeReasonResult(packageName: String, reason: String) {
            _diagnosticDialogText.value = packageName to reason
        }
    }

    init {
        connectAndRefresh(includeSystem = false)
        loadInstalledApps()
    }

    fun connectAndRefresh(includeSystem: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            _isScanningRunning.value = true
            val app = getApplication<Application>()
            val lspCheck = PrefsManager.isModuleActivatedInLsp(app)
            val rootOk = ProcessScanner.checkRootAccess()
            _isRootGranted.value = rootOk

            val binder = BinderBridge.fetchSystemInterface(app)
            systemInterface = binder
            val sysOk = runCatching { binder?.isSystemHookActive() == true }.getOrDefault(false)
            val pkOk = runCatching { binder?.isPowerKeeperActive() == true }.getOrDefault(false)
            if (sysOk && binder != null) {
                runCatching { binder.registerCallback(uiCallback, "HomePage") }
                runCatching { binder.pushConfigJson(prefsManager.exportBackupJson()) }
            }
            _isLspActivated.value = lspCheck || sysOk
            _isSystemActive.value = sysOk
            _isPowerKeeperActive.value = pkOk

            val res = ProcessScanner.scanRunningApps(
                context = app,
                includeSystemApps = includeSystem,
                systemInterface = binder
            )
            res.onSuccess { _runningApps.value = it }
            _isScanningRunning.value = false
        }
    }

    fun refreshRunningApps(includeSystem: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            _isScanningRunning.value = true
            if (systemInterface == null) {
                systemInterface = BinderBridge.fetchSystemInterface(getApplication())
            }
            val res = ProcessScanner.scanRunningApps(
                context = getApplication(),
                includeSystemApps = includeSystem,
                systemInterface = systemInterface
            )
            res.onSuccess { _runningApps.value = it }
            _isScanningRunning.value = false
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingApps.value = true
            val context = getApplication<Application>()
            val pm = context.packageManager
            val powerManager = context.getSystemService(PowerManager::class.java)
            val list = pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
                .map { info ->
                    val isSys = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val ignored = powerManager?.isIgnoringBatteryOptimizations(info.packageName) == true
                    InstalledAppItem(
                        uid = info.uid,
                        packageName = info.packageName,
                        appName = pm.getApplicationLabel(info).toString().trim(),
                        icon = runCatching { pm.getApplicationIcon(info) }.getOrNull(),
                        isSystemApp = isSys,
                        isBatteryOptIgnored = ignored
                    )
                }
                .sortedBy { it.appName.lowercase() }
            _installedApps.value = list
            _isLoadingApps.value = false
        }
    }

    fun updateBoolean(key: String, value: Boolean) {
        prefsManager.putBoolean(key, value)
        _config.value = prefsManager.snapshot()
        pushConfigToSystem(key)
    }

    fun updateString(key: String, value: String) {
        prefsManager.putString(key, value)
        _config.value = prefsManager.snapshot()
        pushConfigToSystem(key)
    }

    fun updateAppSet(key: String, packageName: String, enabled: Boolean) {
        prefsManager.updateAppSet(key, packageName, enabled)
        _config.value = prefsManager.snapshot()
        pushConfigToSystem(key)
    }

    fun setWhiteListApp(packageName: String, enabled: Boolean) {
        prefsManager.setWhiteListApp(packageName, enabled)
        _config.value = prefsManager.snapshot()
        pushConfigToSystem("whiteAppSet")
    }

    fun setBatteryOptimization(packageName: String, ignoreBatteryOpt: Boolean) {
        prefsManager.setBatteryOptimization(packageName, ignoreBatteryOpt)
        _config.value = prefsManager.snapshot()
        _installedApps.value = _installedApps.value.map { item ->
            if (item.packageName == packageName) {
                item.copy(isBatteryOptIgnored = ignoreBatteryOpt)
            } else {
                item
            }
        }
        val json = prefsManager.exportBackupJson()
        viewModelScope.launch(Dispatchers.IO) {
            val binder = systemInterface ?: BinderBridge.fetchSystemInterface(getApplication()).also {
                systemInterface = it
            }
            runCatching {
                binder?.pushConfigJson(json)
            }
            val context = getApplication<Application>()
            val powerManager = context.getSystemService(PowerManager::class.java)
            val actualIgnored = runCatching {
                powerManager?.isIgnoringBatteryOptimizations(packageName) ?: ignoreBatteryOpt
            }.getOrDefault(ignoreBatteryOpt)
            _installedApps.value = _installedApps.value.map { item ->
                if (item.packageName == packageName) {
                    item.copy(isBatteryOptIgnored = actualIgnored)
                } else {
                    item
                }
            }
        }
    }

    fun requestDiagnoseApp(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val binder = systemInterface ?: BinderBridge.fetchSystemInterface(getApplication()).also {
                systemInterface = it
            }
            if (binder == null) {
                val runningItem = _runningApps.value.firstOrNull { it.packageName == packageName }
                val localState = when {
                    runningItem == null -> "未在运行列表中发现进程（当前可能未启动或无 Root 权限）"
                    runningItem.frozenCount > 0 -> "已冻结 (${runningItem.frozenCount}/${runningItem.totalCount} 进程已冻结)"
                    else -> "未冻结 · 运行中 (共 ${runningItem.totalCount} 个活跃进程)"
                }
                _diagnosticDialogText.value = packageName to
                    "当前冻结状态：$localState\n\n未连接到 system_server，请确认模块已在 LSPosed 启用并重启系统以获取完整诊断信息。"
            } else {
                runCatching { binder.checkUnfreezeReason(packageName) }
                    .onFailure {
                        _diagnosticDialogText.value = packageName to "调用冻结状态诊断接口失败: ${it.message}"
                    }
            }
        }
    }

    fun dismissDiagnosticDialog() {
        _diagnosticDialogText.value = null
    }

    fun reloadSnapshot() {
        _config.value = prefsManager.snapshot()
        pushConfigToSystem("ALL")
    }

    private fun pushConfigToSystem(key: String) {
        val json = prefsManager.exportBackupJson()
        viewModelScope.launch(Dispatchers.IO) {
            val binder = systemInterface ?: BinderBridge.fetchSystemInterface(getApplication()).also {
                systemInterface = it
            }
            runCatching {
                binder?.pushConfigJson(json)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        runCatching { systemInterface?.unregisterCallback(uiCallback, "HomePage") }
    }
}
