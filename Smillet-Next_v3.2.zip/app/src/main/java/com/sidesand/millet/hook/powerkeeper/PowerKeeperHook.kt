package com.sidesand.millet.hook.powerkeeper

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.provider.Settings
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import com.sidesand.millet.ipc.BinderBridge
import com.sidesand.millet.ipc.ISystemCallback
import com.sidesand.millet.ipc.SystemInterface
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

object PowerKeeperHook {

    private val DEFAULT_BRIGHT_WHITE_APPS = listOf(
        "com.xiaomi.smarthome",
        "com.android.vending",
        "com.google.android.gms",
        "com.miui.gallery"
    )

    private val REMOVED_DATA_WHITE_APPS = listOf(
        "com.miui.notes",
        "com.flyersoft.moonreaderp",
        "com.sinovoice.voicebook",
        "com.wyfc.itingtxt2",
        "com.gedoor.monkeybook",
        "com.iflytek.vflynote",
        "com.flyersoft.seekbooks",
        "com.flyersoft.moonreader",
        "com.miui.themestore",
        "com.mipay.wallet",
        "com.tencent.wework"
    )

    @Volatile
    var appContext: Context? = null
        private set

    @Volatile
    var systemService: SystemInterface? = null
        private set

    @Volatile
    var milletPolicyInstance: Any? = null
        private set

    @Volatile
    var brightScenarioInstance: Any? = null
        private set

    private val mainHandler = Handler(Looper.getMainLooper())

    private val pkCallback = object : ISystemCallback.Stub() {
        override fun onConfigChanged(keyOrJson: String) {
            val parsed = if (keyOrJson.trimStart().startsWith("{")) {
                PrefsManager.saveSystemConfigFile(keyOrJson)
                    ?: PrefsManager.parseSnapshotFromJson(keyOrJson)
            } else {
                runCatching {
                    val pulled = systemService?.pullConfigJson().orEmpty()
                    PrefsManager.parseSnapshotFromJson(pulled)
                }.getOrNull() ?: PrefsManager.loadFromXposed()
            }
            if (parsed != null) {
                SMilletLogger.config = parsed
            }
            applyMilletPolicyLists()
            applyBrightPreloadWhitelist()
        }

        override fun requestCheckFreezeReason(packageName: String) {
            val report = diagnoseUnfreezeReason(packageName)
            systemService?.reportUnfreezeReason(packageName, report)
        }

        override fun onFreezeReasonResult(packageName: String, reason: String) {}
    }

    fun init(classLoader: ClassLoader) {
        SMilletLogger.config = PrefsManager.loadFromXposed()

        hookPowerKeeperApplication(classLoader)
        hookMilletPolicy(classLoader)
        hookMilletHandlers(classLoader)
        hookPowerSaveWhitelistAdapter(classLoader)
        hookBackgroundKillers(classLoader)
        hookHelperInstances(classLoader)

        SMilletLogger.info("com.miui.powerkeeper 全部 Hook 初始化完成")
    }

    private fun ensureSystemServiceConnected() {
        val current = systemService
        if (current != null && runCatching { current.asBinder().isBinderAlive }.getOrDefault(false)) {
            return
        }
        val ctx = appContext ?: return
        runCatching {
            val binder = BinderBridge.fetchSystemInterface(ctx)
            if (binder != null && binder.isSystemHookActive()) {
                systemService = binder
                binder.registerCallback(pkCallback, "PowerKeeper")
                val json = binder.pullConfigJson()
                PrefsManager.parseSnapshotFromJson(json)?.let {
                    SMilletLogger.config = it
                    applyMilletPolicyLists()
                    applyBrightPreloadWhitelist()
                }
                val noRestrict = Settings.System.getString(ctx.contentResolver, "MILLET_NO_RESTRICT_APP")
                binder.syncNoRestrictApps(noRestrict)
                SMilletLogger.info("电量与性能 (PowerKeeper) 绑定 system_server 服务成功")
            } else {
                mainHandler.postDelayed({ ensureSystemServiceConnected() }, 3000L)
            }
        }
    }

    private fun hookPowerKeeperApplication(classLoader: ClassLoader) {
        val appClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.PowerKeeperApplication",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(appClass, "onCreate", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                val app = param.thisObject as? Application ?: return
                appContext = app
                ensureSystemServiceConnected()
            }
        })
    }

    private fun hookMilletPolicy(classLoader: ClassLoader) {
        val policyClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.MilletPolicy",
            classLoader
        ) ?: return

        XposedBridge.hookAllConstructors(policyClass, object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                milletPolicyInstance = param.thisObject
                val ctx = param.args.firstOrNull { it is Context } as? Context
                if (ctx != null && appContext == null) {
                    appContext = ctx.applicationContext ?: ctx
                    ensureSystemServiceConnected()
                }
                runCatching {
                    val musicList = XposedHelpers.getStaticObjectField(policyClass, "musicApp") as? MutableList<*>
                    musicList?.clear()
                }
                applyMilletPolicyLists()
            }
        })

        XposedBridge.hookAllMethods(policyClass, "dealCloudWhiteList", XC_MethodReplacement.DO_NOTHING)
        XposedBridge.hookAllMethods(policyClass, "onCloudWhiteListChanged", XC_MethodReplacement.DO_NOTHING)

        XposedBridge.hookAllMethods(policyClass, "dealSleepModeWhiteList", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (milletPolicyInstance == null) milletPolicyInstance = param.thisObject
                param.result = null
            }
        })

        XposedBridge.hookAllMethods(policyClass, "dealNoRestrictApp", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                if (milletPolicyInstance == null) milletPolicyInstance = param.thisObject
                ensureSystemServiceConnected()
                applyMilletPolicyLists()
                appContext?.let { ctx ->
                    runCatching {
                        val noRestrict = Settings.System.getString(ctx.contentResolver, "MILLET_NO_RESTRICT_APP")
                        systemService?.syncNoRestrictApps(noRestrict)
                    }
                }
            }
        })

        XposedBridge.hookAllMethods(policyClass, "isInWhiteList", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (milletPolicyInstance == null) milletPolicyInstance = param.thisObject
                val arg0 = param.args.getOrNull(0) ?: return
                val pkg = when (arg0) {
                    is String -> arg0
                    is Int -> getPackageNameForUid(arg0)
                    else -> null
                } ?: return
                val cfg = SMilletLogger.config
                if (cfg.whiteAppSet.contains(pkg)) {
                    param.result = true
                } else if (cfg.forceFreezeSet.contains(pkg)) {
                    param.result = false
                }
            }
        })

        XposedBridge.hookAllMethods(policyClass, "isAllowFreeze", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (milletPolicyInstance == null) milletPolicyInstance = param.thisObject
                val uid = param.args.getOrNull(0) as? Int ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config
                if (cfg.whiteAppSet.contains(pkg)) {
                    param.result = false
                } else if (cfg.forceFreezeSet.contains(pkg)) {
                    param.result = true
                }
            }
        })
    }

    @Suppress("UNCHECKED_CAST")
    fun applyMilletPolicyLists() {
        val policy = milletPolicyInstance ?: return
        val policyClass = policy.javaClass
        val cfg = SMilletLogger.config

        runCatching {
            val msgList = XposedHelpers.getStaticObjectField(policyClass, "MESSAGE_APPS") as? MutableCollection<String>
            msgList?.apply {
                clear()
                addAll(cfg.messageAppSet)
            }
        }

        runCatching {
            val brightList = XposedHelpers.getStaticObjectField(policyClass, "BRIGHT_WHITE_APPS") as? MutableCollection<String>
            brightList?.apply {
                val allowed = HashSet(DEFAULT_BRIGHT_WHITE_APPS)
                allowed.removeAll(cfg.forceFreezeSet)
                allowed.addAll(cfg.whiteAppSet)
                clear()
                addAll(allowed)
            }
        }

        runCatching {
            val whiteList = XposedHelpers.getStaticObjectField(policyClass, "whiteApps") as? MutableCollection<String>
            if (whiteList != null) {
                whiteList.remove("com.miui.systemAdSolution")
                whiteList.remove("com.xiaomi.market")
                whiteList.removeAll(cfg.forceFreezeSet)
                XposedHelpers.setStaticObjectField(policyClass, "whiteApps", whiteList)
            }
        }

        runCatching {
            val dataWhiteList = XposedHelpers.getStaticObjectField(policyClass, "mDataWhiteList") as? MutableCollection<String>
            if (dataWhiteList != null) {
                dataWhiteList.removeAll(REMOVED_DATA_WHITE_APPS.toSet())
                dataWhiteList.removeAll(cfg.forceFreezeSet)
                XposedHelpers.setStaticObjectField(policyClass, "mDataWhiteList", dataWhiteList)
            }
        }

        runCatching {
            val blackSet = HashSet<String>(cfg.forceFreezeSet)
            XposedHelpers.setObjectField(policy, "mUseSystemBlackList", blackSet)
        }

        runCatching {
            val whiteSet = HashSet<String>(cfg.whiteAppSet)
            XposedHelpers.setObjectField(policy, "mUseDataWhiteList", whiteSet)
        }

        SMilletLogger.info(
            "PowerKeeper 已应用策略名单: 白名单=${cfg.whiteAppSet}, 强制冻结=${cfg.forceFreezeSet}, 消息应用=${cfg.messageAppSet}"
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun hookMilletHandlers(classLoader: ClassLoader) {
        val milletHandlerClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.MilletHandler",
            classLoader
        )
        if (milletHandlerClass != null) {
            XposedBridge.hookAllMethods(milletHandlerClass, "handleMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    ensureSystemServiceConnected()
                    val msg = param.args.getOrNull(0) as? Message ?: return
                    val cfg = SMilletLogger.config

                    if (msg.what == 13 && msg.arg1 == 16) {
                        if (cfg.disableCharge) {
                            param.result = null
                        }
                        return
                    }

                    val uid = msg.data?.getInt("uid", -1) ?: -1
                    if (uid > 0) {
                        val pkg = getPackageNameForUid(uid)
                        if (pkg != null && cfg.forbidSyncBinderSet.contains(pkg)) {
                            runCatching {
                                val qList = XposedHelpers.getObjectField(param.thisObject, "queryList") as? MutableSet<Int>
                                qList?.remove(uid)
                            }
                            param.result = null
                        }
                    }
                }
            })
        }

        val brightHandlerClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.bright.MilletBrightHandler",
            classLoader
        )
        if (brightHandlerClass != null) {
            XposedBridge.hookAllMethods(brightHandlerClass, "handleMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val msg = param.args.getOrNull(0) as? Message ?: return
                    val cfg = SMilletLogger.config
                    val data = msg.data

                    val uid = data?.getInt("uid", -1) ?: -1
                    if (uid > 0 && msg.what != 20) {
                        val pkg = getPackageNameForUid(uid)
                        if (pkg != null && cfg.forbidSyncBinderSet.contains(pkg)) {
                            runCatching {
                                val qList = XposedHelpers.getObjectField(param.thisObject, "queryList") as? MutableSet<Int>
                                qList?.remove(uid)
                            }
                            param.result = null
                            return
                        }
                    }

                    val eventCode = data?.getInt("eventcode", -1) ?: -1
                    if ((eventCode == 24 || eventCode == 25) && cfg.disableVolume) {
                        param.result = null
                    }
                }
            })
        }
    }

    private fun hookPowerSaveWhitelistAdapter(classLoader: ClassLoader) {
        val adapterClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.utils.CommonAdapter",
            classLoader
        ) ?: return

        val blockHook = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (SMilletLogger.config.blockAddPowerSaveWhitelistApps) {
                    param.result = null
                }
            }
        }
        XposedBridge.hookAllMethods(adapterClass, "addPowerSaveWhitelistApps", blockHook)
        XposedBridge.hookAllMethods(adapterClass, "removePowerSaveWhitelistApps", blockHook)
    }

    private fun hookBackgroundKillers(classLoader: ClassLoader) {
        val checkerClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.powerchecker.PowerCheckerController",
            classLoader
        )
        if (checkerClass != null) {
            XposedBridge.hookAllMethods(checkerClass, "clearApp", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (SMilletLogger.config.disableKill) {
                        param.result = null
                    }
                }
            })
        }

        val stateMachineClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.statemachine.PowerStateMachine",
            classLoader
        )
        if (stateMachineClass != null) {
            val stopKillHook = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (SMilletLogger.config.disableKill) {
                        param.result = null
                    }
                }
            }
            XposedBridge.hookAllMethods(stateMachineClass, "clearAppWhenScreenOffTimeOut", stopKillHook)
            XposedBridge.hookAllMethods(stateMachineClass, "clearAppWhenScreenOffTimeOutInNight", stopKillHook)
            XposedBridge.hookAllMethods(stateMachineClass, "clearUnactiveApps", stopKillHook)
        }
    }

    private fun hookHelperInstances(classLoader: ClassLoader) {
        XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.bright.BrightScenarioBase",
            classLoader
        )?.let { cls ->
            XposedBridge.hookAllConstructors(cls, object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    brightScenarioInstance = param.thisObject
                    applyBrightPreloadWhitelist()
                }
            })
        }

        XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.bright.BrightController",
            classLoader
        )?.let { cls ->
            XposedBridge.hookAllMethods(cls, "canFreezePkg", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val pkg = param.args.getOrNull(1) as? String
                        ?: (param.args.getOrNull(0) as? Int)?.let { getPackageNameForUid(it) }
                        ?: return
                    val cfg = SMilletLogger.config
                    if (cfg.whiteAppSet.contains(pkg)) {
                        param.result = false
                    } else if (cfg.forceFreezeSet.contains(pkg)) {
                        param.result = true
                    }
                }
            })
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun applyBrightPreloadWhitelist() {
        val bright = brightScenarioInstance ?: return
        runCatching {
            val preloadSet = XposedHelpers.getStaticObjectField(
                bright.javaClass,
                "preloadWhiteApps"
            ) as? MutableCollection<String>
            preloadSet?.removeAll(SMilletLogger.config.forceFreezeSet)
        }
    }

    private fun getPackageNameForUid(uid: Int): String? {
        val ctx = appContext ?: return null
        return runCatching {
            ctx.packageManager.getPackagesForUid(uid)?.firstOrNull()
        }.getOrNull()
    }

    private fun diagnoseUnfreezeReason(packageName: String): String {
        val ctx = appContext ?: return "无法获取 PowerKeeper 上下文"
        val uid = runCatching {
            ctx.packageManager.getApplicationInfo(packageName, 0).uid
        }.getOrNull() ?: return "找不到应用 UID: $packageName"

        val reasons = mutableListOf<String>()
        val cfg = SMilletLogger.config
        if (cfg.whiteAppSet.contains(packageName)) {
            reasons.add("处于 Smillet-Next 墓碑白名单中")
        }

        val policy = milletPolicyInstance
        if (policy != null) {
            runCatching {
                if (XposedHelpers.callMethod(policy, "isCtsPackage", packageName) as? Boolean == true) {
                    reasons.add("属于 CTS 测试包名豁免")
                }
            }
            runCatching {
                val noRestrict = XposedHelpers.getObjectField(policy, "mNoRestrictSet") as? Collection<*>
                if (noRestrict?.contains(packageName) == true) {
                    reasons.add("系统省电策略设为「无限制」")
                }
            }
            runCatching {
                if (XposedHelpers.callMethod(policy, "getActiveVpnUid") as? Int == uid) {
                    reasons.add("当前正在作为活跃 VPN 运行")
                }
            }
            runCatching {
                val ime = XposedHelpers.callMethod(policy, "getCurrentIME") as? String
                if (ime?.contains(packageName) == true) {
                    reasons.add("当前正在作为默认输入法 (IME) 使用")
                }
            }
            runCatching {
                val accUids = XposedHelpers.getObjectField(policy, "mAccessibilityUids") as? Collection<*>
                if (accUids?.contains(uid) == true) {
                    reasons.add("已开启无障碍服务 (AccessibilityService)")
                }
            }
            runCatching {
                if (XposedHelpers.callMethod(policy, "isInWhiteList", packageName) as? Boolean == true) {
                    reasons.add("位于 MilletPolicy 内置白名单（可在模块中开启「强制冻结」移出）")
                }
            }
        }

        return if (reasons.isEmpty()) {
            "[PowerKeeper 策略层]\n• 未发现白名单豁免项，该应用满足 Millet 冻结条件（切入后台静置后将被系统冻结）"
        } else {
            "[PowerKeeper 策略层 · 豁免/未冻结原因]\n• " + reasons.joinToString("\n• ")
        }
    }
}
