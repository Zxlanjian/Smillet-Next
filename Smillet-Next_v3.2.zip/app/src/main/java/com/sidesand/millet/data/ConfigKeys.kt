package com.sidesand.millet.data

/**
 * 对应原模块 Landroid/support/v4/ќ; 与 ध 中的全部 SharedPreferences 配置键与默认值。
 * 配置文件名固定为 "Settings" (MODE_WORLD_READABLE，支持 XSharedPreferences 读取)。
 */
object ConfigKeys {
    const val PREFS_NAME = "Settings"
    const val BINDER_ACTION = "SMillet-Binder"
    const val BINDER_KEY_SYSTEM = "system"
    const val LOCAL_LOG_PATH = "/data/system/SMillet/log"

    // 1. MilletSettings (墓碑核心配置)
    const val IS_LOG = "isLog"                                     // 详细日志开关 (默认 false)
    const val SIMPLIFY_LOG = "simplifyLog"                         // 精简日志 & 进程状态追踪 (默认 false)
    const val DISABLE_KILL = "disableKill"                         // 阻止电量与性能杀后台 (默认 true)
    const val DISABLE_VOLUME = "disableVolume"                     // 阻止音量键解冻后台音频相关应用 (默认 true)
    const val DISABLE_CHARGE = "disableCharge"                     // 阻止充电状态变化解冻全部应用 (默认 true)
    const val BLOCK_ADD_POWERSAVE_WHITELIST = "blockAddPowerSaveWhitelistApps" // 阻止动态篡改省电白名单 (默认 true)
    const val BATTERY_CHANGE_OBSERVE = "batteryChangeObserve"       // 息屏耗电统计 (默认 false)
    const val LOG_TO_LOCAL = "logToLocal"                          // 日志写入本地文件 (默认 false)

    // 2. DozeSettings (深度 Doze 配置)
    const val DOZE_LOG = "dozeLog"                                 // Doze 状态日志 (默认 false)
    const val ENABLE_DOZE = "enableDoze"                           // 息屏 3 分钟自动进入深度 Doze (默认 true)
    const val SKIP_STATE_CHECK = "skipStateCheck"                   // 跳过传感/定位检查直接进入 IDLE (默认 true)
    const val DISABLE_MOTION_LISTENER = "disableMotionListener"     // 禁用 Doze 运动传感器唤醒 (默认 true)

    // 3. BatteryOptSettings (系统电池优化白名单控制)
    const val BATTERY_OPT_WHITE_SET = "batteryOptWhiteSet"         // 未优化应用集合 (加入系统 PowerSaveWhitelist)
    const val BATTERY_OPT_BLACK_SET = "batteryOptBlackSet"         // 优化应用集合 (从系统 PowerSaveWhitelist 移除)

    // 4. AppSettings (单应用墓碑策略集合)
    const val WHITE_APP_SET = "whiteAppSet"                         // 墓碑白名单 (永不冻结，跳过广播拦截)
    const val MESSAGE_APP_SET = "messageAppSet"                     // 消息应用名单 (网络包短暂解冻后迅速重冻)
    const val FORCE_FREEZE_SET = "forceFreezeSet"                   // 强制冻结名单 (移出系统白名单、加入黑名单)
    const val BLOCK_THAW_SET = "blockThawSet"                       // 强力压制名单 (拦截非核心解冻原因)
    const val FORBID_SYNC_BINDER_SET = "forbidSyncBinderSet"       // 禁止同步 Binder 解冻名单
    const val NOT_FREEZE_WHEN_HAS_FGS_SET = "notFreezeWhenHasFgsSet"// 存在前台服务 (FGS) 时不冻结名单

    // 5. LogSettings (日志级别与输出目标)
    const val LOG_LEVEL = "logLevel"                               // "debug" | "info" | "warn" | "error"
    const val LOG_TYPE = "logType"                                 // "xposed" | "file"

    val DEFAULT_MESSAGE_APPS = setOf("com.tencent.mm")

    /**
     * 强力压制 (blockThawSet) 允许放行的解冻原因白名单 (还原自原模块 Landroid/support/v4/ษ;)
     */
    val ALLOWED_THAW_REASONS = listOf(
        "activity start",
        "notifi",
        "Activity Front",
        "FG activity",
        "tofront",
        "Sync Binder",
        "Check Binder",
        "Signal other",
        "Signal iso",
        "LAUNCH_MODE",
        "IMMOBULUS",
        "MediaButton",
        "receiver pkg",
        "PACKET",
        "cmd: thuid",
        "Net Change",
        "broadcast"
    )
}
