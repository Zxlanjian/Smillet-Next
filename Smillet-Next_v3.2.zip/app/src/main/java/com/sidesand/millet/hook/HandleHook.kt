package com.sidesand.millet.hook

import com.sidesand.millet.hook.powerkeeper.PowerKeeperHook
import com.sidesand.millet.hook.system.SystemServerHook
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * Xposed 入口类 (assets/xposed_init -> com.sidesand.millet.hook.HandleHook)
 * 对应原模块 com.sidesand.millet.hook.HandleHook 与 Landroid/support/v4/ࣂ;
 */
class HandleHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        when (lpparam.packageName) {
            "android" -> {
                SystemServerHook.init(lpparam.classLoader)
            }
            "com.miui.powerkeeper" -> {
                PowerKeeperHook.init(lpparam.classLoader)
            }
        }
    }
}
