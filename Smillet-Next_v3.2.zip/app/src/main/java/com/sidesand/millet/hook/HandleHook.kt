package com.sidesand.millet.hook

import com.sidesand.millet.hook.powerkeeper.PowerKeeperHook
import com.sidesand.millet.hook.system.SystemServerHook
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * Xposed 入口类 (assets/xposed_init -> com.sidesand.millet.hook.HandleHook)
 */
class HandleHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        when (lpparam.packageName) {
            "android" -> {
                SystemServerHook.init(lpparam.classLoader)
            }
            "com.miui.powerkeeper" -> {
                PowerKeeperHook.init(lpparam.classLoader)
            }
            "com.sidesand.millet" -> {
                runCatching {
                    XposedHelpers.findAndHookMethod(
                        "com.sidesand.millet.data.PrefsManager",
                        lpparam.classLoader,
                        "isHookedByLsp",
                        XC_MethodReplacement.returnConstant(true)
                    )
                }
            }
        }
    }
}
