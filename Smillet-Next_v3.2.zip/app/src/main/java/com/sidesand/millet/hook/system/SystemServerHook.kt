package com.sidesand.millet.hook.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.util.ArraySet
import com.google.gson.Gson
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import java.io.File
import java.util.Collections

object SystemServerHook {

    data class SysProcEntry(
        val pid: Int,
        val uid: Int,
        val processName: String,
        val rssKb: Long,
        val wchan: String,
        val state: String,
        val isFrozenByGreeze: Boolean
    )

    private val gson = Gson()
    private val hookedDicClasses = Collections.synchronizedSet(HashSet<Class<*>>())
    private val hookedGmsClasses = Collections.synchronizedSet(HashSet<Class<*>>())
    private val hookedAurogonClasses = Collections.synchronizedSet(HashSet<Class<*>>())

    @Volatile
    var greezeManagerService: Any? = null
        private set

    @Volatile
    var aurogonImmobulusMode: Any? = null
        private set

    @Volatile
    var amsInstance: Any? = null
        private set

    @Volatile
    private var cachedSystemContext: Context? = null

    @Volatile
    private var lastToFrontPkg: String? = null

    @Volatile
    private var screenReceiverRegistered: Boolean = false

    fun init(classLoader: ClassLoader) {
        reloadConfig("ALL")

        hookSystemServiceManager(classLoader)
        hookAmsBinderBridge(classLoader)
        hookGreezeManagerService(classLoader)
        hookAurogonImmobulusMode(classLoader)
        hookAnrSuppression(classLoader)
        hookBroadcastSkipForFrozenApp(classLoader)
        hookDeviceIdleController(classLoader)

        SMilletLogger.info("system_server 全部 Hook 初始化完成 (SDK=${Build.VERSION.SDK_INT})")
    }

    private fun hookSystemServiceManager(classLoader: ClassLoader) {
        val ssmClass = XposedHelpers.findClassIfExists(
            "com.android.server.SystemServiceManager",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(ssmClass, "startService", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                val service = param.result ?: param.args.firstOrNull() ?: return
                val cls = service.javaClass
                val name = cls.name
                if (name == "com.android.server.DeviceIdleController") {
                    hookDeviceIdleControllerClass(cls)
                    DozeControllerHelper.onDeviceIdleStart(service)
                } else if (name.contains("GreezeManagerService")) {
                    greezeManagerService = service
                    hookGreezeManagerServiceClass(cls)
                    cls.classLoader?.let { cl -> hookAurogonImmobulusMode(cl) }
                }
            }
        })
    }

    private fun ensureRuntimeServicesResolved() {
        if (greezeManagerService == null) {
            runCatching {
                val smClass = Class.forName("android.os.ServiceManager")
                val greezer = XposedHelpers.callStaticMethod(smClass, "getService", "greezer")
                if (greezer != null) {
                    greezeManagerService = greezer
                    hookGreezeManagerServiceClass(greezer.javaClass)
                    greezer.javaClass.classLoader?.let { cl -> hookAurogonImmobulusMode(cl) }
                }
            }
        }
        if (aurogonImmobulusMode == null && greezeManagerService != null) {
            val gms = greezeManagerService!!
            for (fieldName in listOf("mImmobulusMode", "mAurogonImmobulusMode")) {
                val obj = runCatching { XposedHelpers.getObjectField(gms, fieldName) }.getOrNull()
                if (obj != null) {
                    aurogonImmobulusMode = obj
                    hookAurogonClass(obj.javaClass)
                    break
                }
            }
        }
        DozeControllerHelper.resolveDeviceIdleController()
    }

    fun reloadConfig(changedKey: String) {
        val snapshot = PrefsManager.loadFromXposed()
        applyConfigSnapshot(snapshot)
    }

    fun applyConfigSnapshot(snapshot: MilletConfigSnapshot) {
        SMilletLogger.config = snapshot
        ensureRuntimeServicesResolved()
        syncMessageAppsToAurogon()
        syncBroadcastTargetWhiteList()
        thawWhitelistedApps(snapshot.whiteAppSet)
        DozeControllerHelper.applyBatteryOptimizationSets()
    }

    private fun thawWhitelistedApps(whiteApps: Set<String>) {
        if (whiteApps.isEmpty()) return
        val gms = greezeManagerService ?: return
        val ctx = getSystemContext() ?: return
        val pm = ctx.packageManager
        for (pkg in whiteApps) {
            runCatching {
                val uid = pm.getApplicationInfo(pkg, 0).uid
                if (uid >= 10000 && isUidFrozen(uid)) {
                    runCatching {
                        XposedHelpers.callMethod(gms, "thawUid", uid, 1000, "SmilletWhite")
                    }
                    SMilletLogger.info("白名单应用 [$pkg] (uid=$uid) 处于冻结状态，已立即执行解冻")
                }
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun syncBroadcastTargetWhiteList() {
        val gms = greezeManagerService ?: return
        val msgApps = SMilletLogger.config.messageAppSet
        runCatching {
            val map = XposedHelpers.getObjectField(gms, "mBroadcastTargetWhiteList") as? MutableMap<String, MutableList<String>>
                ?: return
            val actions = arrayListOf(
                "android.net.wifi.STATE_CHANGE",
                "android.net.conn.CONNECTIVITY_CHANGE"
            )
            for (pkg in msgApps) {
                map[pkg] = ArrayList(actions)
            }
            map.keys.retainAll(msgApps)
        }
    }

    fun collectRunningProcessesJson(includeSystem: Boolean): String {
        val token = Binder.clearCallingIdentity()
        return try {
            ensureRuntimeServicesResolved()
            val ctx = getSystemContext() ?: return "[]"
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return "[]"
            val runningList = am.runningAppProcesses ?: emptyList()
            val entries = ArrayList<SysProcEntry>(runningList.size)

            for (procInfo in runningList) {
                val pid = procInfo.pid
                val uid = procInfo.uid
                if (pid <= 0) continue
                val appId = uid % 100000
                if (!includeSystem && appId < 10000) continue

                val isFrozen = isUidFrozen(uid)
                val wchan = readProcWchan(pid, isFrozen)
                val (state, rssKb) = readProcStateAndRss(pid, am)

                entries.add(
                    SysProcEntry(
                        pid = pid,
                        uid = uid,
                        processName = procInfo.processName ?: "pid:$pid",
                        rssKb = rssKb,
                        wchan = wchan,
                        state = state,
                        isFrozenByGreeze = isFrozen
                    )
                )
            }
            gson.toJson(entries)
        } catch (t: Throwable) {
            SMilletLogger.error("collectRunningProcessesJson 异常", t)
            "[]"
        } finally {
            Binder.restoreCallingIdentity(token)
        }
    }

    private fun readProcWchan(pid: Int, isFrozenByGreeze: Boolean): String {
        val raw = runCatching {
            File("/proc/$pid/wchan").readText().trim()
        }.getOrNull().orEmpty()
        if (raw.isNotEmpty() && raw != "0" && raw != "-") {
            return raw
        }
        return if (isFrozenByGreeze) "do_freezer_trap" else "ep_poll"
    }

    private fun readProcStateAndRss(pid: Int, am: ActivityManager): Pair<String, Long> {
        var state = "S"
        var rssKb = 0L
        runCatching {
            val statusFile = File("/proc/$pid/status")
            if (statusFile.exists()) {
                statusFile.forEachLine { line ->
                    when {
                        line.startsWith("State:") -> {
                            state = line.substringAfter("State:").trim().take(1)
                        }
                        line.startsWith("VmRSS:") -> {
                            val num = line.substringAfter("VmRSS:").trim().split(Regex("\\s+")).firstOrNull()
                            rssKb = num?.toLongOrNull() ?: 0L
                        }
                    }
                }
            }
        }
        if (rssKb <= 0L) {
            runCatching {
                val memInfo = am.getProcessMemoryInfo(intArrayOf(pid))
                if (memInfo != null && memInfo.isNotEmpty()) {
                    rssKb = memInfo[0].totalPss.toLong()
                }
            }
        }
        return state to rssKb
    }

    private fun hookAmsBinderBridge(classLoader: ClassLoader) {
        val amsClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.ActivityManagerService",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(amsClass, "setSystemProcess", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                amsInstance = param.thisObject
                reloadConfig("ALL")
            }
        })

        XposedBridge.hookAllMethods(amsClass, "registerReceiverWithFeature", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val filter = param.args.firstOrNull { it is IntentFilter } as? IntentFilter ?: return
                if (filter.hasAction(ConfigKeys.BINDER_ACTION)) {
                    if (amsInstance == null) {
                        amsInstance = param.thisObject
                    }
                    ensureRuntimeServicesResolved()
                    val replyIntent = Intent()
                    val bundle = Bundle()
                    bundle.putBinder(ConfigKeys.BINDER_KEY_SYSTEM, SystemServerService)
                    replyIntent.putExtras(bundle)
                    param.result = replyIntent
                }
            }
        })
    }

    private fun hookGreezeManagerService(classLoader: ClassLoader) {
        val gmsClass = XposedHelpers.findClassIfExists(
            "com.miui.server.greeze.GreezeManagerService",
            classLoader
        ) ?: return
        hookGreezeManagerServiceClass(gmsClass)
    }

    fun hookGreezeManagerServiceClass(gmsClass: Class<*>) {
        if (!hookedGmsClasses.add(gmsClass)) return

        XposedBridge.hookAllConstructors(gmsClass, object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                greezeManagerService = param.thisObject
                val ctx = param.args.firstOrNull { it is Context } as? Context
                if (ctx != null) {
                    cachedSystemContext = ctx
                    if (!screenReceiverRegistered) {
                        screenReceiverRegistered = true
                        runCatching { DozeControllerHelper.registerScreenReceiver(ctx) }
                    }
                }
                syncBroadcastTargetWhiteList()
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "freezeAction", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: ""
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (cfg.whiteAppSet.contains(pkg)) {
                    SMilletLogger.debug("freezeAction 拦截: 白名单应用 [$pkg] 不冻结")
                    param.result = false
                    return
                }

                if (reason != "LAUNCH_MODE" && cfg.notFreezeWhenHasFgsSet.contains(pkg)) {
                    val hasFgs = checkAppHasForegroundService(uid)
                    if (hasFgs) {
                        SMilletLogger.debug("freezeAction 拦截: [$pkg] 具有前台服务，跳过冻结")
                        param.result = false
                    }
                }
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "freezeProcess", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val proc = param.args.getOrNull(0) ?: return
                val uid = runCatching { XposedHelpers.getIntField(proc, "uid") }.getOrNull() ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                if (SMilletLogger.config.whiteAppSet.contains(pkg)) {
                    SMilletLogger.debug("freezeProcess 拦截: 白名单应用 [$pkg] 不冻结")
                    param.result = false
                }
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "freezeUids", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val uids = param.args.getOrNull(0) as? IntArray ?: return
                if (uids.isEmpty()) return
                val cfg = SMilletLogger.config
                if (cfg.whiteAppSet.isEmpty() && cfg.notFreezeWhenHasFgsSet.isEmpty()) return

                val filtered = uids.filter { uid ->
                    val pkg = getPackageNameForUid(uid)
                    if (pkg != null && cfg.whiteAppSet.contains(pkg)) {
                        SMilletLogger.debug("freezeUids 过滤白名单应用: [$pkg] (uid=$uid)")
                        false
                    } else if (pkg != null && cfg.notFreezeWhenHasFgsSet.contains(pkg) && checkAppHasForegroundService(uid)) {
                        SMilletLogger.debug("freezeUids 过滤前台服务应用: [$pkg] (uid=$uid)")
                        false
                    } else {
                        true
                    }
                }.toIntArray()

                if (filtered.isEmpty()) {
                    param.result = ArrayList<Int>()
                } else if (filtered.size != uids.size) {
                    param.args[0] = filtered
                }
            }

            override fun afterHookedMethod(param: MethodHookParam) {
                if (!SMilletLogger.config.isLog && !SMilletLogger.config.simplifyLog) return
                val uids = param.args.getOrNull(0) as? IntArray ?: return
                val reason = param.args.getOrNull(3) as? String ?: ""
                if (uids.isEmpty()) return
                val names = uids.joinToString(",") { uid -> "${getPackageNameForUid(uid) ?: uid}@$uid" }
                SMilletLogger.info("++系统[冻结Uids]: 原因=[$reason], 列表=[$names]")
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "thawUid", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (reason == "tofront") {
                    lastToFrontPkg = pkg
                    return
                }
                if (reason == "screen on" && pkg == lastToFrontPkg) {
                    return
                }
                if (reason == "SmilletWhite") {
                    return
                }

                if (isUidFrozen(uid) && (reason == "broadcast" || reason == "Broadcast") && !cfg.whiteAppSet.contains(pkg)) {
                    param.result = false
                    return
                }

                if ((reason == "Sync Binder" || reason == "Check Binder") && cfg.forbidSyncBinderSet.contains(pkg)) {
                    SMilletLogger.info("--系统[解冻uid]: 禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                    return
                }

                if (cfg.blockThawSet.contains(pkg) && !ConfigKeys.ALLOWED_THAW_REASONS.contains(reason)) {
                    SMilletLogger.info("--系统[解冻uid]: 强力压制，禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                }
            }
        })

        SMilletLogger.info("已挂载 GreezeManagerService Hook")
    }

    private fun hookAurogonImmobulusMode(classLoader: ClassLoader) {
        val aurogonClass = XposedHelpers.findClassIfExists(
            "com.miui.server.greeze.AurogonImmobulusMode",
            classLoader
        ) ?: return
        hookAurogonClass(aurogonClass)
    }

    private fun hookAurogonClass(aurogonClass: Class<*>) {
        if (!hookedAurogonClasses.add(aurogonClass)) return

        XposedBridge.hookAllConstructors(aurogonClass, object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                aurogonImmobulusMode = param.thisObject
                syncMessageAppsToAurogon()
            }
        })

        XposedBridge.hookAllMethods(aurogonClass, "checkAppStatusForFreeze", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (aurogonImmobulusMode == null) aurogonImmobulusMode = param.thisObject
                val appInfo = param.args.getOrNull(0) ?: return
                val pkg = runCatching {
                    XposedHelpers.getObjectField(appInfo, "mPackageName") as? String
                }.getOrNull() ?: return
                if (SMilletLogger.config.whiteAppSet.contains(pkg)) {
                    param.result = false
                }
            }
        })
    }

    @Suppress("UNCHECKED_CAST")
    private fun syncMessageAppsToAurogon() {
        val instance = aurogonImmobulusMode ?: return
        val msgApps = SMilletLogger.config.messageAppSet
        runCatching {
            val staticField = runCatching {
                XposedHelpers.getStaticObjectField(instance.javaClass, "mMessageApp")
            }.getOrNull()
            val fieldObj = staticField ?: runCatching {
                XposedHelpers.getObjectField(instance, "mMessageApp")
            }.getOrNull()
            when (fieldObj) {
                is MutableList<*> -> {
                    val list = fieldObj as MutableList<String>
                    list.clear()
                    list.addAll(msgApps)
                }
                is ArraySet<*> -> {
                    val set = fieldObj as ArraySet<String>
                    set.clear()
                    set.addAll(msgApps)
                }
                else -> {
                    runCatching { XposedHelpers.setStaticObjectField(instance.javaClass, "mMessageApp", ArrayList(msgApps)) }
                    runCatching { XposedHelpers.setObjectField(instance, "mMessageApp", ArrayList(msgApps)) }
                }
            }
        }
    }

    private fun hookAnrSuppression(classLoader: ClassLoader) {
        val anrHelperClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.AnrHelper",
            classLoader
        )
        if (anrHelperClass != null) {
            val anrHook = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val processRecord = param.args.getOrNull(0) ?: return
                    val uid = runCatching { XposedHelpers.getIntField(processRecord, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        param.result = null
                    }
                }
            }
            XposedBridge.hookAllMethods(anrHelperClass, "appNotResponding", anrHook)
            XposedBridge.hookAllMethods(anrHelperClass, "deferAppNotResponding", anrHook)
        }

        val errStateClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.ProcessErrorStateRecord",
            classLoader
        )
        if (errStateClass != null) {
            XposedBridge.hookAllMethods(errStateClass, "appNotResponding", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val app = runCatching { XposedHelpers.getObjectField(param.thisObject, "mApp") }.getOrNull() ?: return
                    val uid = runCatching { XposedHelpers.getIntField(app, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        param.result = null
                    }
                }
            })
        }
    }

    private fun hookBroadcastSkipForFrozenApp(classLoader: ClassLoader) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU) {
            val bqClass = XposedHelpers.findClassIfExists(
                "com.android.server.am.BroadcastQueue",
                classLoader
            ) ?: return
            XposedBridge.hookAllMethods(bqClass, "deliverToRegisteredReceiverLocked", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedHelpers.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedHelpers.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = null
                    }
                }
            })
        } else {
            val skipPolicyClass = XposedHelpers.findClassIfExists(
                "com.android.server.am.BroadcastSkipPolicy",
                classLoader
            ) ?: return
            XposedBridge.hookAllMethods(skipPolicyClass, "shouldSkipMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedHelpers.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedHelpers.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = "Skip frozen process by Smillet-Next"
                    }
                }
            })
        }
    }

    private fun shouldSkipFrozenProcess(processRecord: Any): Boolean {
        val uid = runCatching { XposedHelpers.getIntField(processRecord, "uid") }.getOrNull() ?: return false
        if (uid < 10000) return false
        if (!isUidFrozen(uid)) return false
        val pkg = getPackageNameForUid(uid) ?: return false
        return !SMilletLogger.config.whiteAppSet.contains(pkg)
    }

    private fun hookDeviceIdleController(classLoader: ClassLoader) {
        val dicClass = XposedHelpers.findClassIfExists(
            "com.android.server.DeviceIdleController",
            classLoader
        )
        if (dicClass != null) {
            hookDeviceIdleControllerClass(dicClass)
        }
    }

    fun hookDeviceIdleControllerClass(dicClass: Class<*>) {
        if (!hookedDicClasses.add(dicClass)) return

        XposedBridge.hookAllConstructors(dicClass, object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                DozeControllerHelper.onDeviceIdleStart(param.thisObject)
            }
        })

        XposedBridge.hookAllMethods(dicClass, "onStart", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                DozeControllerHelper.onDeviceIdleStart(param.thisObject)
            }
        })

        XposedBridge.hookAllMethods(dicClass, "motionLocked", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                if (cfg.disableMotionListener) {
                    param.result = null
                    runCatching { XposedHelpers.setBooleanField(param.thisObject, "mNotMoving", true) }
                }
            }
        })

        XposedBridge.hookAllMethods(dicClass, "moveToStateLocked", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                val targetState = param.args.getOrNull(0) as? Int ?: return
                if (cfg.enableDoze && cfg.skipStateCheck && targetState in 2..4) {
                    param.args[0] = 5
                    param.args[1] = "SMilletSkip"
                    runCatching { XposedHelpers.callMethod(param.thisObject, "resetIdleManagementLocked") }
                }
            }
        })

        SMilletLogger.info("已挂载 DeviceIdleController Hook (${dicClass.classLoader})")
    }

    fun isUidFrozen(uid: Int): Boolean {
        val gms = greezeManagerService ?: ensureGreezeManagerService() ?: return false
        return runCatching {
            XposedHelpers.callMethod(gms, "isUidFrozen", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    fun diagnoseFreezeStatus(packageName: String): String {
        val ctx = getSystemContext()
        val uid = runCatching {
            ctx?.packageManager?.getApplicationInfo(packageName, 0)?.uid
        }.getOrNull() ?: -1

        val isGreezeFrozen = if (uid > 0) isUidFrozen(uid) else false
        val hasFgService = if (uid > 0) checkAppHasForegroundService(uid) else false
        val isDozeIgnored = runCatching {
            val pm = ctx?.getSystemService(android.os.PowerManager::class.java)
            pm?.isIgnoringBatteryOptimizations(packageName) == true
        }.getOrDefault(false)

        var totalProcs = 0
        var frozenProcs = 0
        if (uid > 0) {
            runCatching {
                val json = collectRunningProcessesJson(includeSystem = true)
                if (json.startsWith("[")) {
                    val arr = org.json.JSONArray(json)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        if (obj.optInt("uid") == uid) {
                            totalProcs++
                            val wchan = obj.optString("wchan", "").lowercase()
                            val state = obj.optString("state", "")
                            val byGreeze = obj.optBoolean("isFrozenByGreeze", false)
                            if (byGreeze || wchan.contains("freezer") || wchan.contains("refrigerator") ||
                                wchan.contains("get_signal") || state == "T"
                            ) {
                                frozenProcs++
                            }
                        }
                    }
                }
            }
        }

        val stateText = when {
            isGreezeFrozen || (totalProcs > 0 && frozenProcs > 0) ->
                "已冻结 (Greezer=${if (isGreezeFrozen) "已冻结" else "未标记"}, 冻结进程 $frozenProcs/$totalProcs)"
            totalProcs > 0 ->
                "未冻结 · 正在运行 (活跃进程 $totalProcs 个)"
            else ->
                "未运行 (当前无后台进程)"
        }

        val cfg = SMilletLogger.config
        val rules = mutableListOf<String>()
        if (cfg.whiteAppSet.contains(packageName)) rules.add("墓碑白名单")
        if (cfg.forceFreezeSet.contains(packageName)) rules.add("强制冻结 (黑名单)")
        if (cfg.blockThawSet.contains(packageName)) rules.add("强力压制 (黑名单)")
        if (cfg.messageAppSet.contains(packageName)) rules.add("消息应用")
        if (cfg.forbidSyncBinderSet.contains(packageName)) rules.add("禁止同步 Binder")
        if (cfg.notFreezeWhenHasFgsSet.contains(packageName)) rules.add("前台服务不冻结")

        return buildString {
            append("[SystemServer 实时状态]\n")
            append("• 当前冻结状态：$stateText\n")
            append("• 应用 UID：${if (uid > 0) uid else "未知"}\n")
            append("• 电池优化状态：${if (isDozeIgnored) "未优化 (已豁免 Doze)" else "已优化 (受省电管控)"}\n")
            append("• 活跃前台服务 (FGS)：${if (hasFgService) "存在" else "无"}\n")
            append("• 模块已配策略：${if (rules.isEmpty()) "默认 (未配置特殊规则)" else rules.joinToString("、")}")
        }
    }

    private fun checkAppHasForegroundService(uid: Int): Boolean {
        val aurogon = aurogonImmobulusMode ?: return false
        return runCatching {
            XposedHelpers.callMethod(aurogon, "checkAppFgService", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    private fun getSystemContext(): Context? {
        cachedSystemContext?.let { return it }
        val ams = amsInstance ?: return null
        return runCatching {
            (XposedHelpers.getObjectField(ams, "mContext") as? Context)?.also {
                cachedSystemContext = it
                if (!screenReceiverRegistered) {
                    screenReceiverRegistered = true
                    runCatching { DozeControllerHelper.registerScreenReceiver(it) }
                }
            }
        }.getOrNull()
    }

    private fun getPackageNameForUid(uid: Int): String? {
        val ctx = getSystemContext() ?: return null
        return runCatching {
            ctx.packageManager.getPackagesForUid(uid)?.firstOrNull()
        }.getOrNull()
    }
}
