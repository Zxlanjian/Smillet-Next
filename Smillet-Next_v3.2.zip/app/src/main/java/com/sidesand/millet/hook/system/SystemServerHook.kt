package com.sidesand.millet.hook.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.util.ArraySet
import com.google.gson.Gson
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import com.sidesand.millet.hook.XposedCompat
import com.sidesand.millet.hook.XposedCompat.MethodHook
import com.sidesand.millet.hook.XposedCompat.MethodHookParam
import java.io.File
import java.util.Collections

object SystemServerHook {

    data class SysProcEntry(
        val pid: Int,
        val uid: Int,
        val processName: String,
        val rssKb: Long,
        val wchan: String,
        val state: String,
        val isFrozenByGreeze: Boolean
    )

    private val gson = Gson()
    private val hookedDicClasses = Collections.synchronizedSet(HashSet<Class<*>>())
    private val hookedGmsClasses = Collections.synchronizedSet(HashSet<Class<*>>())
    private val hookedAurogonClasses = Collections.synchronizedSet(HashSet<Class<*>>())

    @Volatile
    var greezeManagerService: Any? = null
        private set

    @Volatile
    var aurogonImmobulusMode: Any? = null
        private set

    @Volatile
    var amsInstance: Any? = null
        private set

    @Volatile
    private var cachedSystemContext: Context? = null

    @Volatile
    private var lastToFrontPkg: String? = null

    @Volatile
    private var screenReceiverRegistered: Boolean = false

    fun init(classLoader: ClassLoader) {
        reloadConfig("ALL")

        hookSystemServiceManager(classLoader)
        hookAmsBinderBridge(classLoader)
        hookGreezeManagerService(classLoader)
        hookAurogonImmobulusMode(classLoader)
        hookAnrSuppression(classLoader)
        hookBroadcastSkipForFrozenApp(classLoader)
        hookDeviceIdleController(classLoader)

        SMilletLogger.info("system_server 全部 Hook 初始化完成 (SDK=${Build.VERSION.SDK_INT}, API 102)")
    }

    private fun hookSystemServiceManager(classLoader: ClassLoader) {
        val ssmClass = XposedCompat.findClassIfExists(
            "com.android.server.SystemServiceManager",
            classLoader
        ) ?: return

        XposedCompat.hookAllMethods(ssmClass, "startService", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val arg0 = param.args.firstOrNull() ?: return
                val targetCls = when (arg0) {
                    is Class<*> -> arg0
                    else -> arg0.javaClass
                }
                val name = targetCls.name
                if (name.contains("DeviceIdleController")) {
                    val dicCls = if (name == "com.android.server.DeviceIdleController") {
                        targetCls
                    } else {
                        targetCls.classLoader?.let {
                            XposedCompat.findClassIfExists("com.android.server.DeviceIdleController", it)
                        }
                    }
                    if (dicCls != null) hookDeviceIdleControllerClass(dicCls)
                } else if (name.contains("GreezeManagerService")) {
                    targetCls.classLoader?.let { cl ->
                        hookGreezeManagerService(cl)
                        hookAurogonImmobulusMode(cl)
                    }
                }
            }

            override fun afterHookedMethod(param: MethodHookParam) {
                val service = param.result ?: param.args.firstOrNull() ?: return
                if (service is Class<*>) return
                val cls = service.javaClass
                val name = cls.name
                if (name.contains("DeviceIdleController")) {
                    val actualDic = unwrapServiceInstance(service)
                    hookDeviceIdleControllerClass(actualDic.javaClass)
                    DozeControllerHelper.onDeviceIdleStart(actualDic)
                } else if (name.contains("GreezeManagerService")) {
                    val actualService = unwrapServiceInstance(service)
                    greezeManagerService = actualService
                    hookGreezeManagerServiceClass(actualService.javaClass)
                    actualService.javaClass.classLoader?.let { cl -> hookAurogonImmobulusMode(cl) }
                    ensureRuntimeServicesResolved()
                }
            }
        })

        XposedCompat.hookAllMethods(ssmClass, "startBootPhase", object : MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                val phase = param.args.firstOrNull { it is Int } as? Int ?: return
                if (phase == 500 || phase == 550 || phase == 1000) {
                    ensureRuntimeServicesResolved()
                    if (phase == 1000) {
                        applyConfigSnapshot(SMilletLogger.config)
                    }
                }
            }
        })
    }

    private fun unwrapServiceInstance(raw: Any): Any {
        if (!raw.javaClass.name.contains("$")) return raw
        return runCatching { XposedCompat.getObjectField(raw, "this$0") }.getOrNull()
            ?: runCatching { XposedCompat.getObjectField(raw, "mService") }.getOrNull()
            ?: raw
    }

    private fun ensureRuntimeServicesResolved() {
        if (greezeManagerService == null) {
            runCatching {
                val smClass = Class.forName("android.os.ServiceManager")
                val greezer = XposedCompat.callStaticMethod(smClass, "getService", "greezer")
                if (greezer != null) {
                    val actual = unwrapServiceInstance(greezer)
                    greezeManagerService = actual
                    hookGreezeManagerServiceClass(actual.javaClass)
                    actual.javaClass.classLoader?.let { cl -> hookAurogonImmobulusMode(cl) }
                    syncBroadcastTargetWhiteList()
                }
            }
        }
        if (aurogonImmobulusMode == null && greezeManagerService != null) {
            val gms = greezeManagerService!!
            for (fieldName in listOf("mImmobulusMode", "mAurogonImmobulusMode")) {
                val obj = runCatching { XposedCompat.getObjectField(gms, fieldName) }.getOrNull()
                if (obj != null) {
                    aurogonImmobulusMode = obj
                    hookAurogonClass(obj.javaClass)
                    syncMessageAppsToAurogon()
                    break
                }
            }
        }
        getSystemContext()
        DozeControllerHelper.resolveDeviceIdleController()
    }

    fun reloadConfig(changedKey: String) {
        val snapshot = PrefsManager.loadFromXposed()
        applyConfigSnapshot(snapshot)
    }

    fun applyConfigSnapshot(snapshot: MilletConfigSnapshot) {
        SMilletLogger.config = snapshot
        ensureRuntimeServicesResolved()
        syncMessageAppsToAurogon()
        syncBroadcastTargetWhiteList()
        thawWhitelistedApps(snapshot.whiteAppSet)
        DozeControllerHelper.applyBatteryOptimizationSets()
    }

    private fun thawWhitelistedApps(whiteApps: Set<String>) {
        if (whiteApps.isEmpty()) return
        val gms = greezeManagerService ?: return
        val ctx = getSystemContext() ?: return
        val pm = ctx.packageManager
        for (pkg in whiteApps) {
            runCatching {
                val uid = pm.getApplicationInfo(pkg, 0).uid
                if (uid >= 10000 && isUidFrozen(uid)) {
                    runCatching {
                        XposedCompat.callMethod(gms, "thawUid", uid, 1000, "SmilletWhite")
                    }
                    SMilletLogger.info("白名单应用 [$pkg] (uid=$uid) 处于冻结状态，已立即执行解冻")
                }
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun syncBroadcastTargetWhiteList() {
        val gms = greezeManagerService ?: return
        val msgApps = SMilletLogger.config.messageAppSet
        runCatching {
            val map = XposedCompat.getObjectField(gms, "mBroadcastTargetWhiteList") as? MutableMap<String, MutableList<String>>
                ?: return
            val actions = arrayListOf(
                "android.net.wifi.STATE_CHANGE",
                "android.net.conn.CONNECTIVITY_CHANGE"
            )
            for (pkg in msgApps) {
                map[pkg] = ArrayList(actions)
            }
            map.keys.retainAll(msgApps)
        }
    }

    fun collectRunningProcessesJson(includeSystem: Boolean): String {
        val token = Binder.clearCallingIdentity()
        return try {
            ensureRuntimeServicesResolved()
            val ctx = getSystemContext() ?: return "[]"
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return "[]"
            val runningList = am.runningAppProcesses ?: emptyList()
            val entries = ArrayList<SysProcEntry>(runningList.size)

            for (procInfo in runningList) {
                val pid = procInfo.pid
                val uid = procInfo.uid
                if (pid <= 0) continue
                val appId = uid % 100000
                if (!includeSystem && appId < 10000) continue

                val isFrozen = isUidFrozen(uid)
                val wchan = readProcWchan(pid, isFrozen)
                val (state, rssKb) = readProcStateAndRss(pid, am)

                entries.add(
                    SysProcEntry(
                        pid = pid,
                        uid = uid,
                        processName = procInfo.processName ?: "pid:$pid",
                        rssKb = rssKb,
                        wchan = wchan,
                        state = state,
                        isFrozenByGreeze = isFrozen
                    )
                )
            }
            gson.toJson(entries)
        } catch (t: Throwable) {
            SMilletLogger.error("collectRunningProcessesJson 异常", t)
            "[]"
        } finally {
            Binder.restoreCallingIdentity(token)
        }
    }

    private fun readProcWchan(pid: Int, isFrozenByGreeze: Boolean): String {
        val raw = runCatching {
            File("/proc/$pid/wchan").readText().trim()
        }.getOrNull().orEmpty()
        if (raw.isNotEmpty() && raw != "0" && raw != "-") {
            return raw
        }
        return if (isFrozenByGreeze) "do_freezer_trap" else "ep_poll"
    }

    private fun readProcStateAndRss(pid: Int, am: ActivityManager): Pair<String, Long> {
        var state = "S"
        var rssKb = 0L
        runCatching {
            val statusFile = File("/proc/$pid/status")
            if (statusFile.exists()) {
                statusFile.forEachLine { line ->
                    when {
                        line.startsWith("State:") -> {
                            state = line.substringAfter("State:").trim().take(1)
                        }
                        line.startsWith("VmRSS:") -> {
                            val num = line.substringAfter("VmRSS:").trim().split(Regex("\\s+")).firstOrNull()
                            rssKb = num?.toLongOrNull() ?: 0L
                        }
                    }
                }
            }
        }
        if (rssKb <= 0L) {
            runCatching {
                val memInfo = am.getProcessMemoryInfo(intArrayOf(pid))
                if (memInfo != null && memInfo.isNotEmpty()) {
                    rssKb = memInfo[0].totalPss.toLong()
                }
            }
        }
        return state to rssKb
    }

    private fun hookAmsBinderBridge(classLoader: ClassLoader) {
        val amsClass = XposedCompat.findClassIfExists(
            "com.android.server.am.ActivityManagerService",
            classLoader
        ) ?: return

        XposedCompat.hookAllMethods(amsClass, "setSystemProcess", object : MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                amsInstance = param.thisObject
                reloadConfig("ALL")
            }
        })

        XposedCompat.hookAllMethods(amsClass, "registerReceiverWithFeature", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val filter = param.args.firstOrNull { it is IntentFilter } as? IntentFilter ?: return
                if (filter.hasAction(ConfigKeys.BINDER_ACTION)) {
                    if (amsInstance == null) {
                        amsInstance = param.thisObject
                    }
                    ensureRuntimeServicesResolved()
                    val replyIntent = Intent()
                    val bundle = Bundle()
                    bundle.putBinder(ConfigKeys.BINDER_KEY_SYSTEM, SystemServerService)
                    replyIntent.putExtras(bundle)
                    param.result = replyIntent
                }
            }
        })
    }

    private fun hookGreezeManagerService(classLoader: ClassLoader) {
        val gmsClass = XposedCompat.findClassIfExists(
            "com.miui.server.greeze.GreezeManagerService",
            classLoader
        ) ?: return
        hookGreezeManagerServiceClass(gmsClass)
    }

    fun hookGreezeManagerServiceClass(gmsClass: Class<*>) {
        if (!hookedGmsClasses.add(gmsClass)) return

        XposedCompat.hookAllConstructors(gmsClass, object : MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                greezeManagerService = param.thisObject
                val ctx = param.args.firstOrNull { it is Context } as? Context
                if (ctx != null) {
                    cachedSystemContext = ctx
                    if (!screenReceiverRegistered) {
                        screenReceiverRegistered = true
                        runCatching { DozeControllerHelper.registerScreenReceiver(ctx) }
                    }
                }
                syncBroadcastTargetWhiteList()
            }
        })

        XposedCompat.hookAllMethods(gmsClass, "freezeAction", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: ""
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (cfg.whiteAppSet.contains(pkg)) {
                    SMilletLogger.debug("freezeAction 拦截: 白名单应用 [$pkg] 不冻结")
                    param.result = false
                    return
                }

                if (reason != "LAUNCH_MODE" && cfg.notFreezeWhenHasFgsSet.contains(pkg)) {
                    val hasFgs = checkAppHasForegroundService(uid)
                    if (hasFgs) {
                        SMilletLogger.debug("freezeAction 拦截: [$pkg] 具有前台服务，跳过冻结")
                        param.result = false
                    }
                }
            }
        })

        XposedCompat.hookAllMethods(gmsClass, "freezeProcess", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val proc = param.args.getOrNull(0) ?: return
                val uid = runCatching { XposedCompat.getIntField(proc, "uid") }.getOrNull() ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                if (SMilletLogger.config.whiteAppSet.contains(pkg)) {
                    SMilletLogger.debug("freezeProcess 拦截: 白名单应用 [$pkg] 不冻结")
                    param.result = false
                }
            }
        })

        XposedCompat.hookAllMethods(gmsClass, "freezeUids", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val uids = param.args.getOrNull(0) as? IntArray ?: return
                if (uids.isEmpty()) return
                val cfg = SMilletLogger.config
                if (cfg.whiteAppSet.isEmpty() && cfg.notFreezeWhenHasFgsSet.isEmpty()) return

                val filtered = uids.filter { uid ->
                    val pkg = getPackageNameForUid(uid)
                    if (pkg != null && cfg.whiteAppSet.contains(pkg)) {
                        SMilletLogger.debug("freezeUids 过滤白名单应用: [$pkg] (uid=$uid)")
                        false
                    } else if (pkg != null && cfg.notFreezeWhenHasFgsSet.contains(pkg) && checkAppHasForegroundService(uid)) {
                        SMilletLogger.debug("freezeUids 过滤前台服务应用: [$pkg] (uid=$uid)")
                        false
                    } else {
                        true
                    }
                }.toIntArray()

                if (filtered.isEmpty()) {
                    param.result = ArrayList<Int>()
                } else if (filtered.size != uids.size) {
                    param.args[0] = filtered
                }
            }

            override fun afterHookedMethod(param: MethodHookParam) {
                if (!SMilletLogger.config.isLog && !SMilletLogger.config.simplifyLog) return
                val uids = param.args.getOrNull(0) as? IntArray ?: return
                val reason = param.args.getOrNull(3) as? String ?: ""
                if (uids.isEmpty()) return
                val names = uids.joinToString(",") { uid -> "${getPackageNameForUid(uid) ?: uid}@$uid" }
                SMilletLogger.info("++系统[冻结Uids]: 原因=[$reason], 列表=[$names]")
            }
        })

        XposedCompat.hookAllMethods(gmsClass, "thawUid", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) greezeManagerService = param.thisObject
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (reason == "tofront") {
                    lastToFrontPkg = pkg
                    return
                }
                if (reason == "screen on" && pkg == lastToFrontPkg) {
                    return
                }
                if (reason == "SmilletWhite") {
                    return
                }

                if (isUidFrozen(uid) &&
                    pkg != "com.tencent.mobileqq" &&
                    (reason == "broadcast" || reason == "Broadcast") &&
                    !cfg.whiteAppSet.contains(pkg)
                ) {
                    param.result = false
                    return
                }

                if ((reason == "Sync Binder" || reason == "Check Binder") && cfg.forbidSyncBinderSet.contains(pkg)) {
                    SMilletLogger.info("--系统[解冻uid]: 禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                    return
                }

                if (cfg.blockThawSet.contains(pkg) && !ConfigKeys.ALLOWED_THAW_REASONS.contains(reason)) {
                    SMilletLogger.info("--系统[解冻uid]: 强力压制，禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                }
            }
        })

        SMilletLogger.info("已挂载 GreezeManagerService Hook")
    }

    private fun hookAurogonImmobulusMode(classLoader: ClassLoader) {
        val aurogonClass = XposedCompat.findClassIfExists(
            "com.miui.server.greeze.AurogonImmobulusMode",
            classLoader
        ) ?: return
        hookAurogonClass(aurogonClass)
    }

    private fun hookAurogonClass(aurogonClass: Class<*>) {
        if (!hookedAurogonClasses.add(aurogonClass)) return

        XposedCompat.hookAllConstructors(aurogonClass, object : MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                aurogonImmobulusMode = param.thisObject
                syncMessageAppsToAurogon()
            }
        })

        XposedCompat.hookAllMethods(aurogonClass, "checkAppStatusForFreeze", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (aurogonImmobulusMode == null) aurogonImmobulusMode = param.thisObject
                val appInfo = param.args.getOrNull(0) ?: return
                val pkg = runCatching {
                    XposedCompat.getObjectField(appInfo, "mPackageName") as? String
                }.getOrNull() ?: return
                if (SMilletLogger.config.whiteAppSet.contains(pkg)) {
                    param.result = false
                }
            }
        })
    }

    @Suppress("UNCHECKED_CAST")
    private fun syncMessageAppsToAurogon() {
        val instance = aurogonImmobulusMode ?: return
        val msgApps = SMilletLogger.config.messageAppSet
        runCatching {
            val staticField = runCatching {
                XposedCompat.getStaticObjectField(instance.javaClass, "mMessageApp")
            }.getOrNull()
            val fieldObj = staticField ?: runCatching {
                XposedCompat.getObjectField(instance, "mMessageApp")
            }.getOrNull()
            when (fieldObj) {
                is MutableList<*> -> {
                    val list = fieldObj as MutableList<String>
                    list.clear()
                    list.addAll(msgApps)
                }
                is ArraySet<*> -> {
                    val set = fieldObj as ArraySet<String>
                    set.clear()
                    set.addAll(msgApps)
                }
                else -> {
                    runCatching { XposedCompat.setStaticObjectField(instance.javaClass, "mMessageApp", ArrayList(msgApps)) }
                    runCatching { XposedCompat.setObjectField(instance, "mMessageApp", ArrayList(msgApps)) }
                }
            }
        }
    }

    private fun extractUidFromAnrArgs(args: Array<Any?>): Int? {
        for (arg in args) {
            if (arg == null) continue
            val clsName = arg.javaClass.name
            if (clsName.endsWith("ProcessRecord")) {
                val uid = runCatching { XposedCompat.getIntField(arg, "uid") }.getOrNull()
                if (uid != null) return uid
            } else if (clsName.contains("AnrRecord")) {
                val app = runCatching { XposedCompat.getObjectField(arg, "mApp") }.getOrNull()
                if (app != null) {
                    val uid = runCatching { XposedCompat.getIntField(app, "uid") }.getOrNull()
                    if (uid != null) return uid
                }
                val directUid = runCatching { XposedCompat.getIntField(arg, "mUid") }.getOrNull()
                    ?: runCatching { XposedCompat.getIntField(arg, "uid") }.getOrNull()
                if (directUid != null) return directUid
            }
        }
        return null
    }

    private fun hookAnrSuppression(classLoader: ClassLoader) {
        val anrHelperClass = XposedCompat.findClassIfExists(
            "com.android.server.am.AnrHelper",
            classLoader
        )
        if (anrHelperClass != null) {
            val anrHook = object : MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val uid = extractUidFromAnrArgs(param.args) ?: return
                    if (isUidFrozen(uid)) {
                        SMilletLogger.debug("已屏蔽冻结应用 ANR (AnrHelper, uid=$uid)")
                        param.result = null
                    }
                }
            }
            XposedCompat.hookAllMethods(anrHelperClass, "appNotResponding", anrHook)
            XposedCompat.hookAllMethods(anrHelperClass, "deferAppNotResponding", anrHook)
        }

        val errStateClass = XposedCompat.findClassIfExists(
            "com.android.server.am.ProcessErrorStateRecord",
            classLoader
        )
        if (errStateClass != null) {
            XposedCompat.hookAllMethods(errStateClass, "appNotResponding", object : MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val thisObj = param.thisObject ?: return
                    val app = runCatching { XposedCompat.getObjectField(thisObj, "mApp") }.getOrNull() ?: return
                    val uid = runCatching { XposedCompat.getIntField(app, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        SMilletLogger.debug("已屏蔽冻结应用 ANR (ProcessErrorStateRecord, uid=$uid)")
                        param.result = null
                    }
                }
            })
        }
    }

    private fun hookBroadcastSkipForFrozenApp(classLoader: ClassLoader) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU) {
            val bqClass = XposedCompat.findClassIfExists(
                "com.android.server.am.BroadcastQueue",
                classLoader
            ) ?: return
            XposedCompat.hookAllMethods(bqClass, "deliverToRegisteredReceiverLocked", object : MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedCompat.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedCompat.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = null
                    }
                }
            })
        } else {
            val skipPolicyClass = XposedCompat.findClassIfExists(
                "com.android.server.am.BroadcastSkipPolicy",
                classLoader
            ) ?: return
            XposedCompat.hookAllMethods(skipPolicyClass, "shouldSkipMessage", object : MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedCompat.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedCompat.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = "Skip frozen process by Smillet-Next"
                    }
                }
            })
        }
    }

    private fun shouldSkipFrozenProcess(processRecord: Any): Boolean {
        val uid = runCatching { XposedCompat.getIntField(processRecord, "uid") }.getOrNull() ?: return false
        if (uid < 10000) return false
        if (!isUidFrozen(uid)) return false
        val pkg = getPackageNameForUid(uid) ?: return false
        return !SMilletLogger.config.whiteAppSet.contains(pkg)
    }

    private fun hookDeviceIdleController(classLoader: ClassLoader) {
        val dicClass = XposedCompat.findClassIfExists(
            "com.android.server.DeviceIdleController",
            classLoader
        )
        if (dicClass != null) {
            hookDeviceIdleControllerClass(dicClass)
        }
    }

    fun hookDeviceIdleControllerClass(dicClass: Class<*>) {
        if (!hookedDicClasses.add(dicClass)) return

        XposedCompat.hookAllConstructors(dicClass, object : MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                param.thisObject?.let { DozeControllerHelper.onDeviceIdleStart(it) }
            }
        })

        XposedCompat.hookAllMethods(dicClass, "onStart", object : MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                param.thisObject?.let { DozeControllerHelper.onDeviceIdleStart(it) }
            }
        })

        XposedCompat.hookAllMethods(dicClass, "motionLocked", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                if (cfg.disableMotionListener) {
                    param.result = null
                    param.thisObject?.let { obj ->
                        runCatching { XposedCompat.setBooleanField(obj, "mNotMoving", true) }
                    }
                }
            }
        })

        XposedCompat.hookAllMethods(dicClass, "moveToStateLocked", object : MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                val targetState = param.args.getOrNull(0) as? Int ?: return
                if (cfg.enableDoze && cfg.skipStateCheck && targetState in 2..4) {
                    param.args[0] = 5
                    param.args[1] = "SMilletSkip"
                    param.thisObject?.let { obj ->
                        runCatching { XposedCompat.callMethod(obj, "resetIdleManagementLocked") }
                    }
                }
            }
        })

        SMilletLogger.info("已挂载 DeviceIdleController Hook (${dicClass.classLoader})")
    }

    fun isUidFrozen(uid: Int): Boolean {
        if (greezeManagerService == null) {
            ensureRuntimeServicesResolved()
        }
        val gms = greezeManagerService ?: return false
        return runCatching {
            XposedCompat.callMethod(gms, "isUidFrozen", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    fun diagnoseFreezeStatus(packageName: String): String {
        val ctx = getSystemContext()
        val uid = runCatching {
            ctx?.packageManager?.getApplicationInfo(packageName, 0)?.uid
        }.getOrNull() ?: -1

        val isGreezeFrozen = if (uid > 0) isUidFrozen(uid) else false
        val hasFgService = if (uid > 0) checkAppHasForegroundService(uid) else false
        val isDozeIgnored = runCatching {
            val pm = ctx?.getSystemService(android.os.PowerManager::class.java)
            pm?.isIgnoringBatteryOptimizations(packageName) == true
        }.getOrDefault(false)

        var totalProcs = 0
        var frozenProcs = 0
        if (uid > 0) {
            runCatching {
                val json = collectRunningProcessesJson(includeSystem = true)
                if (json.startsWith("[")) {
                    val arr = org.json.JSONArray(json)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        if (obj.optInt("uid") == uid) {
                            totalProcs++
                            val wchan = obj.optString("wchan", "").lowercase()
                            val state = obj.optString("state", "")
                            val byGreeze = obj.optBoolean("isFrozenByGreeze", false)
                            if (byGreeze || wchan.contains("freezer") || wchan.contains("refrigerator") ||
                                wchan.contains("get_signal") || state == "T"
                            ) {
                                frozenProcs++
                            }
                        }
                    }
                }
            }
        }

        val stateText = when {
            isGreezeFrozen || (totalProcs > 0 && frozenProcs > 0) ->
                "已冻结 (Greezer=${if (isGreezeFrozen) "已冻结" else "未标记"}, 冻结进程 $frozenProcs/$totalProcs)"
            totalProcs > 0 ->
                "未冻结 · 正在运行 (活跃进程 $totalProcs 个)"
            else ->
                "未运行 (当前无后台进程)"
        }

        val cfg = SMilletLogger.config
        val rules = mutableListOf<String>()
        if (cfg.whiteAppSet.contains(packageName)) rules.add("墓碑白名单")
        if (cfg.forceFreezeSet.contains(packageName)) rules.add("强制冻结 (黑名单)")
        if (cfg.blockThawSet.contains(packageName)) rules.add("强力压制 (黑名单)")
        if (cfg.messageAppSet.contains(packageName)) rules.add("消息应用")
        if (cfg.forbidSyncBinderSet.contains(packageName)) rules.add("禁止同步 Binder")
        if (cfg.notFreezeWhenHasFgsSet.contains(packageName)) rules.add("前台服务不冻结")

        return buildString {
            append("[SystemServer 实时状态]\n")
            append("• 当前冻结状态：$stateText\n")
            append("• 应用 UID：${if (uid > 0) uid else "未知"}\n")
            append("• 电池优化状态：${if (isDozeIgnored) "未优化 (已豁免 Doze)" else "已优化 (受省电管控)"}\n")
            append("• 活跃前台服务 (FGS)：${if (hasFgService) "存在" else "无"}\n")
            append("• 模块已配策略：${if (rules.isEmpty()) "默认 (未配置特殊规则)" else rules.joinToString("、")}")
        }
    }

    private fun checkAppHasForegroundService(uid: Int): Boolean {
        val aurogon = aurogonImmobulusMode ?: return false
        return runCatching {
            XposedCompat.callMethod(aurogon, "checkAppFgService", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    private fun getSystemContext(): Context? {
        cachedSystemContext?.let { return it }
        val candidates = listOfNotNull(amsInstance, greezeManagerService)
        for (holder in candidates) {
            val ctx = runCatching { XposedCompat.getObjectField(holder, "mContext") as? Context }.getOrNull()
            if (ctx != null) {
                cachedSystemContext = ctx
                if (!screenReceiverRegistered) {
                    screenReceiverRegistered = true
                    runCatching { DozeControllerHelper.registerScreenReceiver(ctx) }
                }
                return ctx
            }
        }
        return null
    }

    private fun getPackageNameForUid(uid: Int): String? {
        val ctx = getSystemContext() ?: return null
        return runCatching {
            ctx.packageManager.getPackagesForUid(uid)?.firstOrNull()
        }.getOrNull()
    }
}
