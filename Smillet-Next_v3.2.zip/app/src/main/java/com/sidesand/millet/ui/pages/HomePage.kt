package com.sidesand.millet.ui.pages

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun HomePage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    isSystemActive: Boolean,
    isPowerKeeperActive: Boolean,
    scrollBehavior: ScrollBehavior,
    onNavigateToWhitelist: () -> Unit,
    onNavigateToBlacklist: () -> Unit,
    onNavigateToRunning: () -> Unit
) {
    val runningApps by viewModel.runningApps.collectAsState()
    val frozenCount = runningApps.count { it.frozenCount > 0 }
    val blackCount = (config.forceFreezeSet + config.blockThawSet).size
    val isDark = isSystemInDarkTheme()

    val warnBgColor = if (isDark) Color(0xFF3E1D1E) else Color(0xFFFBE9E9)
    val warnTextColor = if (isDark) Color(0xFFFF7A7C) else Color(0xFFD9383A)

    val statusCardBgColor = if (isSystemActive) {
        if (isDark) Color(0xFF193C28) else Color(0xFFDFF5E6)
    } else {
        if (isDark) Color(0xFF3E1D1E) else Color(0xFFFBE9E9)
    }
    val statusTitleColor = if (isSystemActive) {
        if (isDark) Color(0xFF5CE08E) else Color(0xFF157F3D)
    } else {
        if (isDark) Color(0xFFFF7A7C) else Color(0xFFD9383A)
    }
    val statusSubColor = if (isSystemActive) {
        if (isDark) Color(0xFF9AD9B2) else Color(0xFF286E42)
    } else {
        if (isDark) Color(0xFFE09B9C) else Color(0xFFB54748)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!isSystemActive) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(warnBgColor)
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = "此模块尚未被 Xposed 激活！",
                        color = warnTextColor,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        if (!isSystemActive || !isPowerKeeperActive) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(warnBgColor)
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = "长时间未连接：请检查 LSPosed 中 Smillet-Next 是否启用，并勾选 系统框架(android) / 电量与性能(com.miui.powerkeeper) 作用域后重启。",
                        color = warnTextColor,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 左侧状态卡片：运行中为绿色卡片，未运行为红色卡片
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(16.dp))
                        .background(statusCardBgColor)
                        .clickable {
                            viewModel.connectAndRefresh(includeSystem = false)
                            onNavigateToRunning()
                        }
                        .padding(20.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isSystemActive) "运行中" else "未运行",
                                fontSize = 23.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusTitleColor
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isSystemActive) "版本: 3.2.0" else "版本: 未激活",
                                fontSize = 14.sp,
                                color = statusSubColor
                            )
                        }
                        Spacer(modifier = Modifier.height(36.dp))
                        Column {
                            Text(
                                text = "已冻结应用: $frozenCount",
                                fontSize = 13.sp,
                                color = statusTitleColor,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = when {
                                    isSystemActive && isPowerKeeperActive -> "PowerKeeper 已就绪"
                                    isSystemActive -> "点击刷新 PowerKeeper"
                                    else -> "点击重试连接"
                                },
                                fontSize = 12.sp,
                                color = statusSubColor
                            )
                        }
                    }
                }

                // 右侧白名单与黑名单快捷筛选卡片
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onNavigateToWhitelist() }
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "白名单",
                                fontSize = 15.sp,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${config.whiteAppSet.size}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onNavigateToBlacklist() }
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "黑名单",
                                fontSize = 15.sp,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$blackCount",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    InfoBlock(
                        title = "模块版本",
                        value = "v3.2.0 (Smillet-Next)"
                    )
                    InfoBlock(
                        title = "Hook 类型",
                        value = when {
                            isSystemActive && isPowerKeeperActive -> "Greezer + MilletPolicy 双作用域已接管"
                            isSystemActive -> "SystemServer 已连接"
                            else -> "未连接 (等待作用域生效)"
                        }
                    )
                    InfoBlock(
                        title = "Android 版本",
                        value = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
                    )
                    InfoBlock(
                        title = "策略概览",
                        value = "消息应用 ${config.messageAppSet.size} · 禁同步Binder ${config.forbidSyncBinderSet.size} · 前台不冻结 ${config.notFreezeWhenHasFgsSet.size}"
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoBlock(title: String, value: String) {
    Column {
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontSize = 14.sp,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary
        )
    }
}
