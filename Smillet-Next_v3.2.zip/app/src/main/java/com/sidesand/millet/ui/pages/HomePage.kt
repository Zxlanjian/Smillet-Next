package com.sidesand.millet.ui.pages

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun HomePage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    isSystemActive: Boolean,
    isPowerKeeperActive: Boolean,
    scrollBehavior: ScrollBehavior,
    onNavigateToWhitelist: () -> Unit,
    onNavigateToBlacklist: () -> Unit,
    onNavigateToRunning: () -> Unit
) {
    val runningApps by viewModel.runningApps.collectAsState()
    val isLspActivated by viewModel.isLspActivated.collectAsState()
    val isRootGranted by viewModel.isRootGranted.collectAsState()
    val frozenCount = runningApps.count { it.frozenCount > 0 }
    val blackCount = (config.forceFreezeSet + config.blockThawSet).size
    val isDark = isSystemInDarkTheme()

    val isModuleActive = isLspActivated && isSystemActive

    // Miuix 红色警告横幅配色
    val warnBgColor = if (isDark) Color(0xFF3E1D1E) else Color(0xFFFBE9E9)
    val warnTextColor = if (isDark) Color(0xFFFF7A7C) else Color(0xFFD9383A)

    // 主页左侧状态卡片配色：严格参考 Miuix 浅绿/浅红状态卡片设计
    val statusCardBgColor = if (isModuleActive) {
        if (isDark) Color(0xFF163324) else Color(0xFFDEFCE5)
    } else {
        if (isDark) Color(0xFF3A1C1E) else Color(0xFFFDE8E8)
    }
    val statusTitleColor = if (isModuleActive) {
        if (isDark) Color(0xFF5CE09B) else Color(0xFF3EA346)
    } else {
        if (isDark) Color(0xFFFF8080) else Color(0xFFD9383A)
    }
    val statusSubColor = if (isModuleActive) {
        if (isDark) Color(0xFFB4C7B9) else Color(0xFF536157)
    } else {
        if (isDark) Color(0xFFE0B4B4) else Color(0xFF6E5252)
    }
    // 卡片右下角大号圆形线框与 √ / × 颜色
    val cornerBadgeColor = if (isModuleActive) {
        if (isDark) Color(0xFF38C96A) else Color(0xFF3EA346)
    } else {
        if (isDark) Color(0xFFFF5252) else Color(0xFFE53935)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. LSPosed 未激活红色横幅警告
        if (!isModuleActive) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(warnBgColor)
                        .clickable { viewModel.connectAndRefresh(includeSystem = false) }
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = if (!isLspActivated) {
                            "模块未被 LSPosed 激活：请在 LSPosed 管理器中启用 Smillet-Next，勾选「系统框架 (system/android)」与「电量与性能 (com.miui.powerkeeper)」作用域后重启系统。"
                        } else {
                            "模块已在 LSPosed 启用但系统服务未生效：请确认已勾选「系统框架 (system/android)」与「电量与性能 (com.miui.powerkeeper)」作用域并重启手机。"
                        },
                        color = warnTextColor,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // 2. Root 权限未授权红色横幅警告
        if (!isRootGranted) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(warnBgColor)
                        .clickable { viewModel.connectAndRefresh(includeSystem = false) }
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = "未授予 Root 权限：无法执行底层进程冻结状态扫描与 Doze 省电控制命令，请在 Root 管理器中授权 Smillet-Next 后点击此横幅重试。",
                        color = warnTextColor,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // 3. PowerKeeper 未连接提醒横幅
        if (isModuleActive && !isPowerKeeperActive) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(warnBgColor)
                        .clickable { viewModel.connectAndRefresh(includeSystem = false) }
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = "电量与性能 (PowerKeeper) 尚未连接：请确认 LSPosed 已勾选「电量与性能 (com.miui.powerkeeper)」作用域，或点击此处重连刷新。",
                        color = warnTextColor,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 左侧状态卡片：从上往下依次为「运行中/未激活」、「v3.2.0」、「已冻结：X」+ 右下角裁切大圆框 √ / ×
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(20.dp))
                        .background(statusCardBgColor)
                        .clickable {
                            viewModel.connectAndRefresh(includeSystem = false)
                            if (isModuleActive) {
                                onNavigateToRunning()
                            }
                        }
                ) {
                    // 右下角大号圆形线框 + 居中 √ / ×（由卡片圆角边界自然裁切）
                    StatusCornerBadge(
                        isActive = isModuleActive,
                        color = cornerBadgeColor,
                        modifier = Modifier.matchParentSize()
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp, vertical = 20.dp)
                    ) {
                        Text(
                            text = if (isModuleActive) "运行中" else "未激活",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = statusTitleColor
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "v3.2.0",
                            fontSize = 14.sp,
                            color = statusSubColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "已冻结：$frozenCount",
                            fontSize = 14.sp,
                            color = statusSubColor
                        )
                        Spacer(modifier = Modifier.height(64.dp))
                    }
                }

                // 右侧白名单与黑名单快捷筛选卡片
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onNavigateToWhitelist() }
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "白名单",
                                fontSize = 15.sp,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${config.whiteAppSet.size}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onNavigateToBlacklist() }
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "黑名单",
                                fontSize = 15.sp,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$blackCount",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    InfoBlock(
                        title = "模块版本",
                        value = "v3.2.0 (Smillet-Next · LSPosed API 102)"
                    )
                    InfoBlock(
                        title = "环境与作用域状态",
                        value = buildString {
                            append(if (isLspActivated) "LSPosed 已激活" else "LSPosed 未激活")
                            append(" · ")
                            append(if (isRootGranted) "Root 已授权" else "Root 未授权")
                            append(" · ")
                            append(
                                when {
                                    isSystemActive && isPowerKeeperActive -> "双作用域已接管"
                                    isSystemActive -> "仅 SystemServer 已连接"
                                    else -> "服务未连接"
                                }
                            )
                        }
                    )
                    InfoBlock(
                        title = "Android 版本",
                        value = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
                    )
                    InfoBlock(
                        title = "策略概览",
                        value = "消息应用 ${config.messageAppSet.size} · 禁同步Binder ${config.forbidSyncBinderSet.size} · 前台不冻结 ${config.notFreezeWhenHasFgsSet.size}"
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusCornerBadge(
    isActive: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val baseDim = size.minDimension
        val radius = baseDim * 0.37f
        val strokeWidth = baseDim * 0.068f
        val cx = size.width * 0.72f
        val cy = size.height * 0.73f
        val center = Offset(cx, cy)

        // 右下角大号圆形线框（超出卡片右/下边缘部分由父容器圆角自动裁切）
        drawCircle(
            color = color,
            radius = radius,
            center = center,
            style = Stroke(width = strokeWidth)
        )

        if (isActive) {
            // 圆圈内部居中圆角对勾 √
            val checkPath = Path().apply {
                moveTo(cx - radius * 0.40f, cy + radius * 0.02f)
                lineTo(cx - radius * 0.10f, cy + radius * 0.32f)
                lineTo(cx + radius * 0.44f, cy - radius * 0.24f)
            }
            drawPath(
                path = checkPath,
                color = color,
                style = Stroke(
                    width = strokeWidth,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        } else {
            // 非激活状态下圆圈内部居中圆角叉号 ×
            val offset = radius * 0.28f
            drawLine(
                color = color,
                start = Offset(cx - offset, cy - offset),
                end = Offset(cx + offset, cy + offset),
                strokeWidth = strokeWidth,
                cap = StrokeCap.Round
            )
            drawLine(
                color = color,
                start = Offset(cx + offset, cy - offset),
                end = Offset(cx - offset, cy + offset),
                strokeWidth = strokeWidth,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun InfoBlock(title: String, value: String) {
    Column {
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontSize = 14.sp,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary
        )
    }
}
