package com.sidesand.millet.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.sidesand.millet.data.FreezeType
import com.sidesand.millet.data.ProcessDetail
import com.sidesand.millet.data.RunningAppItem
import com.sidesand.millet.ipc.SystemInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 双引擎运行与冻结进程扫描器：
 * 1. 优先结合 Root `su -c "ps -A -o USER,UID,PID,RSS,WCHAN,S,ARGS"`（按 UID 映射包名，解决 Android ps NAME 列 15 字符截断问题）。
 * 2. 同时合并来自 `system_server` (`SystemInterface.getRunningProcessesJson`) 的 GreezeManagerService 冻结状态与进程列表，
 *    即使未授予 Root 权限或内核隐藏了 wchan，也能准确显示冻结与运行状态。
 */
object ProcessScanner {

    data class SysProcDto(
        val pid: Int = 0,
        val uid: Int = 0,
        val processName: String = "",
        val rssKb: Long = 0L,
        val wchan: String = "",
        val state: String = "",
        val isFrozenByGreeze: Boolean = false
    )

    private val gson = Gson()
    private val whitespaceRegex = Regex("\\s+")

    suspend fun scanRunningApps(
        context: Context,
        includeSystemApps: Boolean,
        systemInterface: SystemInterface? = null
    ): Result<List<RunningAppItem>> = withContext(Dispatchers.IO) {
        try {
            val pm = context.packageManager
            val installedApps = pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            val uidToAppMap = HashMap<Int, ApplicationInfo>()
            val pkgToAppMap = HashMap<String, ApplicationInfo>()

            for (info in installedApps) {
                pkgToAppMap[info.packageName] = info
                // 优先保留非系统或者主包名映射
                if (!uidToAppMap.containsKey(info.uid)) {
                    uidToAppMap[info.uid] = info
                }
            }

            // 1. 从 SystemServer Binder 获取 GreezeManagerService 权威冻结状态与进程表
            val frozenUidsFromSystem = HashSet<Int>()
            val pidMap = LinkedHashMap<Int, Pair<Int, ProcessDetail>>() // pid -> (uid, detail)

            if (systemInterface != null) {
                runCatching {
                    val json = systemInterface.getRunningProcessesJson(includeSystemApps)
                    if (json.isNotBlank() && json.startsWith("[")) {
                        val type = object : TypeToken<List<SysProcDto>>() {}.type
                        val list: List<SysProcDto> = gson.fromJson(json, type) ?: emptyList()
                        for (dto in list) {
                            if (dto.isFrozenByGreeze) {
                                frozenUidsFromSystem.add(dto.uid)
                            }
                            val fType = classifyFreezeState(dto.wchan, dto.state, dto.isFrozenByGreeze)
                            val detail = ProcessDetail(
                                pid = dto.pid,
                                processName = dto.processName,
                                rssKb = dto.rssKb,
                                wchan = dto.wchan,
                                state = dto.state,
                                isFrozen = fType != FreezeType.RUNNING,
                                freezeType = fType
                            )
                            pidMap[dto.pid] = dto.uid to detail
                        }
                    }
                }
            }

            // 2. 通过 Root 执行 ps -A -o USER,PID,RSS,WCHAN,S,ARGS 获取完整内核 wchan 状态
            runCatching {
                val proc = Runtime.getRuntime().exec(
                    arrayOf("su", "-c", "ps -A -o USER,PID,RSS,WCHAN,S,ARGS")
                )
                val reader = BufferedReader(InputStreamReader(proc.inputStream))
                reader.useLines { lines ->
                    lines.forEach { rawLine ->
                        val line = rawLine.trim()
                        if (line.isEmpty() || line.startsWith("USER")) return@forEach

                        val parts = line.split(whitespaceRegex, limit = 6)
                        if (parts.size < 6) return@forEach

                        val userStr = parts[0]
                        val pid = parts[1].toIntOrNull() ?: return@forEach
                        val rssKb = parts[2].toLongOrNull() ?: 0L
                        val wchan = parts[3]
                        val state = parts[4]
                        val cmdArgs = parts[5].trim()

                        // 过滤内核线程 (如 [kthreadd]) 与 zombies
                        if (state == "Z" || cmdArgs.startsWith("[")) return@forEach

                        val uid = parseAndroidUid(userStr) ?: return@forEach
                        val appId = uid % 100000
                        if (!includeSystemApps && appId < 10000) return@forEach

                        val procName = cmdArgs.split(whitespaceRegex).firstOrNull() ?: cmdArgs
                        if (!procName.contains(".")) return@forEach

                        val isUidFrozen = frozenUidsFromSystem.contains(uid)
                        val freezeType = classifyFreezeState(wchan, state, isUidFrozen)
                        val detail = ProcessDetail(
                            pid = pid,
                            processName = procName,
                            rssKb = if (rssKb > 0) rssKb else (pidMap[pid]?.second?.rssKb ?: 0L),
                            wchan = if (wchan != "-" && wchan != "0") wchan else (pidMap[pid]?.second?.wchan ?: wchan),
                            state = state,
                            isFrozen = freezeType != FreezeType.RUNNING,
                            freezeType = freezeType
                        )
                        pidMap[pid] = uid to detail
                    }
                }
                proc.waitFor()
            }

            // 3. 按应用包名聚合所有进程
            val grouped = HashMap<String, MutableList<ProcessDetail>>()
            val pkgUidMap = HashMap<String, Int>()

            for ((_, pair) in pidMap) {
                val (uid, detail) = pair
                val basePkgFromProc = detail.processName.substringBefore(":")
                val appInfo = pkgToAppMap[basePkgFromProc]
                    ?: resolveAppInfoForUid(pm, uid, uidToAppMap, pkgToAppMap)
                    ?: continue

                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                if (!includeSystemApps && isSystem) continue

                pkgUidMap[appInfo.packageName] = uid
                grouped.getOrPut(appInfo.packageName) { mutableListOf() }.add(detail)
            }

            val resultList = grouped.mapNotNull { (pkg, processes) ->
                val appInfo = pkgToAppMap[pkg] ?: return@mapNotNull null
                val appName = pm.getApplicationLabel(appInfo).toString().trim()
                val icon = runCatching { pm.getApplicationIcon(appInfo) }.getOrNull()
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val totalRssMb = processes.sumOf { it.rssKb } / 1024f

                RunningAppItem(
                    uid = pkgUidMap[pkg] ?: appInfo.uid,
                    packageName = pkg,
                    appName = appName,
                    icon = icon,
                    isSystemApp = isSystem,
                    totalRssMb = totalRssMb,
                    processes = processes.sortedBy { it.processName }
                )
            }.sortedWith(
                compareByDescending<RunningAppItem> { it.frozenCount > 0 }
                    .thenByDescending { it.totalRssMb }
            )

            Result.success(resultList)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    /**
     * 还原原模块 Landroid/support/v4/צ; 与 ສ 的 USER 字符串转 UID 逻辑：
     * 例如 "u0_a443" -> userId=0, appId=10443 -> uid=10443
     */
    private fun parseAndroidUid(user: String): Int? {
        user.toIntOrNull()?.let { return it }
        if (user == "system") return 1000
        if (user == "phone" || user == "radio") return 1001
        if (user == "shell") return 2000
        if (!user.startsWith("u")) return null

        val underscoreIdx = user.indexOf('_')
        if (underscoreIdx <= 1) return null
        val userId = user.substring(1, underscoreIdx).toIntOrNull() ?: return null
        val suffix = user.substring(underscoreIdx + 1)
        return when {
            suffix.startsWith("a") -> {
                val offset = suffix.substring(1).toIntOrNull() ?: return null
                userId * 100000 + 10000 + offset
            }
            suffix.startsWith("i") -> {
                val offset = suffix.substring(1).toIntOrNull() ?: return null
                userId * 100000 + 99000 + offset
            }
            else -> null
        }
    }

    private fun resolveAppInfoForUid(
        pm: PackageManager,
        uid: Int,
        uidToAppMap: Map<Int, ApplicationInfo>,
        pkgToAppMap: Map<String, ApplicationInfo>
    ): ApplicationInfo? {
        uidToAppMap[uid]?.let { return it }
        val normalizedUid = if (uid > 19999) {
            val s = uid.toString()
            ("1" + s.substring(s.length - 4)).toIntOrNull() ?: uid
        } else {
            uid
        }
        uidToAppMap[normalizedUid]?.let { return it }
        val pkgs = runCatching { pm.getPackagesForUid(normalizedUid) }.getOrNull()
        val firstPkg = pkgs?.firstOrNull() ?: return null
        return pkgToAppMap[firstPkg]
    }

    /**
     * 还原原模块 Landroid/support/v4/ʫ; 的冻结状态判定表：
     * - V2: `do_freezer_trap`, `get_signal`, `freezable_schedule` 或 GreezeManagerService.isUidFrozen == true
     * - V1: `__refrigerator`
     * - KILL: `do_signal_stop` 或进程状态 `T`
     */
    private fun classifyFreezeState(
        wchan: String,
        state: String,
        isFrozenByGreeze: Boolean
    ): FreezeType {
        val lower = wchan.lowercase()
        return when {
            lower.contains("do_freezer_trap") ||
                lower.contains("get_signal") ||
                lower.contains("freezable_schedule") ||
                lower.contains("freezer") -> FreezeType.V2
            lower.contains("__refrigerator") || lower.contains("refrigerator") -> FreezeType.V1
            lower.contains("do_signal_stop") || state.equals("T", ignoreCase = true) -> FreezeType.KILL
            isFrozenByGreeze -> FreezeType.V2
            else -> FreezeType.RUNNING
        }
    }
}
