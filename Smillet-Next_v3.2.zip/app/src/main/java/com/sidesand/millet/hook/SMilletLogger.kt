package com.sidesand.millet.hook

import android.util.Log
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SMilletLogger {
    private const val TAG = "Smillet-Next"
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    @Volatile
    var config: MilletConfigSnapshot = MilletConfigSnapshot()

    fun debug(msg: String) {
        if (!config.isLog && !config.simplifyLog && !config.dozeLog) return
        write(Log.DEBUG, "DEBUG", msg, null)
    }

    fun info(msg: String) {
        write(Log.INFO, "INFO", msg, null)
    }

    fun warn(msg: String) {
        write(Log.WARN, "WARN", msg, null)
    }

    fun error(msg: String, t: Throwable? = null) {
        val full = if (t != null) "$msg: ${t.message}" else msg
        write(Log.ERROR, "ERROR", full, t)
    }

    private fun write(priority: Int, level: String, msg: String, t: Throwable?) {
        val formatted = "${dateFormat.format(Date())} [$level] [$TAG] $msg"
        XposedCompat.log(priority, TAG, formatted, t)
        if (config.logType == "file" || config.logToLocal) {
            runCatching {
                val file = File(ConfigKeys.LOCAL_LOG_PATH)
                file.parentFile?.mkdirs()
                FileWriter(file, true).use { it.appendLine(formatted) }
            }
        }
    }
}
