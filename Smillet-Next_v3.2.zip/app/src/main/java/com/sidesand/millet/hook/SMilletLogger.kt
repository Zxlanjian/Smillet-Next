package com.sidesand.millet.hook

import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SMilletLogger {
    private const val TAG = "[Smillet-Next]"
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    @Volatile
    var config: MilletConfigSnapshot = MilletConfigSnapshot()

    fun debug(msg: String) {
        if (!config.isLog && !config.simplifyLog && !config.dozeLog) return
        write("DEBUG", msg)
    }

    fun info(msg: String) {
        write("INFO", msg)
    }

    fun warn(msg: String) {
        write("WARN", msg)
    }

    fun error(msg: String, t: Throwable? = null) {
        val full = if (t != null) "$msg: ${t.message}" else msg
        write("ERROR", full)
    }

    private fun write(level: String, msg: String) {
        val formatted = "${dateFormat.format(Date())} [$level] $TAG $msg"
        XposedBridge.log(formatted)
        if (config.logType == "file" || config.logToLocal) {
            runCatching {
                val file = File(ConfigKeys.LOCAL_LOG_PATH)
                file.parentFile?.mkdirs()
                FileWriter(file, true).use { it.appendLine(formatted) }
            }
        }
    }
}
