package com.sidesand.millet.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController

/**
 * 基于 compose-miuix-ui/miuix (v0.9.4) 的小米澎湃 HyperOS 主题封装，
 * 支持跟随系统浅色/深色与莫奈动态取色 (ColorSchemeMode.MonetSystem)。
 */
@Composable
fun SMilletMiuixTheme(
    colorSchemeMode: ColorSchemeMode = ColorSchemeMode.System,
    content: @Composable () -> Unit
) {
    val controller = remember(colorSchemeMode) {
        ThemeController(colorSchemeMode)
    }
    MiuixTheme(
        controller = controller,
        content = content
    )
}
