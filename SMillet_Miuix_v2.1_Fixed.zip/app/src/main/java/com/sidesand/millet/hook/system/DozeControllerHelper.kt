package com.sidesand.millet.hook.system

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.sidesand.millet.hook.SMilletLogger
import de.robv.android.xposed.XposedHelpers

/**
 * 还原原模块 Landroid/support/v4/ร;、প 与 Ā 的深度 Doze 控制器与息屏耗电监控：
 * 1. 捕获 `com.android.server.DeviceIdleController` 实例。
 * 2. 息屏满 3 分钟 (`180_000L`) 通过 AlarmManager ("SMillet.Screen") 自动触发深度 Doze (`force-idle deep`)。
 * 3. 亮屏自动退出强制 Doze (`unforce`) 并统计息屏时长与耗电百分比 / mAh。
 * 4. 动态同步 `batteryOptWhiteSet` 与 `batteryOptBlackSet` 到 `DeviceIdleController`。
 */
object DozeControllerHelper {

    @Volatile
    var deviceIdleController: Any? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isForcedIdle = false
    private var screenOffTimestamp = 0L
    private var screenOffBatteryPct = 0
    private var screenOffBatteryCounter = 0

    private val deepDozeAlarmListener = AlarmManager.OnAlarmListener {
        if (SMilletLogger.config.enableDoze) {
            forceDeepDoze()
        }
    }

    fun onDeviceIdleStart(controller: Any) {
        deviceIdleController = controller
        applyBatteryOptimizationSets()
    }

    fun registerScreenReceiver(context: Context) {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val alarmManager = ctx.getSystemService(AlarmManager::class.java)
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        if (SMilletLogger.config.enableDoze && alarmManager != null) {
                            val triggerAt = SystemClock.elapsedRealtime() + 180_000L
                            alarmManager.setExact(
                                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                                triggerAt,
                                "SMillet.Screen",
                                deepDozeAlarmListener,
                                handler
                            )
                            if (SMilletLogger.config.dozeLog) {
                                SMilletLogger.info("[Doze]: 屏幕关闭，已设定 3 分钟后进入深度 Doze")
                            }
                        }
                        if (SMilletLogger.config.batteryChangeObserve) {
                            recordBatteryOnScreenOff(ctx)
                        }
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        alarmManager?.cancel(deepDozeAlarmListener)
                        if (isForcedIdle) {
                            unforceDeepDoze()
                        }
                        if (SMilletLogger.config.batteryChangeObserve) {
                            logBatteryDrainOnScreenOn(ctx)
                        }
                    }
                }
            }
        }
        context.registerReceiver(receiver, filter)
        SMilletLogger.info("已注册屏幕状态广播监听 (Screen ON/OFF)")
    }

    private fun forceDeepDoze() {
        val controller = deviceIdleController ?: return
        runCatching {
            XposedHelpers.callMethod(controller, "becomeInactiveIfAppropriateLocked")
            XposedHelpers.callMethod(controller, "stepIdleStateLocked", "s:shell")
            isForcedIdle = true
            if (SMilletLogger.config.dozeLog) {
                SMilletLogger.info("[Doze]: 已在息屏后强制进入深度 Doze (IDLE)")
            }
        }.onFailure {
            SMilletLogger.error("[Doze]: 触发深度 Doze 失败", it)
        }
    }

    private fun unforceDeepDoze() {
        val controller = deviceIdleController ?: return
        runCatching {
            XposedHelpers.callMethod(controller, "exitForceIdleLocked")
            isForcedIdle = false
            if (SMilletLogger.config.dozeLog) {
                SMilletLogger.info("[Doze]: 屏幕点亮，已退出强制深度 Doze")
            }
        }
    }

    /**
     * 还原原模块 প.Ԩ(): 将 batteryOptWhiteSet 加入省电白名单，将 batteryOptBlackSet 从系统/用户省电白名单移除
     */
    fun applyBatteryOptimizationSets() {
        val controller = deviceIdleController ?: return
        val cfg = SMilletLogger.config

        runCatching {
            if (cfg.batteryOptWhiteSet.isNotEmpty()) {
                XposedHelpers.callMethod(
                    controller,
                    "addPowerSaveWhitelistAppsInternal",
                    ArrayList(cfg.batteryOptWhiteSet)
                )
            }
            for (pkg in cfg.batteryOptBlackSet) {
                runCatching { XposedHelpers.callMethod(controller, "removePowerSaveWhitelistAppInternal", pkg) }
                runCatching { XposedHelpers.callMethod(controller, "removeSystemPowerWhitelistAppInternal", pkg) }
            }
        }.onFailure {
            SMilletLogger.error("同步电池优化白名单失败", it)
        }
    }

    private fun recordBatteryOnScreenOff(context: Context) {
        val bm = context.getSystemService(BatteryManager::class.java) ?: return
        screenOffTimestamp = System.currentTimeMillis()
        screenOffBatteryPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        screenOffBatteryCounter = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000
        SMilletLogger.info(
            "[电量统计-息屏]: 当前电量=${screenOffBatteryPct}%, 容量=${screenOffBatteryCounter}mAh"
        )
    }

    private fun logBatteryDrainOnScreenOn(context: Context) {
        if (screenOffTimestamp <= 0L) return
        val bm = context.getSystemService(BatteryManager::class.java) ?: return
        val durationMin = (System.currentTimeMillis() - screenOffTimestamp) / 60_000L
        val currentPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val currentMah = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000
        val diffPct = screenOffBatteryPct - currentPct
        val diffMah = screenOffBatteryCounter - currentMah
        SMilletLogger.info(
            "[电量统计-亮屏]: 息屏时长=${durationMin}分钟, 消耗电量=${diffPct}% (${diffMah}mAh), 当前剩余=${currentPct}% (${currentMah}mAh)"
        )
    }
}
