package com.sidesand.millet.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme

private val IconRunning: ImageVector by lazy {
    ImageVector.Builder("Running", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(13f, 3f); lineTo(6f, 14f); horizontalLineTo(11f)
            lineTo(11f, 21f); lineTo(18f, 10f); horizontalLineTo(13f); close()
        }
    }.build()
}

private val IconApps: ImageVector by lazy {
    ImageVector.Builder("Apps", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(4f, 4f); horizontalLineTo(10f); verticalLineTo(10f); horizontalLineTo(4f); close()
            moveTo(14f, 4f); horizontalLineTo(20f); verticalLineTo(10f); horizontalLineTo(14f); close()
            moveTo(4f, 14f); horizontalLineTo(10f); verticalLineTo(20f); horizontalLineTo(4f); close()
            moveTo(14f, 14f); horizontalLineTo(20f); verticalLineTo(20f); horizontalLineTo(14f); close()
        }
    }.build()
}

private val IconSettings: ImageVector by lazy {
    ImageVector.Builder("Settings", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(19.14f, 12.94f)
            lineTo(21.0f, 11.0f)
            lineTo(19.14f, 9.06f)
            lineTo(19.5f, 6.5f)
            lineTo(17.0f, 5.5f)
            lineTo(15.5f, 3.5f)
            lineTo(13.0f, 4.5f)
            lineTo(11.0f, 4.5f)
            lineTo(8.5f, 3.5f)
            lineTo(7.0f, 5.5f)
            lineTo(4.5f, 6.5f)
            lineTo(4.86f, 9.06f)
            lineTo(3.0f, 11.0f)
            lineTo(4.86f, 12.94f)
            lineTo(4.5f, 15.5f)
            lineTo(7.0f, 16.5f)
            lineTo(8.5f, 18.5f)
            lineTo(11.0f, 17.5f)
            lineTo(13.0f, 17.5f)
            lineTo(15.5f, 18.5f)
            lineTo(17.0f, 16.5f)
            lineTo(19.5f, 15.5f)
            close()
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(15.41f, 7.41f)
            lineTo(14.0f, 6.0f)
            lineTo(8.0f, 12.0f)
            lineTo(14.0f, 18.0f)
            lineTo(15.41f, 16.59f)
            lineTo(10.83f, 12.0f)
            close()
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }

    val config by viewModel.config.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val tabTitles = listOf("运行列表", "应用配置", "模块设置")

    BackHandler(enabled = selectedAppForConfig != null) {
        selectedAppForConfig = null
    }

    Scaffold(
        topBar = {
            val activeApp = selectedAppForConfig
            if (activeApp != null) {
                SmallTopAppBar(
                    title = activeApp.second,
                    navigationIcon = {
                        IconButton(onClick = { selectedAppForConfig = null }) {
                            Icon(
                                imageVector = IconBack,
                                contentDescription = "返回",
                                tint = MiuixTheme.colorScheme.onSurface
                            )
                        }
                    }
                )
            } else {
                SmallTopAppBar(
                    title = tabTitles[selectedTab]
                )
            }
        },
        bottomBar = {
            if (selectedAppForConfig == null) {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = IconRunning,
                        label = "运行列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = IconApps,
                        label = "应用配置"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = IconSettings,
                        label = "模块设置"
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val activeApp = selectedAppForConfig
            if (activeApp != null) {
                AppConfigDialog(
                    packageName = activeApp.first,
                    appName = activeApp.second,
                    config = config,
                    viewModel = viewModel,
                    onDismiss = { selectedAppForConfig = null }
                )
            } else {
                Crossfade(targetState = selectedTab, label = "MainTabs") { tab ->
                    when (tab) {
                        0 -> RunningListPage(
                            viewModel = viewModel,
                            isSystemActive = isSystemActive,
                            isPowerKeeperActive = isPkActive,
                            onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                            onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                        )
                        1 -> AppListPage(
                            viewModel = viewModel,
                            config = config,
                            onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name }
                        )
                        2 -> SettingsPage(
                            viewModel = viewModel,
                            config = config,
                            isSystemActive = isSystemActive,
                            isPowerKeeperActive = isPkActive
                        )
                    }
                }
            }

            // 注意：OverlayDialog 必须放在 Scaffold 内部作用域中才能挂载到 MiuixPopupHost
            diagnosticPair?.let { (pkg, reason) ->
                OverlayDialog(
                    show = true,
                    title = "未冻结原因诊断",
                    summary = pkg,
                    onDismissRequest = { viewModel.dismissDiagnosticDialog() }
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(text = reason)
                        Spacer(modifier = Modifier.height(16.dp))
                        TextButton(
                            text = "我知道了",
                            onClick = { viewModel.dismissDiagnosticDialog() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }
    }
}
