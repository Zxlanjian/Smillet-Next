package com.sidesand.millet.ui.pages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference

@Composable
fun SettingsPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    isSystemActive: Boolean,
    isPowerKeeperActive: Boolean
) {
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    var importFeedback by remember { mutableStateOf<String?>(null) }

    val logLevels = listOf("debug", "info", "warn", "error")
    val logTypes = listOf("xposed", "file")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Millet 墓碑核心设置
        item {
            SmallTitle(text = "Millet 墓碑机制增强")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "屏蔽 Millet 杀后台",
                        summary = "阻止电量与性能在锁屏超时或夜间自动清理后台进程",
                        checked = config.disableKill,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_KILL, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽充电解冻",
                        summary = "防止插拔充电器时唤醒全部已冻结的后台应用",
                        checked = config.disableCharge,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_CHARGE, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽音量键解冻",
                        summary = "防止按下音量加减键时连带解冻后台音频相关应用",
                        checked = config.disableVolume,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_VOLUME, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽省电白名单调整",
                        summary = "阻止电量与性能和睡眠模式动态重置系统省电白名单",
                        checked = config.blockAddPowerSaveWhitelistApps,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, it)
                        }
                    )
                    SwitchPreference(
                        title = "记录息屏电量变化",
                        summary = "在每次息屏与亮屏时自动统计待机时长与耗电毫安时",
                        checked = config.batteryChangeObserve,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, it)
                        }
                    )
                }
            }
        }

        // 2. 深度 Doze 优化设置
        item {
            SmallTitle(text = "深度 Doze 待机优化")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "息屏进入深度 Doze",
                        summary = "屏幕关闭满 3 分钟后自动触发深度睡眠，亮屏即刻恢复",
                        checked = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.ENABLE_DOZE, it) }
                    )
                    SwitchPreference(
                        title = "跳过状态检查进入 Doze",
                        summary = "跳过传感与定位等待阶段，直接切换至深度 IDLE 状态",
                        checked = config.skipStateCheck,
                        enabled = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SKIP_STATE_CHECK, it) }
                    )
                    SwitchPreference(
                        title = "避免运动退出深度 Doze",
                        summary = "屏蔽运动传感器唤醒，防止手机移动时退出深度待机",
                        checked = config.disableMotionListener,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, it)
                        }
                    )
                    SwitchPreference(
                        title = "开启 Doze 状态日志",
                        summary = "在日志中记录每次 Doze 状态机切换原因与目标状态",
                        checked = config.dozeLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DOZE_LOG, it) }
                    )
                }
            }
        }

        // 3. 日志与调试配置
        item {
            SmallTitle(text = "日志与调试")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "调试日志 (日常无需开启)",
                        summary = "输出完整的冻结、解冻与策略拦截调试日志",
                        checked = config.isLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.IS_LOG, it) }
                    )
                    SwitchPreference(
                        title = "简化冻结日志",
                        summary = "仅记录核心冻结与解冻事件并追踪进程启动与移除",
                        checked = config.simplifyLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SIMPLIFY_LOG, it) }
                    )
                    OverlayDropdownPreference(
                        title = "日志级别",
                        items = logLevels,
                        selectedIndex = logLevels.indexOf(config.logLevel).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_LEVEL, logLevels[idx])
                        }
                    )
                    OverlayDropdownPreference(
                        title = "日志输出方式",
                        items = listOf("LSPosed 框架日志", "本地文件 (/data/system/SMillet/log)"),
                        selectedIndex = logTypes.indexOf(config.logType).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_TYPE, logTypes[idx])
                        }
                    )
                }
            }
        }

        // 4. 配置备份与恢复
        item {
            SmallTitle(text = "备份与恢复")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                ArrowPreference(
                    title = "备份与恢复模块配置",
                    summary = "导出或导入 JSON 配置文件（兼容原版 SMillet Pro 备份格式）",
                    onClick = {
                        backupJsonText = viewModel.prefsManager.exportBackupJson()
                        importFeedback = null
                        showBackupDialog = true
                    }
                )
            }
        }
    }

    if (showBackupDialog) {
        OverlayDialog(
            show = true,
            title = "JSON 配置备份与恢复",
            summary = "复制下方 JSON 保存备份，或粘贴已有备份后点击「导入并应用」",
            onDismissRequest = { showBackupDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                TextField(
                    value = backupJsonText,
                    onValueChange = { backupJsonText = it },
                    label = "备份 JSON 内容",
                    modifier = Modifier.fillMaxWidth()
                )
                importFeedback?.let { msg ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = msg)
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        text = "关闭",
                        onClick = { showBackupDialog = false },
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        text = "导入并应用",
                        onClick = {
                            val ok = viewModel.prefsManager.importBackupJson(backupJsonText)
                            if (ok) {
                                viewModel.reloadSnapshot()
                                importFeedback = "导入成功，已实时同步至系统框架与电量与性能"
                            } else {
                                importFeedback = "JSON 格式解析失败，请检查内容是否完整"
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    }
}
