package com.sidesand.millet.data

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import de.robv.android.xposed.XSharedPreferences

/**
 * 统一管理 UI 端 SharedPreferences 与 Hook 端 XSharedPreferences，
 * 移除了原版 libtestverify.so 联网设备码鉴权限制，全部高级功能直接可用。
 */
class PrefsManager(private val prefs: SharedPreferences?) {

    @SuppressLint("WorldReadableFiles")
    companion object {
        private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

        fun fromContext(context: Context): PrefsManager {
            val sp = try {
                @Suppress("DEPRECATION")
                context.getSharedPreferences(ConfigKeys.PREFS_NAME, Context.MODE_WORLD_READABLE)
            } catch (_: SecurityException) {
                // 当模块未被 LSPosed 接管 xposedsharedprefs 时回退为 MODE_PRIVATE
                context.getSharedPreferences(ConfigKeys.PREFS_NAME, Context.MODE_PRIVATE)
            }
            return PrefsManager(sp)
        }

        fun loadFromXposed(): MilletConfigSnapshot {
            val xsp = XSharedPreferences("com.sidesand.millet", ConfigKeys.PREFS_NAME)
            xsp.makeWorldReadable()
            xsp.reload()
            return readSnapshot(xsp)
        }

        fun readSnapshot(sp: SharedPreferences): MilletConfigSnapshot {
            return MilletConfigSnapshot(
                isLog = sp.getBoolean(ConfigKeys.IS_LOG, false),
                simplifyLog = sp.getBoolean(ConfigKeys.SIMPLIFY_LOG, false),
                disableKill = sp.getBoolean(ConfigKeys.DISABLE_KILL, true),
                disableVolume = sp.getBoolean(ConfigKeys.DISABLE_VOLUME, true),
                disableCharge = sp.getBoolean(ConfigKeys.DISABLE_CHARGE, true),
                blockAddPowerSaveWhitelistApps = sp.getBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, true),
                batteryChangeObserve = sp.getBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, false),
                logToLocal = sp.getBoolean(ConfigKeys.LOG_TO_LOCAL, false),
                dozeLog = sp.getBoolean(ConfigKeys.DOZE_LOG, false),
                enableDoze = sp.getBoolean(ConfigKeys.ENABLE_DOZE, true),
                skipStateCheck = sp.getBoolean(ConfigKeys.SKIP_STATE_CHECK, true),
                disableMotionListener = sp.getBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, true),
                batteryOptWhiteSet = sp.getStringSet(ConfigKeys.BATTERY_OPT_WHITE_SET, emptySet())?.toSet() ?: emptySet(),
                batteryOptBlackSet = sp.getStringSet(ConfigKeys.BATTERY_OPT_BLACK_SET, emptySet())?.toSet() ?: emptySet(),
                whiteAppSet = sp.getStringSet(ConfigKeys.WHITE_APP_SET, emptySet())?.toSet() ?: emptySet(),
                messageAppSet = sp.getStringSet(ConfigKeys.MESSAGE_APP_SET, ConfigKeys.DEFAULT_MESSAGE_APPS)?.toSet() ?: ConfigKeys.DEFAULT_MESSAGE_APPS,
                forceFreezeSet = sp.getStringSet(ConfigKeys.FORCE_FREEZE_SET, emptySet())?.toSet() ?: emptySet(),
                blockThawSet = sp.getStringSet(ConfigKeys.BLOCK_THAW_SET, emptySet())?.toSet() ?: emptySet(),
                forbidSyncBinderSet = sp.getStringSet(ConfigKeys.FORBID_SYNC_BINDER_SET, emptySet())?.toSet() ?: emptySet(),
                notFreezeWhenHasFgsSet = sp.getStringSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, emptySet())?.toSet() ?: emptySet(),
                logLevel = sp.getString(ConfigKeys.LOG_LEVEL, "info") ?: "info",
                logType = sp.getString(ConfigKeys.LOG_TYPE, "xposed") ?: "xposed"
            )
        }
    }

    val isReady: Boolean get() = prefs != null

    fun snapshot(): MilletConfigSnapshot {
        val sp = prefs ?: return MilletConfigSnapshot()
        return readSnapshot(sp)
    }

    fun getBoolean(key: String, default: Boolean): Boolean =
        prefs?.getBoolean(key, default) ?: default

    fun putBoolean(key: String, value: Boolean) {
        prefs?.edit()?.putBoolean(key, value)?.apply()
    }

    fun getString(key: String, default: String): String =
        prefs?.getString(key, default) ?: default

    fun putString(key: String, value: String) {
        prefs?.edit()?.putString(key, value)?.apply()
    }

    fun getStringSet(key: String, default: Set<String> = emptySet()): Set<String> =
        prefs?.getStringSet(key, default)?.toSet() ?: default

    fun putStringSet(key: String, value: Set<String>) {
        prefs?.edit()?.putStringSet(key, HashSet(value))?.apply()
    }

    fun updateAppSet(key: String, packageName: String, add: Boolean): Set<String> {
        val current = getStringSet(key).toMutableSet()
        if (add) current.add(packageName) else current.remove(packageName)
        putStringSet(key, current)
        return current
    }

    /**
     * 导出与原模块 BackupConfigPage 100% 兼容的分组 JSON 结构
     */
    fun exportBackupJson(): String {
        val s = snapshot()
        val root = JsonObject().apply {
            add("MilletSettings", gson.toJsonTree(mapOf(
                ConfigKeys.IS_LOG to s.isLog,
                ConfigKeys.SIMPLIFY_LOG to s.simplifyLog,
                ConfigKeys.DISABLE_KILL to s.disableKill,
                ConfigKeys.DISABLE_VOLUME to s.disableVolume,
                ConfigKeys.DISABLE_CHARGE to s.disableCharge,
                ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST to s.blockAddPowerSaveWhitelistApps,
                ConfigKeys.BATTERY_CHANGE_OBSERVE to s.batteryChangeObserve,
                ConfigKeys.LOG_TO_LOCAL to s.logToLocal
            )))
            add("DozeSettings", gson.toJsonTree(mapOf(
                ConfigKeys.DOZE_LOG to s.dozeLog,
                ConfigKeys.ENABLE_DOZE to s.enableDoze,
                ConfigKeys.SKIP_STATE_CHECK to s.skipStateCheck,
                ConfigKeys.DISABLE_MOTION_LISTENER to s.disableMotionListener
            )))
            add("BatteryOptSettings", gson.toJsonTree(mapOf(
                ConfigKeys.BATTERY_OPT_WHITE_SET to s.batteryOptWhiteSet,
                ConfigKeys.BATTERY_OPT_BLACK_SET to s.batteryOptBlackSet
            )))
            add("AppSettings", gson.toJsonTree(mapOf(
                ConfigKeys.WHITE_APP_SET to s.whiteAppSet,
                ConfigKeys.MESSAGE_APP_SET to s.messageAppSet,
                ConfigKeys.FORCE_FREEZE_SET to s.forceFreezeSet,
                ConfigKeys.BLOCK_THAW_SET to s.blockThawSet,
                ConfigKeys.FORBID_SYNC_BINDER_SET to s.forbidSyncBinderSet,
                ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET to s.notFreezeWhenHasFgsSet
            )))
            add("LogSettings", gson.toJsonTree(mapOf(
                ConfigKeys.LOG_LEVEL to s.logLevel,
                ConfigKeys.LOG_TYPE to s.logType
            )))
        }
        return gson.toJson(root)
    }

    /**
     * 从原模块或本模块导出的 JSON 恢复配置
     */
    fun importBackupJson(jsonText: String): Boolean {
        val sp = prefs ?: return false
        return try {
            val root = gson.fromJson(jsonText, JsonObject::class.java)
            val editor = sp.edit()

            root.getAsJsonObject("MilletSettings")?.let { obj ->
                obj.get(ConfigKeys.IS_LOG)?.asBoolean?.let { editor.putBoolean(ConfigKeys.IS_LOG, it) }
                obj.get(ConfigKeys.SIMPLIFY_LOG)?.asBoolean?.let { editor.putBoolean(ConfigKeys.SIMPLIFY_LOG, it) }
                obj.get(ConfigKeys.DISABLE_KILL)?.asBoolean?.let { editor.putBoolean(ConfigKeys.DISABLE_KILL, it) }
                obj.get(ConfigKeys.DISABLE_VOLUME)?.asBoolean?.let { editor.putBoolean(ConfigKeys.DISABLE_VOLUME, it) }
                obj.get(ConfigKeys.DISABLE_CHARGE)?.asBoolean?.let { editor.putBoolean(ConfigKeys.DISABLE_CHARGE, it) }
                obj.get(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST)?.asBoolean?.let {
                    editor.putBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, it)
                }
                obj.get(ConfigKeys.BATTERY_CHANGE_OBSERVE)?.asBoolean?.let {
                    editor.putBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, it)
                }
                obj.get(ConfigKeys.LOG_TO_LOCAL)?.asBoolean?.let { editor.putBoolean(ConfigKeys.LOG_TO_LOCAL, it) }
            }

            root.getAsJsonObject("DozeSettings")?.let { obj ->
                obj.get(ConfigKeys.DOZE_LOG)?.asBoolean?.let { editor.putBoolean(ConfigKeys.DOZE_LOG, it) }
                obj.get(ConfigKeys.ENABLE_DOZE)?.asBoolean?.let { editor.putBoolean(ConfigKeys.ENABLE_DOZE, it) }
                obj.get(ConfigKeys.SKIP_STATE_CHECK)?.asBoolean?.let { editor.putBoolean(ConfigKeys.SKIP_STATE_CHECK, it) }
                obj.get(ConfigKeys.DISABLE_MOTION_LISTENER)?.asBoolean?.let {
                    editor.putBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, it)
                }
            }

            fun parseSet(parent: JsonObject?, key: String): Set<String>? {
                val arr = parent?.getAsJsonArray(key) ?: return null
                return arr.mapNotNull { it.asString }.toSet()
            }

            root.getAsJsonObject("BatteryOptSettings")?.let { obj ->
                parseSet(obj, ConfigKeys.BATTERY_OPT_WHITE_SET)?.let { editor.putStringSet(ConfigKeys.BATTERY_OPT_WHITE_SET, it) }
                parseSet(obj, ConfigKeys.BATTERY_OPT_BLACK_SET)?.let { editor.putStringSet(ConfigKeys.BATTERY_OPT_BLACK_SET, it) }
            }

            root.getAsJsonObject("AppSettings")?.let { obj ->
                parseSet(obj, ConfigKeys.WHITE_APP_SET)?.let { editor.putStringSet(ConfigKeys.WHITE_APP_SET, it) }
                parseSet(obj, ConfigKeys.MESSAGE_APP_SET)?.let { editor.putStringSet(ConfigKeys.MESSAGE_APP_SET, it) }
                parseSet(obj, ConfigKeys.FORCE_FREEZE_SET)?.let { editor.putStringSet(ConfigKeys.FORCE_FREEZE_SET, it) }
                parseSet(obj, ConfigKeys.BLOCK_THAW_SET)?.let { editor.putStringSet(ConfigKeys.BLOCK_THAW_SET, it) }
                parseSet(obj, ConfigKeys.FORBID_SYNC_BINDER_SET)?.let { editor.putStringSet(ConfigKeys.FORBID_SYNC_BINDER_SET, it) }
                parseSet(obj, ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET)?.let { editor.putStringSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, it) }
            }

            root.getAsJsonObject("LogSettings")?.let { obj ->
                obj.get(ConfigKeys.LOG_LEVEL)?.asString?.let { editor.putString(ConfigKeys.LOG_LEVEL, it) }
                obj.get(ConfigKeys.LOG_TYPE)?.asString?.let { editor.putString(ConfigKeys.LOG_TYPE, it) }
            }

            editor.commit()
            true
        } catch (e: Throwable) {
            false
        }
    }
}
