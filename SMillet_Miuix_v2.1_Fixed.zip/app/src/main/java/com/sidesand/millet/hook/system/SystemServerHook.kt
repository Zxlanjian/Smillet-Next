package com.sidesand.millet.hook.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.util.ArraySet
import com.google.gson.Gson
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import java.io.File

object SystemServerHook {

    data class SysProcEntry(
        val pid: Int,
        val uid: Int,
        val processName: String,
        val rssKb: Long,
        val wchan: String,
        val state: String,
        val isFrozenByGreeze: Boolean
    )

    private val gson = Gson()

    @Volatile
    var greezeManagerService: Any? = null
        private set

    @Volatile
    var aurogonImmobulusMode: Any? = null
        private set

    @Volatile
    var amsInstance: Any? = null
        private set

    @Volatile
    var systemContext: Context? = null
        private set

    @Volatile
    private var lastToFrontPkg: String? = null

    fun init(classLoader: ClassLoader) {
        reloadConfig("ALL")

        hookAmsBinderBridge(classLoader)
        hookGreezeManagerService(classLoader)
        hookAurogonImmobulusMode(classLoader)
        hookAnrSuppression(classLoader)
        hookBroadcastSkipForFrozenApp(classLoader)
        hookDeviceIdleController(classLoader)

        SMilletLogger.info("system_server 全部 Hook 初始化完成 (SDK=${Build.VERSION.SDK_INT})")
    }

    fun reloadConfig(changedKey: String) {
        val snapshot = PrefsManager.loadFromXposed()
        SMilletLogger.config = snapshot
        if (changedKey == "ALL" || changedKey == ConfigKeys.MESSAGE_APP_SET) {
            syncMessageAppsToAurogon()
        }
        if (changedKey == "ALL" ||
            changedKey == ConfigKeys.BATTERY_OPT_WHITE_SET ||
            changedKey == ConfigKeys.BATTERY_OPT_BLACK_SET
        ) {
            DozeControllerHelper.applyBatteryOptimizationSets()
        }
    }

    /**
     * 直接在 system_server (UID 1000) 内收集所有运行中/已冻结的应用进程，
     * 结合 ActivityManager、GreezeManagerService.isUidFrozen(uid) 以及 /proc/<pid>/status 与 wchan。
     */
    fun collectRunningProcessesJson(includeSystem: Boolean): String {
        val token = Binder.clearCallingIdentity()
        return try {
            val ctx = getSystemContext() ?: return "[]"
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return "[]"
            val runningList = am.runningAppProcesses ?: emptyList()
            val entries = ArrayList<SysProcEntry>(runningList.size)

            for (procInfo in runningList) {
                val pid = procInfo.pid
                val uid = procInfo.uid
                if (pid <= 0) continue
                val appId = uid % 100000
                if (!includeSystem && appId < 10000) continue

                val isFrozen = isUidFrozen(uid)
                val wchan = readProcWchan(pid, isFrozen)
                val (state, rssKb) = readProcStateAndRss(pid, am)

                entries.add(
                    SysProcEntry(
                        pid = pid,
                        uid = uid,
                        processName = procInfo.processName ?: "pid:$pid",
                        rssKb = rssKb,
                        wchan = wchan,
                        state = state,
                        isFrozenByGreeze = isFrozen
                    )
                )
            }
            gson.toJson(entries)
        } catch (t: Throwable) {
            SMilletLogger.error("collectRunningProcessesJson 异常", t)
            "[]"
        } finally {
            Binder.restoreCallingIdentity(token)
        }
    }

    private fun readProcWchan(pid: Int, isFrozenByGreeze: Boolean): String {
        val raw = runCatching {
            File("/proc/$pid/wchan").readText().trim()
        }.getOrNull().orEmpty()
        if (raw.isNotEmpty() && raw != "0" && raw != "-") {
            return raw
        }
        return if (isFrozenByGreeze) "do_freezer_trap" else "ep_poll"
    }

    private fun readProcStateAndRss(pid: Int, am: ActivityManager): Pair<String, Long> {
        var state = "S"
        var rssKb = 0L
        runCatching {
            val statusFile = File("/proc/$pid/status")
            if (statusFile.exists()) {
                statusFile.forEachLine { line ->
                    when {
                        line.startsWith("State:") -> {
                            state = line.substringAfter("State:").trim().take(1)
                        }
                        line.startsWith("VmRSS:") -> {
                            val num = line.substringAfter("VmRSS:").trim().split(Regex("\\s+")).firstOrNull()
                            rssKb = num?.toLongOrNull() ?: 0L
                        }
                    }
                }
            }
        }
        if (rssKb <= 0L) {
            runCatching {
                val memInfo = am.getProcessMemoryInfo(intArrayOf(pid))
                if (memInfo != null && memInfo.isNotEmpty()) {
                    rssKb = memInfo[0].totalPss.toLong()
                }
            }
        }
        return state to rssKb
    }

    private fun hookAmsBinderBridge(classLoader: ClassLoader) {
        val amsClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.ActivityManagerService",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(amsClass, "setSystemProcess", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                amsInstance = param.thisObject
            }
        })

        XposedBridge.hookAllMethods(amsClass, "registerReceiverWithFeature", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val filter = param.args.firstOrNull { it is IntentFilter } as? IntentFilter ?: return
                if (filter.hasAction(ConfigKeys.BINDER_ACTION)) {
                    if (amsInstance == null) {
                        amsInstance = param.thisObject
                    }
                    val replyIntent = Intent()
                    val bundle = Bundle()
                    bundle.putBinder(ConfigKeys.BINDER_KEY_SYSTEM, SystemServerService)
                    replyIntent.putExtras(bundle)
                    param.result = replyIntent
                }
            }
        })
    }

    private fun hookGreezeManagerService(classLoader: ClassLoader) {
        val gmsClass = XposedHelpers.findClassIfExists(
            "com.miui.server.greeze.GreezeManagerService",
            classLoader
        ) ?: return

        XposedBridge.hookAllConstructors(gmsClass, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) {
                    greezeManagerService = param.thisObject
                }
                val ctx = param.args.firstOrNull { it is Context } as? Context
                if (ctx != null) {
                    systemContext = ctx
                    runCatching { DozeControllerHelper.registerScreenReceiver(ctx) }
                }
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "freezeAction", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: ""
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (cfg.whiteAppSet.contains(pkg)) {
                    SMilletLogger.debug("freezeAction 拦截: 白名单应用 [$pkg] 不冻结")
                    param.result = false
                    return
                }

                if (reason != "LAUNCH_MODE" && cfg.notFreezeWhenHasFgsSet.contains(pkg)) {
                    val hasFgs = checkAppHasForegroundService(uid)
                    if (hasFgs) {
                        SMilletLogger.debug("freezeAction 拦截: [$pkg] 具有前台服务，跳过冻结")
                        param.result = false
                    }
                }
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "thawUid", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (reason == "tofront") {
                    lastToFrontPkg = pkg
                    return
                }
                if (reason == "screen on" && pkg == lastToFrontPkg) {
                    return
                }

                if (isUidFrozen(uid) && (reason == "broadcast" || reason == "Broadcast") && !cfg.whiteAppSet.contains(pkg)) {
                    param.result = false
                    return
                }

                if ((reason == "Sync Binder" || reason == "Check Binder") && cfg.forbidSyncBinderSet.contains(pkg)) {
                    SMilletLogger.info("--系统[解冻uid]: 禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                    return
                }

                if (cfg.blockThawSet.contains(pkg) && !ConfigKeys.ALLOWED_THAW_REASONS.contains(reason)) {
                    SMilletLogger.info("--系统[解冻uid]: 强力压制，禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                }
            }
        })

        XposedBridge.hookAllMethods(gmsClass, "freezeUids", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                if (!SMilletLogger.config.isLog && !SMilletLogger.config.simplifyLog) return
                val uids = param.args.getOrNull(0) as? IntArray ?: return
                val reason = param.args.getOrNull(3) as? String ?: ""
                if (uids.isEmpty()) return
                val names = uids.joinToString(",") { uid -> "${getPackageNameForUid(uid) ?: uid}@$uid" }
                SMilletLogger.info("++系统[冻结Uids]: 原因=[$reason], 列表=[$names]")
            }
        })
    }

    private fun hookAurogonImmobulusMode(classLoader: ClassLoader) {
        val aurogonClass = XposedHelpers.findClassIfExists(
            "com.miui.server.greeze.AurogonImmobulusMode",
            classLoader
        ) ?: return

        XposedBridge.hookAllConstructors(aurogonClass, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (aurogonImmobulusMode == null) {
                    aurogonImmobulusMode = param.thisObject
                }
                syncMessageAppsToAurogon()
            }
        })

        XposedBridge.hookAllMethods(aurogonClass, "checkAppStatusForFreeze", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val appInfo = param.args.getOrNull(0) ?: return
                val pkg = runCatching {
                    XposedHelpers.getObjectField(appInfo, "mPackageName") as? String
                }.getOrNull() ?: return
                if (SMilletLogger.config.whiteAppSet.contains(pkg)) {
                    param.result = false
                }
            }
        })
    }

    @Suppress("UNCHECKED_CAST")
    private fun syncMessageAppsToAurogon() {
        val instance = aurogonImmobulusMode ?: return
        val msgApps = SMilletLogger.config.messageAppSet
        runCatching {
            val fieldObj = XposedHelpers.getObjectField(instance, "mMessageApp")
            when (fieldObj) {
                is MutableList<*> -> {
                    val list = fieldObj as MutableList<String>
                    list.clear()
                    list.addAll(msgApps)
                }
                is ArraySet<*> -> {
                    val set = fieldObj as ArraySet<String>
                    set.clear()
                    set.addAll(msgApps)
                }
                else -> {
                    XposedHelpers.setObjectField(instance, "mMessageApp", ArrayList(msgApps))
                }
            }
        }
    }

    private fun hookAnrSuppression(classLoader: ClassLoader) {
        val anrHelperClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.AnrHelper",
            classLoader
        )
        if (anrHelperClass != null) {
            val anrHook = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val processRecord = param.args.getOrNull(0) ?: return
                    val uid = runCatching { XposedHelpers.getIntField(processRecord, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        param.result = null
                    }
                }
            }
            XposedBridge.hookAllMethods(anrHelperClass, "appNotResponding", anrHook)
            XposedBridge.hookAllMethods(anrHelperClass, "deferAppNotResponding", anrHook)
        }

        val errStateClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.ProcessErrorStateRecord",
            classLoader
        )
        if (errStateClass != null) {
            XposedBridge.hookAllMethods(errStateClass, "appNotResponding", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val app = runCatching { XposedHelpers.getObjectField(param.thisObject, "mApp") }.getOrNull() ?: return
                    val uid = runCatching { XposedHelpers.getIntField(app, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        param.result = null
                    }
                }
            })
        }
    }

    private fun hookBroadcastSkipForFrozenApp(classLoader: ClassLoader) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU) {
            val bqClass = XposedHelpers.findClassIfExists(
                "com.android.server.am.BroadcastQueue",
                classLoader
            ) ?: return
            XposedBridge.hookAllMethods(bqClass, "deliverToRegisteredReceiverLocked", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedHelpers.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedHelpers.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = null
                    }
                }
            })
        } else {
            val skipPolicyClass = XposedHelpers.findClassIfExists(
                "com.android.server.am.BroadcastSkipPolicy",
                classLoader
            ) ?: return
            XposedBridge.hookAllMethods(skipPolicyClass, "shouldSkipMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedHelpers.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedHelpers.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = "Skip frozen process by SMillet"
                    }
                }
            })
        }
    }

    private fun shouldSkipFrozenProcess(processRecord: Any): Boolean {
        val uid = runCatching { XposedHelpers.getIntField(processRecord, "uid") }.getOrNull() ?: return false
        if (uid < 10000) return false
        if (!isUidFrozen(uid)) return false
        val pkg = getPackageNameForUid(uid) ?: return false
        return !SMilletLogger.config.whiteAppSet.contains(pkg)
    }

    private fun hookDeviceIdleController(classLoader: ClassLoader) {
        val dicClass = XposedHelpers.findClassIfExists(
            "com.android.server.DeviceIdleController",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(dicClass, "onStart", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                DozeControllerHelper.onDeviceIdleStart(param.thisObject)
            }
        })

        XposedBridge.hookAllMethods(dicClass, "motionLocked", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                if (cfg.disableMotionListener) {
                    param.result = null
                    runCatching { XposedHelpers.setBooleanField(param.thisObject, "mNotMoving", true) }
                }
            }
        })

        XposedBridge.hookAllMethods(dicClass, "moveToStateLocked", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                val targetState = param.args.getOrNull(0) as? Int ?: return
                if (cfg.enableDoze && cfg.skipStateCheck && targetState in 2..4) {
                    param.args[0] = 5
                    param.args[1] = "SMilletSkip"
                    runCatching { XposedHelpers.callMethod(param.thisObject, "resetIdleManagementLocked") }
                }
            }
        })
    }

    fun isUidFrozen(uid: Int): Boolean {
        val gms = greezeManagerService ?: return false
        return runCatching {
            XposedHelpers.callMethod(gms, "isUidFrozen", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    private fun checkAppHasForegroundService(uid: Int): Boolean {
        val aurogon = aurogonImmobulusMode ?: return false
        return runCatching {
            XposedHelpers.callMethod(aurogon, "checkAppFgService", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    private fun getSystemContext(): Context? {
        systemContext?.let { return it }
        val ams = amsInstance ?: return null
        return runCatching {
            (XposedHelpers.getObjectField(ams, "mContext") as? Context)?.also { systemContext = it }
        }.getOrNull()
    }

    private fun getPackageNameForUid(uid: Int): String? {
        val ctx = getSystemContext() ?: return null
        return runCatching {
            ctx.packageManager.getPackagesForUid(uid)?.firstOrNull()
        }.getOrNull()
    }
}
