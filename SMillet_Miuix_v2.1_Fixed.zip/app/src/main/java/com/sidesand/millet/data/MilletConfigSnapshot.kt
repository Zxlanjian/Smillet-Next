package com.sidesand.millet.data

/**
 * 供 Hook 层与备份导出使用的不可变/可变配置快照，对应原模块 Landroid/support/v4/ध;。
 */
data class MilletConfigSnapshot(
    var isLog: Boolean = false,
    var simplifyLog: Boolean = false,
    var disableKill: Boolean = true,
    var disableVolume: Boolean = true,
    var disableCharge: Boolean = true,
    var blockAddPowerSaveWhitelistApps: Boolean = true,
    var batteryChangeObserve: Boolean = false,
    var logToLocal: Boolean = false,
    var dozeLog: Boolean = false,
    var enableDoze: Boolean = true,
    var skipStateCheck: Boolean = true,
    var disableMotionListener: Boolean = true,
    var batteryOptWhiteSet: Set<String> = emptySet(),
    var batteryOptBlackSet: Set<String> = emptySet(),
    var whiteAppSet: Set<String> = emptySet(),
    var messageAppSet: Set<String> = ConfigKeys.DEFAULT_MESSAGE_APPS,
    var forceFreezeSet: Set<String> = emptySet(),
    var blockThawSet: Set<String> = emptySet(),
    var forbidSyncBinderSet: Set<String> = emptySet(),
    var notFreezeWhenHasFgsSet: Set<String> = emptySet(),
    var logLevel: String = "info",
    var logType: String = "xposed"
)
