package com.sidesand.millet.hook.powerkeeper

import android.app.Application
import android.content.Context
import android.os.Message
import android.provider.Settings
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import com.sidesand.millet.ipc.BinderBridge
import com.sidesand.millet.ipc.ISystemCallback
import com.sidesand.millet.ipc.SystemInterface
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

/**
 * 完整还原原模块针对 `com.miui.powerkeeper` (电量与性能) 的全部 19 个 Hook 点：
 * 1. PowerKeeperApplication#onCreate -> 绑定 system_server 的 SMillet-Binder 服务并注册回调
 * 2. MilletPolicy 构造、dealCloudWhiteList、onCloudWhiteListChanged、dealNoRestrictApp、dealSleepModeWhiteList
 *    -> 拦截云控白名单覆盖，强制注入自定义白名单 (`whiteAppSet`)、黑名单 (`forceFreezeSet`)、消息应用 (`messageAppSet`)
 * 3. MilletHandler#handleMessage -> 阻止充电状态变更解冻 (`what == 13, arg1 == 16`) 与同步 Binder 解冻
 * 4. MilletBrightHandler#handleMessage -> 阻止音量键解冻 (`eventcode == 24 || 25`)
 * 5. CommonAdapter#addPowerSaveWhitelistApps / removePowerSaveWhitelistApps -> 阻止篡改系统省电白名单
 * 6. PowerCheckerController#clearApp & PowerStateMachine#clearApp* -> 阻止电量与性能后台杀进程
 * 7. 未冻结原因全链路诊断器 (还原原模块 Landroid/support/v4/ʴ;)
 */
object PowerKeeperHook {

    @Volatile
    var appContext: Context? = null
        private set

    @Volatile
    var systemService: SystemInterface? = null
        private set

    @Volatile
    var milletPolicyInstance: Any? = null
        private set

    @Volatile
    var brightScenarioInstance: Any? = null
        private set

    @Volatile
    var freezeBinderInstance: Any? = null
        private set

    @Volatile
    var bluetoothEventInstance: Any? = null
        private set

    private val pkCallback = object : ISystemCallback.Stub() {
        override fun onConfigChanged(key: String) {
            SMilletLogger.config = PrefsManager.loadFromXposed()
            applyMilletPolicyLists()
            applyBrightPreloadWhitelist()
        }

        override fun requestCheckFreezeReason(packageName: String) {
            val report = diagnoseUnfreezeReason(packageName)
            systemService?.reportUnfreezeReason(packageName, report)
        }

        override fun onFreezeReasonResult(packageName: String, reason: String) {}
    }

    fun init(classLoader: ClassLoader) {
        SMilletLogger.config = PrefsManager.loadFromXposed()

        hookPowerKeeperApplication(classLoader)
        hookMilletPolicy(classLoader)
        hookMilletHandlers(classLoader)
        hookPowerSaveWhitelistAdapter(classLoader)
        hookBackgroundKillers(classLoader)
        hookHelperInstances(classLoader)

        SMilletLogger.info("com.miui.powerkeeper 全部 Hook 初始化完成")
    }

    /**
     * Hook 1: PowerKeeperApplication#onCreate -> 连接 SMillet-Binder 服务
     */
    private fun hookPowerKeeperApplication(classLoader: ClassLoader) {
        val appClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.PowerKeeperApplication",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(appClass, "onCreate", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val app = param.thisObject as? Application ?: return
                appContext = app
                val binder = BinderBridge.fetchSystemInterface(app)
                if (binder != null && binder.isSystemHookActive()) {
                    systemService = binder
                    binder.registerCallback(pkCallback, "PowerKeeper")
                    runCatching {
                        val noRestrict = Settings.System.getString(app.contentResolver, "MILLET_NO_RESTRICT_APP")
                        binder.syncNoRestrictApps(noRestrict)
                    }
                    SMilletLogger.info("电量与性能绑定 system_server 服务成功")
                } else {
                    SMilletLogger.warn("电量与性能绑定 system_server 服务为空")
                }
            }
        })
    }

    /**
     * Hook 2: MilletPolicy 云控拦截与自定义名单注入 (还原原模块 Landroid/support/v4/ח;)
     */
    private fun hookMilletPolicy(classLoader: ClassLoader) {
        val policyClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.MilletPolicy",
            classLoader
        ) ?: return

        XposedBridge.hookAllConstructors(policyClass, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                milletPolicyInstance = param.thisObject
                // 清空默认音乐应用豁免列表，交由模块精细接管
                runCatching {
                    val musicList = XposedHelpers.getStaticObjectField(policyClass, "musicApp") as? MutableList<*>
                    musicList?.clear()
                }
                applyMilletPolicyLists()
            }
        })

        // 拦截云控白名单覆盖
        XposedBridge.hookAllMethods(policyClass, "dealCloudWhiteList", XC_MethodReplacement.DO_NOTHING)
        XposedBridge.hookAllMethods(policyClass, "onCloudWhiteListChanged", XC_MethodReplacement.DO_NOTHING)

        // 拦截睡眠模式修改省电白名单
        XposedBridge.hookAllMethods(policyClass, "dealSleepModeWhiteList", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                param.result = null
            }
        })

        // 监听无限制应用变更并重新覆盖自定义列表
        XposedBridge.hookAllMethods(policyClass, "dealNoRestrictApp", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                applyMilletPolicyLists()
                appContext?.let { ctx ->
                    runCatching {
                        val noRestrict = Settings.System.getString(ctx.contentResolver, "MILLET_NO_RESTRICT_APP")
                        systemService?.syncNoRestrictApps(noRestrict)
                    }
                }
            }
        })
    }

    /**
     * 还原原模块 ח.ԭ(): 将自定义配置注入 MilletPolicy 的静态/实例字段
     */
    @Suppress("UNCHECKED_CAST")
    fun applyMilletPolicyLists() {
        val policy = milletPolicyInstance ?: return
        val policyClass = policy.javaClass
        val cfg = SMilletLogger.config

        runCatching {
            // 1. 同步消息应用 MESSAGE_APPS
            (XposedHelpers.getStaticObjectField(policyClass, "MESSAGE_APPS") as? MutableCollection<String>)?.apply {
                clear()
                addAll(cfg.messageAppSet)
            }

            // 2. 从内置白名单移除强制冻结应用 (forceFreezeSet)
            (XposedHelpers.getStaticObjectField(policyClass, "BRIGHT_WHITE_APPS") as? MutableCollection<String>)
                ?.removeAll(cfg.forceFreezeSet)
            (XposedHelpers.getStaticObjectField(policyClass, "whiteApps") as? MutableCollection<String>)
                ?.removeAll(cfg.forceFreezeSet)
            (XposedHelpers.getObjectField(policy, "mDataWhiteList") as? MutableCollection<String>)
                ?.removeAll(cfg.forceFreezeSet)

            // 3. 设置系统级强制冻结黑名单 mUseSystemBlackList 与自定义白名单 mUseDataWhiteList
            (XposedHelpers.getObjectField(policy, "mUseSystemBlackList") as? MutableCollection<String>)?.apply {
                clear()
                addAll(cfg.forceFreezeSet)
            }
            (XposedHelpers.getObjectField(policy, "mUseDataWhiteList") as? MutableCollection<String>)?.apply {
                clear()
                addAll(cfg.whiteAppSet)
            }
        }.onFailure {
            SMilletLogger.error("注入 MilletPolicy 名单失败", it)
        }
    }

    /**
     * Hook 3: MilletHandler & MilletBrightHandler 阻止充电解冻、音量键解冻与同步 Binder 解冻
     */
    private fun hookMilletHandlers(classLoader: ClassLoader) {
        val milletHandlerClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.MilletHandler",
            classLoader
        )
        if (milletHandlerClass != null) {
            XposedBridge.hookAllMethods(milletHandlerClass, "handleMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val msg = param.args.getOrNull(0) as? Message ?: return
                    val cfg = SMilletLogger.config

                    // what == 13 && arg1 == 16: 充电状态变化触发全量解冻
                    if (msg.what == 13 && msg.arg1 == 16 && cfg.disableCharge) {
                        SMilletLogger.debug("MilletHandler: 已阻止充电状态变化触发解冻")
                        param.result = null
                    }
                }
            })
        }

        val brightHandlerClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.bright.MilletBrightHandler",
            classLoader
        )
        if (brightHandlerClass != null) {
            XposedBridge.hookAllMethods(brightHandlerClass, "handleMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val msg = param.args.getOrNull(0) as? Message ?: return
                    val cfg = SMilletLogger.config
                    val data = msg.data ?: return
                    val eventCode = data.getInt("eventcode", -1)
                    // eventcode 24 (VOLUME_UP) / 25 (VOLUME_DOWN)
                    if ((eventCode == 24 || eventCode == 25) && cfg.disableVolume) {
                        SMilletLogger.debug("MilletBrightHandler: 已阻止音量键 ($eventCode) 触发解冻")
                        param.result = null
                    }
                }
            })
        }
    }

    /**
     * Hook 4: CommonAdapter 阻止 PowerKeeper 动态增删系统省电白名单
     */
    private fun hookPowerSaveWhitelistAdapter(classLoader: ClassLoader) {
        val adapterClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.utils.CommonAdapter",
            classLoader
        ) ?: return

        val blockHook = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (SMilletLogger.config.blockAddPowerSaveWhitelistApps) {
                    param.result = null
                }
            }
        }
        XposedBridge.hookAllMethods(adapterClass, "addPowerSaveWhitelistApps", blockHook)
        XposedBridge.hookAllMethods(adapterClass, "removePowerSaveWhitelistApps", blockHook)
    }

    /**
     * Hook 5: 阻止 PowerCheckerController 与 PowerStateMachine 杀后台
     */
    private fun hookBackgroundKillers(classLoader: ClassLoader) {
        val checkerClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.powerchecker.PowerCheckerController",
            classLoader
        )
        if (checkerClass != null) {
            XposedBridge.hookAllMethods(checkerClass, "clearApp", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (SMilletLogger.config.disableKill) {
                        SMilletLogger.debug("已阻止 PowerCheckerController#clearApp 清理后台")
                        param.result = null
                    }
                }
            })
        }

        val stateMachineClass = XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.statemachine.PowerStateMachine",
            classLoader
        )
        if (stateMachineClass != null) {
            val stopKillHook = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (SMilletLogger.config.disableKill) {
                        SMilletLogger.debug("已阻止 PowerStateMachine#${param.method.name} 清理后台")
                        param.result = null
                    }
                }
            }
            XposedBridge.hookAllMethods(stateMachineClass, "clearAppWhenScreenOffTimeOut", stopKillHook)
            XposedBridge.hookAllMethods(stateMachineClass, "clearAppWhenScreenOffTimeOutInNight", stopKillHook)
            XposedBridge.hookAllMethods(stateMachineClass, "clearUnactiveApps", stopKillHook)
        }
    }

    /**
     * Hook 6: 捕获 BrightScenarioBase、FreezeBinder、BluetoothEvent 等辅助实例用于诊断与强制冻结
     */
    private fun hookHelperInstances(classLoader: ClassLoader) {
        XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.bright.BrightScenarioBase",
            classLoader
        )?.let { cls ->
            XposedBridge.hookAllConstructors(cls, object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    brightScenarioInstance = param.thisObject
                    applyBrightPreloadWhitelist()
                }
            })
        }

        XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.millet.FreezeBinder",
            classLoader
        )?.let { cls ->
            XposedBridge.hookAllConstructors(cls, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    freezeBinderInstance = param.thisObject
                }
            })
        }

        XposedHelpers.findClassIfExists(
            "com.miui.powerkeeper.event.BluetoothEvent",
            classLoader
        )?.let { cls ->
            XposedBridge.hookAllConstructors(cls, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    bluetoothEventInstance = param.thisObject
                }
            })
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun applyBrightPreloadWhitelist() {
        val bright = brightScenarioInstance ?: return
        runCatching {
            val preloadSet = XposedHelpers.getStaticObjectField(
                bright.javaClass,
                "preloadWhiteApps"
            ) as? MutableCollection<String>
            preloadSet?.removeAll(SMilletLogger.config.forceFreezeSet)
        }
    }

    /**
     * 还原原模块 Landroid/support/v4/ʴ; 的未冻结原因诊断逻辑：
     * 按顺序检查 MilletPolicy / BrightScenarioBase 的各项豁免条件并给出直观报告。
     */
    private fun diagnoseUnfreezeReason(packageName: String): String {
        val ctx = appContext ?: return "无法获取 PowerKeeper 上下文"
        val uid = runCatching {
            ctx.packageManager.getApplicationInfo(packageName, 0).uid
        }.getOrNull() ?: return "找不到应用 UID: $packageName"

        val reasons = mutableListOf<String>()
        val cfg = SMilletLogger.config
        if (cfg.whiteAppSet.contains(packageName)) {
            reasons.add("处于 SMillet 模块墓碑白名单中")
        }

        val policy = milletPolicyInstance
        if (policy != null) {
            runCatching {
                if (XposedHelpers.callMethod(policy, "isCtsPackage", packageName) as? Boolean == true) {
                    reasons.add("属于 CTS 测试包名豁免")
                }
            }
            runCatching {
                val noRestrict = XposedHelpers.getObjectField(policy, "mNoRestrictSet") as? Collection<*>
                if (noRestrict?.contains(packageName) == true) {
                    reasons.add("系统省电策略设为「无限制」")
                }
            }
            runCatching {
                if (XposedHelpers.callMethod(policy, "getActiveVpnUid") as? Int == uid) {
                    reasons.add("当前正在作为活跃 VPN 运行")
                }
            }
            runCatching {
                val ime = XposedHelpers.callMethod(policy, "getCurrentIME") as? String
                if (ime?.contains(packageName) == true) {
                    reasons.add("当前正在作为默认输入法 (IME) 使用")
                }
            }
            runCatching {
                val accUids = XposedHelpers.getObjectField(policy, "mAccessibilityUids") as? Collection<*>
                if (accUids?.contains(uid) == true) {
                    reasons.add("已开启无障碍服务 (AccessibilityService)")
                }
            }
            runCatching {
                if (XposedHelpers.callMethod(policy, "isInWhiteList", packageName) as? Boolean == true) {
                    reasons.add("位于 MilletPolicy 内置白名单 (可在模块中开启「强制冻结」移出)")
                }
            }
        }

        return if (reasons.isEmpty()) {
            "未发现明显白名单豁免项 (UID=$uid)，该应用满足冻结条件，切入后台静置后将被系统冻结"
        } else {
            "导致 [$packageName] (UID=$uid) 未被冻结的原因：\n• " + reasons.joinToString("\n• ")
        }
    }
}
