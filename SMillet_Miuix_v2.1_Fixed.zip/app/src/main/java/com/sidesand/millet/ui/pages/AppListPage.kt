package com.sidesand.millet.ui.pages

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.InstalledAppItem
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import com.sidesand.millet.ui.components.AppIcon
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun AppListPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    onOpenAppConfig: (packageName: String, appName: String) -> Unit
) {
    val allApps by viewModel.installedApps.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var includeSystemApps by remember { mutableStateOf(false) }
    var filterIndex by remember { mutableIntStateOf(0) }

    val filterOptions = listOf(
        "全部应用",
        "已配置自定义策略",
        "墓碑白名单",
        "消息应用",
        "强制冻结",
        "强力压制",
        "禁止同步 Binder",
        "前台服务不冻结"
    )

    val filteredApps = remember(allApps, searchQuery, includeSystemApps, filterIndex, config) {
        allApps.filter { app ->
            if (!includeSystemApps && app.isSystemApp) return@filter false
            if (searchQuery.isNotBlank() &&
                !app.appName.contains(searchQuery, ignoreCase = true) &&
                !app.packageName.contains(searchQuery, ignoreCase = true)
            ) {
                return@filter false
            }
            val pkg = app.packageName
            when (filterIndex) {
                1 -> config.whiteAppSet.contains(pkg) ||
                    config.messageAppSet.contains(pkg) ||
                    config.forceFreezeSet.contains(pkg) ||
                    config.blockThawSet.contains(pkg) ||
                    config.forbidSyncBinderSet.contains(pkg) ||
                    config.notFreezeWhenHasFgsSet.contains(pkg)
                2 -> config.whiteAppSet.contains(pkg)
                3 -> config.messageAppSet.contains(pkg)
                4 -> config.forceFreezeSet.contains(pkg)
                5 -> config.blockThawSet.contains(pkg)
                6 -> config.forbidSyncBinderSet.contains(pkg)
                7 -> config.notFreezeWhenHasFgsSet.contains(pkg)
                else -> true
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)) {
                    TextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = "搜索应用名称或包名...",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                    OverlayDropdownPreference(
                        title = "策略筛选",
                        items = filterOptions,
                        selectedIndex = filterIndex,
                        onSelectedIndexChange = { filterIndex = it }
                    )
                    SwitchPreference(
                        title = "显示系统应用",
                        summary = "开启后可对系统组件配置强制冻结或白名单策略",
                        checked = includeSystemApps,
                        onCheckedChange = { includeSystemApps = it }
                    )
                }
            }
        }

        item {
            SmallTitle(text = "应用列表 (${filteredApps.size})")
        }

        items(filteredApps, key = { it.packageName }) { app ->
            InstalledAppCard(
                app = app,
                config = config,
                onClick = { onOpenAppConfig(app.packageName, app.appName) }
            )
        }
    }
}

@Composable
private fun InstalledAppCard(
    app: InstalledAppItem,
    config: MilletConfigSnapshot,
    onClick: () -> Unit
) {
    val tags = buildList {
        val pkg = app.packageName
        if (config.whiteAppSet.contains(pkg)) add("白名单")
        if (config.messageAppSet.contains(pkg)) add("消息应用")
        if (config.forceFreezeSet.contains(pkg)) add("强制冻结")
        if (config.blockThawSet.contains(pkg)) add("强力压制")
        if (config.forbidSyncBinderSet.contains(pkg)) add("禁Binder")
        if (config.notFreezeWhenHasFgsSet.contains(pkg)) add("前台服务不冻")
        if (config.batteryOptWhiteSet.contains(pkg) || app.isBatteryOptIgnored) add("电池未优化")
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppIcon(
                    drawable = app.icon,
                    appName = app.appName,
                    size = 42.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.appName,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${app.packageName} · UID:${app.uid}",
                        fontSize = 12.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MiuixTheme.colorScheme.secondaryContainer)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (app.isSystemApp) "系统" else "用户",
                        fontSize = 12.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                    )
                }
            }

            if (tags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tags.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MiuixTheme.colorScheme.primary.copy(alpha = 0.14f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = tag,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MiuixTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}
