# SMillet-Miuix (小米原生墓碑增强 LSPosed 模块 · Miuix 重构开源版)

本项目是对 `671-for2.0_arm64-v8a.apk` (`com.sidesand.millet` / **SMillet Pro**) 的完整逆向还原与现代化重构版本，采用开源的 **[compose-miuix-ui/miuix](https://github.com/compose-miuix-ui/miuix)** (`top.yukonga.miuix.kmp:miuix-ui:0.9.4`) 构建原生 Xiaomi HyperOS 风格界面，并移除了原版 `libtestverify.so` 的联网设备序列号验证与内测付费墙限制。

## 1. 工程结构

```text
SMillet-Miuix/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/xposed_init
│       ├── res/values/
│       │   ├── arrays.xml          # xposedscope: android, com.miui.powerkeeper
│       │   └── strings.xml
│       └── java/com/sidesand/millet/
│           ├── data/
│           │   ├── ConfigKeys.kt           # 全部 SharedPreferences 键名与允许解冻原因列表
│           │   ├── MilletConfigSnapshot.kt # 配置不可变/可变数据快照
│           │   ├── PrefsManager.kt         # XSharedPreferences 读取与 JSON 导入导出
│           │   └── AppModels.kt            # 运行中进程与已安装应用模型
│           ├── ipc/
│           │   ├── SystemInterface.kt      # system_server 驻留 Binder 接口
│           │   ├── ISystemCallback.kt      # PowerKeeper 与 UI 双向回调接口
│           │   └── BinderBridge.kt         # "SMillet-Binder" 匿名广播桥接器
│           ├── util/
│           │   └── ProcessScanner.kt       # Root ps -A & wchan 状态扫描 (V1/V2/Kill)
│           ├── hook/
│           │   ├── HandleHook.kt           # IXposedHookLoadPackage 入口
│           │   ├── SMilletLogger.kt        # Xposed / 本地文件日志系统
│           │   ├── system/
│           │   │   ├── SystemServerHook.kt     # android 作用域全部 Hook
│           │   │   ├── SystemServerService.kt  # SMillet-Binder 服务端实现
│           │   │   └── DozeControllerHelper.kt # 深度 Doze 与息屏耗电统计
│           │   └── powerkeeper/
│           │       └── PowerKeeperHook.kt      # com.miui.powerkeeper 作用域全部 Hook
│           └── ui/
│               ├── MainActivity.kt
│               ├── MainScreen.kt
│               ├── MainViewModel.kt
│               ├── theme/SMilletTheme.kt       # MiuixTheme HyperOS 主题封装
│               └── pages/
│                   ├── RunningListPage.kt      # 运行进程列表 + 未冻结原因长按诊断
│                   ├── AppListPage.kt          # 应用策略筛选与标签展示
│                   ├── AppConfigDialog.kt      # 单应用墓碑策略弹窗 (Miuix OverlayDialog)
│                   └── SettingsPage.kt         # 墓碑设置、深度 Doze、日志、JSON 备份恢复
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── gradle/libs.versions.toml
```

## 2. 编译方式

1. 使用 Android Studio Ladybug / Meerkat 或更高版本打开项目目录（需要 JDK 17+ 与 Android SDK 35）。
2. 执行 `./gradlew :app:assembleRelease` 或在 Android Studio 中直接运行 `app` 配置。
3. 在 LSPosed 管理器中启用 **SMillet Miuix**，勾选作用域：
   - **系统框架 (`android`)**
   - **电量与性能 (`com.miui.powerkeeper`)**
4. 重启手机或重启作用域进程即可生效。
