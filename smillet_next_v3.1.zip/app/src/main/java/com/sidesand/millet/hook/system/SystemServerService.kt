package com.sidesand.millet.hook.system

import android.os.Binder
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import com.sidesand.millet.ipc.ISystemCallback
import com.sidesand.millet.ipc.SystemInterface
import java.util.concurrent.ConcurrentHashMap

object SystemServerService : SystemInterface.Stub() {

    private val callbacks = ConcurrentHashMap<String, ISystemCallback>()

    @Volatile
    var noRestrictAppsRaw: String? = null
        private set

    override fun isSystemHookActive(): Boolean = true

    override fun isPowerKeeperActive(): Boolean = callbacks.containsKey("PowerKeeper")

    override fun registerCallback(callback: ISystemCallback?, clientName: String) {
        if (callback != null && clientName.isNotEmpty()) {
            callbacks[clientName] = callback
            SMilletLogger.info("客户端已绑定 SystemServerService: $clientName")
            if (clientName == "PowerKeeper") {
                val currentJson = pullConfigJson()
                if (currentJson.isNotBlank()) {
                    runCatching { callback.onConfigChanged(currentJson) }
                }
            }
        }
    }

    override fun unregisterCallback(callback: ISystemCallback?, clientName: String) {
        if (clientName.isNotEmpty()) {
            callbacks.remove(clientName)
        }
    }

    override fun notifyConfigChanged(key: String) {
        SystemServerHook.reloadConfig(key)
        val json = pullConfigJson()
        callbacks["PowerKeeper"]?.let { pk ->
            runCatching { pk.onConfigChanged(json.ifBlank { key }) }
                .onFailure { callbacks.remove("PowerKeeper") }
        }
    }

    override fun pushConfigJson(jsonText: String) {
        val token = Binder.clearCallingIdentity()
        try {
            val snapshot = PrefsManager.saveSystemConfigFile(jsonText)
            if (snapshot != null) {
                SMilletLogger.config = snapshot
                SystemServerHook.applyConfigSnapshot(snapshot)
            }
            callbacks["PowerKeeper"]?.let { pk ->
                runCatching { pk.onConfigChanged(jsonText) }
                    .onFailure { callbacks.remove("PowerKeeper") }
            }
        } finally {
            Binder.restoreCallingIdentity(token)
        }
    }

    override fun pullConfigJson(): String {
        val token = Binder.clearCallingIdentity()
        return try {
            PrefsManager.readSystemConfigJson()
                ?: PrefsManager.serializeSnapshotToJson(SMilletLogger.config)
        } finally {
            Binder.restoreCallingIdentity(token)
        }
    }

    override fun checkUnfreezeReason(packageName: String) {
        val pk = callbacks["PowerKeeper"]
        if (pk == null) {
            reportUnfreezeReason(packageName, "电量与性能 (PowerKeeper) 尚未连接系统服务，请尝试重启电量与性能")
            return
        }
        runCatching {
            pk.requestCheckFreezeReason(packageName)
        }.onFailure {
            reportUnfreezeReason(packageName, "请求诊断异常: ${it.message}")
        }
    }

    override fun reportUnfreezeReason(packageName: String, reason: String) {
        callbacks["HomePage"]?.let { ui ->
            runCatching { ui.onFreezeReasonResult(packageName, reason) }
                .onFailure { callbacks.remove("HomePage") }
        }
    }

    override fun syncNoRestrictApps(rawList: String?) {
        noRestrictAppsRaw = rawList
        SMilletLogger.debug("同步无限制应用列表: $rawList")
    }

    override fun getRunningProcessesJson(includeSystem: Boolean): String {
        return SystemServerHook.collectRunningProcessesJson(includeSystem)
    }
}
