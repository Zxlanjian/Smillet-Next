package com.sidesand.millet.ui.pages

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.InstalledAppItem
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import com.sidesand.millet.ui.components.AppIcon
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
fun AppListPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    scrollBehavior: ScrollBehavior,
    showFilterSheet: Boolean,
    onDismissFilterSheet: () -> Unit,
    includeSystemApps: Boolean,
    onIncludeSystemAppsChange: (Boolean) -> Unit,
    filterIndex: Int,
    onFilterIndexChange: (Int) -> Unit,
    onOpenAppConfig: (packageName: String, appName: String) -> Unit
) {
    val allApps by viewModel.installedApps.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filterOptions = listOf(
        "全部应用",
        "已配置策略的应用",
        "白名单",
        "黑名单 (强制冻结 / 压制)",
        "消息应用",
        "禁止同步 Binder",
        "前台服务不冻结"
    )

    val filteredApps = remember(allApps, searchQuery, includeSystemApps, filterIndex, config) {
        allApps.filter { app ->
            if (!includeSystemApps && app.isSystemApp) return@filter false
            if (searchQuery.isNotBlank() &&
                !app.appName.contains(searchQuery, ignoreCase = true) &&
                !app.packageName.contains(searchQuery, ignoreCase = true)
            ) {
                return@filter false
            }
            val pkg = app.packageName
            when (filterIndex) {
                1 -> config.whiteAppSet.contains(pkg) ||
                    config.messageAppSet.contains(pkg) ||
                    config.forceFreezeSet.contains(pkg) ||
                    config.blockThawSet.contains(pkg) ||
                    config.forbidSyncBinderSet.contains(pkg) ||
                    config.notFreezeWhenHasFgsSet.contains(pkg)
                2 -> config.whiteAppSet.contains(pkg)
                3 -> config.forceFreezeSet.contains(pkg) || config.blockThawSet.contains(pkg)
                4 -> config.messageAppSet.contains(pkg)
                5 -> config.forbidSyncBinderSet.contains(pkg)
                6 -> config.notFreezeWhenHasFgsSet.contains(pkg)
                else -> true
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        item {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = "搜索",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
        }

        item {
            SmallTitle(text = "应用信息 (${filteredApps.size})")
        }

        itemsIndexed(filteredApps, key = { _, it -> it.packageName }) { index, app ->
            val isFirst = index == 0
            val isLast = index == filteredApps.lastIndex
            val shape = when {
                isFirst && isLast -> RoundedCornerShape(18.dp)
                isFirst -> RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
                isLast -> RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp)
                else -> RoundedCornerShape(0.dp)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(MiuixTheme.colorScheme.surfaceVariant)
                    .clickable { onOpenAppConfig(app.packageName, app.appName) }
                    .padding(
                        start = 16.dp,
                        end = 16.dp,
                        top = if (isFirst) 16.dp else 12.dp,
                        bottom = if (isLast) 16.dp else 12.dp
                    )
            ) {
                InstalledAppRow(app = app, config = config)
            }
        }
    }

    if (showFilterSheet) {
        OverlayDialog(
            show = true,
            title = "列表筛选",
            summary = "按策略类别或系统应用筛选",
            onDismissRequest = onDismissFilterSheet
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                OverlayDropdownPreference(
                    title = "策略筛选",
                    items = filterOptions,
                    selectedIndex = filterIndex,
                    onSelectedIndexChange = onFilterIndexChange
                )
                SwitchPreference(
                    title = "显示系统应用",
                    checked = includeSystemApps,
                    onCheckedChange = onIncludeSystemAppsChange
                )
                Spacer(modifier = Modifier.height(12.dp))
                TextButton(
                    text = "确定",
                    onClick = onDismissFilterSheet,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary()
                )
            }
        }
    }
}

@Composable
private fun InstalledAppRow(
    app: InstalledAppItem,
    config: MilletConfigSnapshot
) {
    val pkg = app.packageName
    val badgePair: Pair<String, Color>? = when {
        config.whiteAppSet.contains(pkg) -> "白名单" to Color(0xFF1A1A1A)
        config.forceFreezeSet.contains(pkg) || config.blockThawSet.contains(pkg) -> "黑名单" to Color(0xFFD94A4A)
        config.messageAppSet.contains(pkg) -> "消息" to Color(0xFF2874F0)
        config.forbidSyncBinderSet.contains(pkg) -> "禁Binder" to Color(0xFF6B5AED)
        config.notFreezeWhenHasFgsSet.contains(pkg) -> "前台不冻" to Color(0xFF169976)
        config.batteryOptWhiteSet.contains(pkg) || app.isBatteryOptIgnored -> "未优化" to Color(0xFF555555)
        else -> null
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(
            drawable = app.icon,
            appName = app.appName,
            size = 46.dp
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = app.appName,
                fontSize = 17.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = app.packageName,
                fontSize = 13.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (badgePair != null) {
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(badgePair.second)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badgePair.first,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}
