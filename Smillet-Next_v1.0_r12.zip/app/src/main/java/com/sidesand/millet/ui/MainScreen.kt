package com.sidesand.millet.ui

import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.components.MiuixPopupActionRow
import com.sidesand.millet.ui.components.MiuixPopupOptionRow
import com.sidesand.millet.ui.components.MiuixTopPopupMenu
import com.sidesand.millet.ui.pages.APP_FILTER_OPTIONS
import com.sidesand.millet.ui.pages.AboutPage
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.AppearancePage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.MAX_DISPLAY_LOG_COUNT
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import com.sidesand.millet.ui.pages.filterLogLines
import com.sidesand.millet.ui.theme.LocalAppBlurEnabled
import com.sidesand.millet.ui.theme.LocalAppDarkMode
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 1:1 还原 YuKongA/Mishka (参考图 1000110482_63e8b6.jpg) 的顶栏背景毛玻璃模糊着色器：
 * - 严格限制模糊作用区域在顶栏内部 (fragCoord.y < topBarBottom)，顶栏下方正文 100% 锐利清晰，绝不遮挡文字；
 * - 通过 6-Pass 可分离级联高斯卷积 (H1 -> V1 -> H2 -> V2 -> H3 -> V3) 将滚入顶栏背后的卡片与色彩柔和扩散为大半径云雾状色晕。
 */
private const val TOP_BAR_BLUR_H_AGSL = """
    uniform shader content;
    uniform float topBarBottom;
    uniform float stepSize;

    half4 main(float2 fragCoord) {
        if (fragCoord.y >= topBarBottom) {
            return content.eval(fragCoord);
        }
        half4 accum = half4(0.0);
        float weightSum = 0.0;
        for (int i = -12; i <= 12; i++) {
            float fi = float(i);
            float w = exp(-(fi * fi) / 36.0);
            float2 samplePos = float2(max(1.0, fragCoord.x + fi * stepSize), fragCoord.y);
            accum += content.eval(samplePos) * w;
            weightSum += w;
        }
        return accum / weightSum;
    }
"""

private const val TOP_BAR_BLUR_V_TINT_AGSL = """
    uniform shader content;
    uniform float topBarBottom;
    uniform float stepSize;
    uniform float4 surfaceTint;

    half4 main(float2 fragCoord) {
        if (fragCoord.y >= topBarBottom) {
            return content.eval(fragCoord);
        }
        float maxSampleY = max(1.0, topBarBottom - 1.0);
        half4 accum = half4(0.0);
        float weightSum = 0.0;
        for (int i = -12; i <= 12; i++) {
            float fi = float(i);
            float w = exp(-(fi * fi) / 36.0);
            float sy = clamp(fragCoord.y + fi * stepSize, 1.0, maxSampleY);
            accum += content.eval(float2(fragCoord.x, sy)) * w;
            weightSum += w;
        }
        half4 blurred = accum / weightSum;
        if (surfaceTint.a > 0.0) {
            return mix(blurred, half4(surfaceTint.rgb, 1.0), surfaceTint.a);
        }
        return blurred;
    }
"""

/**
 * 对齐 YuKongA/Mishka 的二级页面导航栈路由定义（一级 4 Tab 采用 HorizontalPager 常驻，二级页采用 NavDisplay 栈式覆盖动画）
 */
private sealed interface SecondaryRoute {
    data object None : SecondaryRoute
    data class AppDetail(val packageName: String, val appName: String) : SecondaryRoute
    data object Logs : SecondaryRoute
    data object Appearance : SecondaryRoute
    data object About : SecondaryRoute
}

private val MiuixNavEasing = CubicBezierEasing(0.22f, 1.0f, 0.36f, 1.0f)

private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(5.6f, 3.4f)
            horizontalLineTo(9.4f)
            curveTo(10.6f, 3.4f, 11.4f, 4.2f, 11.4f, 5.4f)
            verticalLineTo(18.6f)
            curveTo(11.4f, 19.8f, 10.6f, 20.6f, 9.4f, 20.6f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 20.6f, 3.6f, 19.8f, 3.6f, 18.6f)
            verticalLineTo(5.4f)
            curveTo(3.6f, 4.2f, 4.4f, 3.4f, 5.6f, 3.4f)
            close()

            moveTo(16.2f, 3.4f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 3.4f, 20.4f, 4.2f, 20.4f, 5.4f)
            verticalLineTo(8.5f)
            curveTo(20.4f, 9.7f, 19.6f, 10.5f, 18.4f, 10.5f)
            horizontalLineTo(16.2f)
            curveTo(15.0f, 10.5f, 14.2f, 9.7f, 14.2f, 8.5f)
            verticalLineTo(5.4f)
            curveTo(14.2f, 4.2f, 15.0f, 3.4f, 16.2f, 3.4f)
            close()

            moveTo(16.2f, 13.5f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 13.5f, 20.4f, 14.3f, 20.4f, 15.5f)
            verticalLineTo(18.6f)
            curveTo(20.4f, 19.8f, 19.6f, 20.6f, 18.4f, 20.6f)
            horizontalLineTo(16.2f)
            curveTo(15.0f, 20.6f, 14.2f, 19.8f, 14.2f, 18.6f)
            verticalLineTo(15.5f)
            curveTo(14.2f, 14.3f, 15.0f, 13.5f, 16.2f, 13.5f)
            close()
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(5.6f, 3.6f)
            horizontalLineTo(8.6f)
            curveTo(9.8f, 3.6f, 10.6f, 4.4f, 10.6f, 5.6f)
            verticalLineTo(8.6f)
            curveTo(10.6f, 9.8f, 9.8f, 10.6f, 8.6f, 10.6f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 10.6f, 3.6f, 9.8f, 3.6f, 8.6f)
            verticalLineTo(5.6f)
            curveTo(3.6f, 4.4f, 4.4f, 3.6f, 5.6f, 3.6f)
            close()

            val cx = 17.0f
            val cy = 7.1f
            val r = 3.5f
            moveTo(cx + r, cy)
            curveTo(cx + r, cy + r * 0.552f, cx + r * 0.552f, cy + r, cx, cy + r)
            curveTo(cx - r * 0.552f, cy + r, cx - r, cy + r * 0.552f, cx - r, cy)
            curveTo(cx - r, cy - r * 0.552f, cx - r * 0.552f, cy - r, cx, cy - r)
            curveTo(cx + r * 0.552f, cy - r, cx + r, cy - r * 0.552f, cx + r, cy)
            close()

            moveTo(5.6f, 13.4f)
            horizontalLineTo(8.6f)
            curveTo(9.8f, 13.4f, 10.6f, 14.2f, 10.6f, 15.4f)
            verticalLineTo(18.4f)
            curveTo(10.6f, 19.6f, 9.8f, 20.4f, 8.6f, 20.4f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 20.4f, 3.6f, 19.6f, 3.6f, 18.4f)
            verticalLineTo(15.4f)
            curveTo(3.6f, 14.2f, 4.4f, 13.4f, 5.6f, 13.4f)
            close()

            moveTo(15.4f, 13.4f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 13.4f, 20.4f, 14.2f, 20.4f, 15.4f)
            verticalLineTo(18.4f)
            curveTo(20.4f, 19.6f, 19.6f, 20.4f, 18.4f, 20.4f)
            horizontalLineTo(15.4f)
            curveTo(14.2f, 20.4f, 13.4f, 19.6f, 13.4f, 18.4f)
            verticalLineTo(15.4f)
            curveTo(13.4f, 14.2f, 14.2f, 13.4f, 15.4f, 13.4f)
            close()
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(7.2f, 3.4f)
            horizontalLineTo(16.8f)
            curveTo(19.0f, 3.4f, 20.6f, 5.0f, 20.6f, 7.2f)
            verticalLineTo(16.8f)
            curveTo(20.6f, 19.0f, 19.0f, 20.6f, 16.8f, 20.6f)
            horizontalLineTo(7.2f)
            curveTo(5.0f, 20.6f, 3.4f, 19.0f, 3.4f, 16.8f)
            verticalLineTo(7.2f)
            curveTo(3.4f, 5.0f, 5.0f, 3.4f, 7.2f, 3.4f)
            close()

            moveTo(6.6f, 12.2f)
            horizontalLineTo(9.0f)
            lineTo(10.6f, 8.6f)
            lineTo(13.2f, 15.4f)
            lineTo(14.9f, 12.2f)
            horizontalLineTo(17.4f)
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(12.0f, 2.8f)
            lineTo(19.8f, 7.3f)
            verticalLineTo(16.7f)
            lineTo(12.0f, 21.2f)
            lineTo(4.2f, 16.7f)
            verticalLineTo(7.3f)
            close()
            val r = 3.15f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
    }.build()
}

private val IconMoreCircle: ImageVector by lazy {
    ImageVector.Builder("MoreCircle", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.85f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            val r = 9.0f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
        path(fill = SolidColor(Color.Black)) {
            val xs = floatArrayOf(8.2f, 12.0f, 15.8f)
            val dotR = 1.15f
            for (cx in xs) {
                moveTo(cx + dotR, 12f)
                curveTo(cx + dotR, 12f + dotR * 0.55f, cx + dotR * 0.55f, 12f + dotR, cx, 12f + dotR)
                curveTo(cx - dotR * 0.55f, 12f + dotR, cx - dotR, 12f + dotR * 0.55f, cx - dotR, 12f)
                curveTo(cx - dotR, 12f - dotR * 0.55f, cx - dotR * 0.55f, 12f - dotR, cx, 12f - dotR)
                curveTo(cx + dotR * 0.55f, 12f - dotR, cx + dotR, 12f - dotR * 0.55f, cx + dotR, 12f)
                close()
            }
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(18.2f, 7.6f)
            curveTo(16.8f, 5.6f, 14.5f, 4.4f, 12.0f, 4.4f)
            curveTo(7.8f, 4.4f, 4.4f, 7.8f, 4.4f, 12.0f)
            curveTo(4.4f, 16.2f, 7.8f, 19.6f, 12.0f, 19.6f)
            curveTo(15.6f, 19.6f, 18.6f, 17.1f, 19.4f, 13.7f)
            moveTo(18.6f, 4.4f)
            verticalLineTo(8.2f)
            horizontalLineTo(14.8f)
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.1f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(14.8f, 5.8f)
            lineTo(8.6f, 12.0f)
            lineTo(14.8f, 18.2f)
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 4 })
    var secondaryRoute by remember { mutableStateOf<SecondaryRoute>(SecondaryRoute.None) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val config by viewModel.config.collectAsState()
    val logs by viewModel.logsList.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")
    val isDark = LocalAppDarkMode.current
    val blurEnabled = LocalAppBlurEnabled.current
    val surfaceBg = MiuixTheme.colorScheme.background
    val topBarColor = if (blurEnabled) Color.Transparent else surfaceBg

    var appListTopBarHeight by remember { mutableStateOf(96.dp) }
    var logPageTopBarHeight by remember { mutableStateOf(88.dp) }

    // 当切换到「运行列表」Tab 时自动刷新运行进程
    LaunchedEffect(pagerState.currentPage) {
        if (pagerState.currentPage != 1) {
            showAppFilterSheet = false
        }
        if (pagerState.currentPage == 2) {
            viewModel.refreshRunningApps(includeSystemApps)
        }
    }

    val exportLogFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val currentFiltered = filterLogLines(logs, config.logLevel, logFilterLevel)
                val content = if (currentFiltered.isEmpty()) {
                    "暂无日志记录\n"
                } else {
                    currentFiltered.joinToString("\n") + "\n"
                }
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "日志文件已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "导出日志失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler(enabled = showAppFilterSheet || showLogTopMenu || secondaryRoute !is SecondaryRoute.None) {
        when {
            showAppFilterSheet -> showAppFilterSheet = false
            showLogTopMenu -> showLogTopMenu = false
            secondaryRoute !is SecondaryRoute.None -> secondaryRoute = SecondaryRoute.None
        }
    }

    fun navigateToTab(targetPage: Int) {
        showAppFilterSheet = false
        scope.launch {
            pagerState.animateScrollToPage(
                page = targetPage,
                animationSpec = spring(
                    dampingRatio = 0.92f,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
    }

    // 对齐 YuKongA/Mishka (HorizontalPager + NavDisplay 二级页栈)：
    // 二级页打开时，底层主界面保持挂载并伴随 -25% 视差左移与轻微压暗，二级页连同自身顶栏从右往左完整滑入覆盖
    val hasSecondaryPage = secondaryRoute !is SecondaryRoute.None
    val mainParallaxProgress by animateFloatAsState(
        targetValue = if (hasSecondaryPage) 1f else 0f,
        animationSpec = tween(durationMillis = 320, easing = MiuixNavEasing),
        label = "MainParallaxProgress"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(surfaceBg)
    ) {
        // 1. 底层常驻主界面：4 Tab HorizontalPager + 底部 NavigationBar
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = -size.width * 0.24f * mainParallaxProgress
                }
        ) {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(
                            selected = pagerState.currentPage == 0,
                            onClick = { navigateToTab(0) },
                            icon = IconHome,
                            label = "主页"
                        )
                        NavigationBarItem(
                            selected = pagerState.currentPage == 1,
                            onClick = { navigateToTab(1) },
                            icon = IconAppList,
                            label = "应用列表"
                        )
                        NavigationBarItem(
                            selected = pagerState.currentPage == 2,
                            onClick = { navigateToTab(2) },
                            icon = IconRunningCheck,
                            label = "运行列表"
                        )
                        NavigationBarItem(
                            selected = pagerState.currentPage == 3,
                            onClick = { navigateToTab(3) },
                            icon = IconHexSettings,
                            label = "设置"
                        )
                    }
                }
            ) { outerPadding ->
                val bottomBarHeight = outerPadding.calculateBottomPadding()

                HorizontalPager(
                    state = pagerState,
                    beyondViewportPageCount = 1,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val tabScrollBehavior = MiuixScrollBehavior()

                    Scaffold(
                        topBar = {
                            TopAppBar(
                                title = tabTitles[page],
                                scrollBehavior = tabScrollBehavior,
                                color = topBarColor,
                                actions = {
                                    when (page) {
                                        1 -> {
                                            TopMenuActionButton(
                                                active = showAppFilterSheet,
                                                isDark = isDark,
                                                contentDescription = "筛选",
                                                onClick = { showAppFilterSheet = !showAppFilterSheet }
                                            )
                                        }
                                        2 -> {
                                            IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                                Icon(
                                                    imageVector = IconRefresh,
                                                    contentDescription = "刷新",
                                                    tint = MiuixTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    ) { tabInnerPadding ->
                        val topBarHeight = tabInnerPadding.calculateTopPadding()
                        if (page == 1 && topBarHeight > 0.dp) {
                            appListTopBarHeight = topBarHeight
                        }
                        val pageContentPadding = PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            top = topBarHeight + 10.dp,
                            bottom = bottomBarHeight + 12.dp
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .topBarFrostedBlur(
                                    enabled = blurEnabled,
                                    topBarHeight = topBarHeight,
                                    surfaceColor = surfaceBg,
                                    isDark = isDark
                                )
                        ) {
                            when (page) {
                                0 -> HomePage(
                                    viewModel = viewModel,
                                    config = config,
                                    isSystemActive = isSystemActive,
                                    isPowerKeeperActive = isPkActive,
                                    scrollBehavior = tabScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    onNavigateToWhitelist = {
                                        appFilterIndex = 2
                                        navigateToTab(1)
                                    },
                                    onNavigateToBlacklist = {
                                        appFilterIndex = 3
                                        navigateToTab(1)
                                    },
                                    onNavigateToRunning = { navigateToTab(2) },
                                    onNavigateToLogs = {
                                        showLogTopMenu = false
                                        secondaryRoute = SecondaryRoute.Logs
                                    }
                                )
                                1 -> AppListPage(
                                    viewModel = viewModel,
                                    config = config,
                                    scrollBehavior = tabScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    includeSystemApps = includeSystemApps,
                                    filterIndex = appFilterIndex,
                                    onFilterIndexChange = { appFilterIndex = it },
                                    onOpenAppConfig = { pkg, name ->
                                        secondaryRoute = SecondaryRoute.AppDetail(pkg, name)
                                    }
                                )
                                2 -> RunningListPage(
                                    viewModel = viewModel,
                                    scrollBehavior = tabScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    onOpenAppConfig = { pkg, name ->
                                        secondaryRoute = SecondaryRoute.AppDetail(pkg, name)
                                    },
                                    onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                                )
                                3 -> SettingsPage(
                                    viewModel = viewModel,
                                    config = config,
                                    scrollBehavior = tabScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    onNavigateToAppearance = {
                                        secondaryRoute = SecondaryRoute.Appearance
                                    },
                                    onNavigateToAbout = {
                                        secondaryRoute = SecondaryRoute.About
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 二级页面推入时对底层主页面叠加柔和景深压暗层
            if (mainParallaxProgress > 0.005f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = (if (isDark) 0.28f else 0.12f) * mainParallaxProgress))
                )
            }
        }

        // 2. 顶层二级页面导航容器（参考 YuKongA/Mishka NavDisplay：整页含顶栏从右往左覆盖滑入，返回时从左往右滑出）
        AnimatedContent(
            targetState = secondaryRoute,
            transitionSpec = {
                val isPushing = targetState !is SecondaryRoute.None
                if (isPushing) {
                    (slideInHorizontally(
                        animationSpec = tween(durationMillis = 320, easing = MiuixNavEasing),
                        initialOffsetX = { fullWidth -> fullWidth }
                    ) togetherWith (slideOutHorizontally(
                        animationSpec = tween(durationMillis = 320, easing = MiuixNavEasing),
                        targetOffsetX = { fullWidth -> -fullWidth / 4 }
                    ) + fadeOut(animationSpec = tween(durationMillis = 320), targetAlpha = 0.9f))).apply {
                        targetContentZIndex = 1f
                    }
                } else {
                    (fadeIn(animationSpec = tween(durationMillis = 280)) togetherWith slideOutHorizontally(
                        animationSpec = tween(durationMillis = 300, easing = MiuixNavEasing),
                        targetOffsetX = { fullWidth -> fullWidth }
                    )).apply {
                        targetContentZIndex = 0f
                    }
                } using SizeTransform(clip = false)
            },
            label = "SecondaryNavDisplay"
        ) { subRoute ->
            when (subRoute) {
                is SecondaryRoute.None -> {
                    Box(modifier = Modifier.fillMaxSize())
                }

                is SecondaryRoute.AppDetail -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(surfaceBg)
                    ) {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = subRoute.appName,
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = { secondaryRoute = SecondaryRoute.None }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                AppConfigDialog(
                                    packageName = subRoute.packageName,
                                    appName = subRoute.appName,
                                    config = config,
                                    viewModel = viewModel,
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    onDismiss = { secondaryRoute = SecondaryRoute.None }
                                )
                            }
                        }
                    }
                }

                is SecondaryRoute.Logs -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(surfaceBg)
                    ) {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = "日志",
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = {
                                            showLogTopMenu = false
                                            secondaryRoute = SecondaryRoute.None
                                        }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    },
                                    actions = {
                                        TopMenuActionButton(
                                            active = showLogTopMenu,
                                            isDark = isDark,
                                            contentDescription = "日志选项",
                                            onClick = { showLogTopMenu = !showLogTopMenu }
                                        )
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            if (topBarHeight > 0.dp) {
                                logPageTopBarHeight = topBarHeight
                            }
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                LogPage(
                                    viewModel = viewModel,
                                    config = config,
                                    listState = logListState,
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    filterLevel = logFilterLevel,
                                    onFilterLevelChange = { logFilterLevel = it }
                                )
                            }
                        }
                    }
                }

                is SecondaryRoute.Appearance -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(surfaceBg)
                    ) {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = "外观与主题",
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = { secondaryRoute = SecondaryRoute.None }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                AppearancePage(
                                    viewModel = viewModel,
                                    config = config,
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding
                                )
                            }
                        }
                    }
                }

                is SecondaryRoute.About -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(surfaceBg)
                    ) {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = "关于",
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = { secondaryRoute = SecondaryRoute.None }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                AboutPage(
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding
                                )
                            }
                        }
                    }
                }
            }
        }

        diagnosticPair?.let { (pkg, reason) ->
            OverlayDialog(
                show = true,
                title = "诊断冻结状态",
                summary = pkg,
                onDismissRequest = { viewModel.dismissDiagnosticDialog() }
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = reason)
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(
                        text = "我知道了",
                        onClick = { viewModel.dismissDiagnosticDialog() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }

        // 应用列表右上角弹出菜单（置于根 Box 最顶层，压暗遮罩对顶栏标题同样生效）
        val safeFilterIndex = appFilterIndex.coerceIn(0, APP_FILTER_OPTIONS.lastIndex)
        MiuixTopPopupMenu(
            visible = showAppFilterSheet && secondaryRoute is SecondaryRoute.None && pagerState.currentPage == 1,
            onDismiss = { showAppFilterSheet = false },
            topOffset = appListTopBarHeight + 6.dp,
            width = 240.dp
        ) {
            APP_FILTER_OPTIONS.forEachIndexed { idx, label ->
                MiuixPopupOptionRow(
                    text = label,
                    selected = idx == safeFilterIndex,
                    onClick = {
                        appFilterIndex = idx
                        showAppFilterSheet = false
                    }
                )
            }

            MiuixPopupOptionRow(
                text = "显示系统应用",
                selected = includeSystemApps,
                onClick = {
                    includeSystemApps = !includeSystemApps
                    showAppFilterSheet = false
                }
            )
        }

        // 日志页右上角弹出菜单（置于根 Box 最顶层，压暗遮罩对顶栏标题同样生效）
        MiuixTopPopupMenu(
            visible = showLogTopMenu && secondaryRoute is SecondaryRoute.Logs,
            onDismiss = { showLogTopMenu = false },
            topOffset = logPageTopBarHeight + 6.dp,
            width = 228.dp
        ) {
            LogFilterLevel.entries.forEach { level ->
                MiuixPopupOptionRow(
                    text = level.label,
                    selected = level == logFilterLevel,
                    onClick = {
                        logFilterLevel = level
                        showLogTopMenu = false
                    }
                )
            }

            val currentFilteredLogs = filterLogLines(logs, config.logLevel, logFilterLevel)
            val displayedLogCount = currentFilteredLogs.size.coerceAtMost(MAX_DISPLAY_LOG_COUNT)

            MiuixPopupActionRow(
                text = "滚动到顶部",
                onClick = {
                    showLogTopMenu = false
                    if (displayedLogCount > 0) {
                        scope.launch { logListState.animateScrollToItem(0) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "滚动到底部",
                onClick = {
                    showLogTopMenu = false
                    if (displayedLogCount > 0) {
                        scope.launch { logListState.animateScrollToItem(displayedLogCount) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "导出日志文件",
                onClick = {
                    showLogTopMenu = false
                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    exportLogFileLauncher.launch("Smillet-Next_log_$ts.txt")
                }
            )
        }
    }
}

@Composable
private fun Modifier.topBarFrostedBlur(
    enabled: Boolean,
    topBarHeight: Dp,
    surfaceColor: Color,
    isDark: Boolean
): Modifier {
    if (!enabled) return this
    val shaders = remember {
        runCatching {
            arrayOf(
                RuntimeShader(TOP_BAR_BLUR_H_AGSL),
                RuntimeShader(TOP_BAR_BLUR_V_TINT_AGSL),
                RuntimeShader(TOP_BAR_BLUR_H_AGSL),
                RuntimeShader(TOP_BAR_BLUR_V_TINT_AGSL),
                RuntimeShader(TOP_BAR_BLUR_H_AGSL),
                RuntimeShader(TOP_BAR_BLUR_V_TINT_AGSL)
            )
        }.getOrNull()
    }
    if (shaders == null) return this

    return this.graphicsLayer {
        val topPx = topBarHeight.toPx()
        if (topPx > 0f) {
            compositingStrategy = CompositingStrategy.Offscreen

            val sH1 = shaders[0]
            val sV1 = shaders[1]
            val sH2 = shaders[2]
            val sV2 = shaders[3]
            val sH3 = shaders[4]
            val sV3 = shaders[5]

            val step1 = 1.8f
            sH1.setFloatUniform("topBarBottom", topPx)
            sH1.setFloatUniform("stepSize", step1)
            sV1.setFloatUniform("topBarBottom", topPx)
            sV1.setFloatUniform("stepSize", step1)
            sV1.setFloatUniform("surfaceTint", 0f, 0f, 0f, 0f)

            val step2 = 7.5f
            sH2.setFloatUniform("topBarBottom", topPx)
            sH2.setFloatUniform("stepSize", step2)
            sV2.setFloatUniform("topBarBottom", topPx)
            sV2.setFloatUniform("stepSize", step2)
            sV2.setFloatUniform("surfaceTint", 0f, 0f, 0f, 0f)

            val step3 = 20.0f
            sH3.setFloatUniform("topBarBottom", topPx)
            sH3.setFloatUniform("stepSize", step3)

            val tintAlpha = if (isDark) 0.75f else 0.72f
            sV3.setFloatUniform("topBarBottom", topPx)
            sV3.setFloatUniform("stepSize", step3)
            sV3.setFloatUniform(
                "surfaceTint",
                surfaceColor.red,
                surfaceColor.green,
                surfaceColor.blue,
                tintAlpha
            )

            val p1 = AndroidRenderEffect.createRuntimeShaderEffect(sH1, "content")
            val p2 = AndroidRenderEffect.createRuntimeShaderEffect(sV1, "content")
            val p3 = AndroidRenderEffect.createRuntimeShaderEffect(sH2, "content")
            val p4 = AndroidRenderEffect.createRuntimeShaderEffect(sV2, "content")
            val p5 = AndroidRenderEffect.createRuntimeShaderEffect(sH3, "content")
            val p6 = AndroidRenderEffect.createRuntimeShaderEffect(sV3, "content")

            val c12 = AndroidRenderEffect.createChainEffect(p2, p1)
            val c123 = AndroidRenderEffect.createChainEffect(p3, c12)
            val c1234 = AndroidRenderEffect.createChainEffect(p4, c123)
            val c12345 = AndroidRenderEffect.createChainEffect(p5, c1234)
            val c123456 = AndroidRenderEffect.createChainEffect(p6, c12345)

            renderEffect = c123456.asComposeRenderEffect()
        }
    }
}

@Composable
private fun TopMenuActionButton(
    active: Boolean,
    isDark: Boolean,
    contentDescription: String,
    onClick: () -> Unit
) {
    val activeCircleColor = if (isDark) {
        Color.White.copy(alpha = 0.14f)
    } else {
        Color.Black.copy(alpha = 0.08f)
    }

    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) activeCircleColor else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = IconMoreCircle,
                contentDescription = contentDescription,
                tint = MiuixTheme.colorScheme.onSurface
            )
        }
    }
}
