package com.sidesand.millet.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import com.sidesand.millet.data.MilletConfigSnapshot
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController

/**
 * 对齐 YuKongA/Mishka 的单点主题架构：
 * - LocalAppDarkMode：全局唯一深浅色判定源，所有页面与组件均读取 LocalAppDarkMode.current，确保手动切换浅色/深色时全应用 100% 跟随；
 * - LocalAppMonetEnabled：标记 Monet 动态取色启用态；
 * - LocalAppBlurEnabled：标记顶栏/底栏毛玻璃材质启用态。
 */
val LocalAppDarkMode = compositionLocalOf { false }
val LocalAppMonetEnabled = compositionLocalOf { false }
val LocalAppBlurEnabled = compositionLocalOf { true }

object ThemeConfig {
    val COLOR_MODE_LABELS = listOf(
        "跟随系统",
        "浅色模式",
        "深色模式"
    )

    val MONET_PALETTE_OPTIONS = listOf(
        "系统壁纸动态取色" to null,
        "小米科技蓝 (#3482FF)" to Color(0xFF3482FF),
        "翡冷翠绿 (#169976)" to Color(0xFF169976),
        "星辰紫 (#6B5AED)" to Color(0xFF6B5AED),
        "琥珀橙 (#E67E22)" to Color(0xFFE67E22),
        "珊瑚红 (#D94A4A)" to Color(0xFFD94A4A)
    )

    fun resolveIsDark(colorMode: Int, systemDark: Boolean): Boolean {
        return when (colorMode) {
            1 -> false
            2 -> true
            else -> systemDark
        }
    }

    fun resolveColorSchemeMode(colorMode: Int, monetEnabled: Boolean): ColorSchemeMode {
        return if (monetEnabled) {
            when (colorMode) {
                1 -> ColorSchemeMode.MonetLight
                2 -> ColorSchemeMode.MonetDark
                else -> ColorSchemeMode.MonetSystem
            }
        } else {
            when (colorMode) {
                1 -> ColorSchemeMode.Light
                2 -> ColorSchemeMode.Dark
                else -> ColorSchemeMode.System
            }
        }
    }

    fun resolveKeyColor(monetEnabled: Boolean, monetColorIndex: Int): Color? {
        if (!monetEnabled) return null
        return MONET_PALETTE_OPTIONS.getOrNull(monetColorIndex)?.second
    }

    fun summaryForConfig(config: MilletConfigSnapshot): String {
        val modeLabel = COLOR_MODE_LABELS.getOrElse(config.themeColorMode) { "跟随系统" }
        val monetLabel = if (config.monetEnabled) " · Monet 动态取色" else ""
        val blurLabel = if (config.blurEnabled) " · 毛玻璃开启" else ""
        return "$modeLabel$monetLabel$blurLabel"
    }
}

@Composable
fun SmilletNextTheme(
    config: MilletConfigSnapshot = MilletConfigSnapshot(),
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val isDark = ThemeConfig.resolveIsDark(config.themeColorMode, systemDark)
    val schemeMode = ThemeConfig.resolveColorSchemeMode(config.themeColorMode, config.monetEnabled)
    val keyColor = ThemeConfig.resolveKeyColor(config.monetEnabled, config.monetColorIndex)

    val controller = remember(schemeMode, keyColor) {
        if (keyColor != null) {
            ThemeController(schemeMode, keyColor = keyColor)
        } else {
            ThemeController(schemeMode)
        }
    }

    CompositionLocalProvider(
        LocalAppDarkMode provides isDark,
        LocalAppMonetEnabled provides config.monetEnabled,
        LocalAppBlurEnabled provides config.blurEnabled
    ) {
        MiuixTheme(
            controller = controller,
            content = content
        )
    }
}
