package com.sidesand.millet.ui

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sidesand.millet.model.AppInfo
import com.sidesand.millet.ui.components.MiuixPopupAction
import com.sidesand.millet.ui.components.MiuixTopPopupMenu
import com.sidesand.millet.ui.pages.AboutScreen
import com.sidesand.millet.ui.pages.ActionIconBox
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.AppearanceSettingsScreen
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import com.sidesand.millet.ui.theme.SMilletTheme
import com.sidesand.millet.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.basic.Search
import top.yukonga.miuix.kmp.theme.MiuixTheme
import kotlin.math.roundToInt

private sealed class SecondaryRoute {
    data object None : SecondaryRoute()
    data class AppDetail(val app: AppInfo) : SecondaryRoute()
    data object Logs : SecondaryRoute()
    data object Appearance : SecondaryRoute()
    data object About : SecondaryRoute()
}

private const val TOP_BAR_BLUR_AGSL = """
uniform shader content;
uniform float topBarBottom;
uniform float topRadius;
uniform float4 tintColor;

half4 main(float2 fragCoord) {
    if (fragCoord.y >= topBarBottom || topBarBottom <= 0.0 || topRadius <= 0.5) {
        return content.eval(fragCoord);
    }
    half4 sum = half4(0.0);
    float totalWeight = 0.0;
    for (int x = -3; x <= 3; x++) {
        for (int y = -3; y <= 3; y++) {
            float weight = exp(-float(x * x + y * y) / 4.5);
            float2 offset = float2(float(x), float(y)) * (topRadius * 0.32);
            float2 samplePos = float2(
                fragCoord.x + offset.x,
                clamp(fragCoord.y + offset.y, 0.0, max(0.0, topBarBottom - 1.0))
            );
            sum += content.eval(samplePos) * weight;
            totalWeight += weight;
        }
    }
    half4 blurred = sum / totalWeight;
    return mix(blurred, half4(tintColor), tintColor.a);
}
"""

private const val BOTTOM_CAPSULE_BLUR_AGSL = """
uniform shader content;
uniform float4 bottomRect;
uniform float bottomRadius;
uniform float isLiquidGlass;
uniform float4 tintColor;

half4 main(float2 fragCoord) {
    float bLeft = bottomRect.x;
    float bTop = bottomRect.y;
    float bRight = bottomRect.z;
    float bBottom = bottomRect.w;
    if (bRight <= bLeft || bBottom <= bTop || bottomRadius <= 0.5) {
        return content.eval(fragCoord);
    }
    // Exact stadium/capsule Signed Distance Function (SDF)
    float r = (bBottom - bTop) * 0.5;
    float cy = (bTop + bBottom) * 0.5;
    float cx = clamp(fragCoord.x, bLeft + r, bRight - r);
    float dist = length(fragCoord - float2(cx, cy)) - r;
    if (dist > 0.0) {
        return content.eval(fragCoord);
    }

    float2 sampleBase = fragCoord;
    if (isLiquidGlass > 0.5 && dist > -r * 0.42) {
        float edgeT = clamp((dist + r * 0.42) / (r * 0.42), 0.0, 1.0);
        float2 normal = normalize(fragCoord - float2(cx, cy) + float2(0.0001, 0.0001));
        sampleBase -= normal * (edgeT * edgeT * 6.5);
    }

    half4 sum = half4(0.0);
    float totalWeight = 0.0;
    for (int x = -3; x <= 3; x++) {
        for (int y = -3; y <= 3; y++) {
            float weight = exp(-float(x * x + y * y) / 4.5);
            float2 offset = float2(float(x), float(y)) * (bottomRadius * 0.28);
            float2 sp = float2(
                clamp(sampleBase.x + offset.x, bLeft + 1.0, bRight - 1.0),
                clamp(sampleBase.y + offset.y, bTop + 1.0, bBottom - 1.0)
            );
            sum += content.eval(sp) * weight;
            totalWeight += weight;
        }
    }
    half4 blurred = sum / totalWeight;
    float tintAlpha = (isLiquidGlass > 0.5) ? (tintColor.a * 0.35) : tintColor.a;
    return mix(blurred, half4(tintColor.rgb, 1.0), tintAlpha);
}
"""

private fun Modifier.topBarFrostedBlur(
    topBarBottomPx: Float,
    topBlurMode: Int,
    surfaceColor: Color,
    isDark: Boolean
): Modifier {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || topBlurMode == 2 || topBarBottomPx <= 1f) {
        return this
    }
    return this.graphicsLayer {
        val shader = RuntimeShader(TOP_BAR_BLUR_AGSL)
        shader.setFloatUniform("topBarBottom", topBarBottomPx)
        val topR = when (topBlurMode) {
            0 -> 30f
            1 -> 14f
            else -> 0f
        }
        shader.setFloatUniform("topRadius", topR)
        val tintAlpha = when (topBlurMode) {
            0 -> if (isDark) 0.54f else 0.62f
            1 -> if (isDark) 0.72f else 0.78f
            else -> 0f
        }
        shader.setFloatUniform(
            "tintColor",
            surfaceColor.red,
            surfaceColor.green,
            surfaceColor.blue,
            tintAlpha
        )
        renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
    }
}

private fun Modifier.bottomCapsuleFrostedBlur(
    bottomBarRect: Rect,
    bottomBlurMode: Int,
    isLiquidGlass: Boolean,
    surfaceColor: Color,
    isDark: Boolean
): Modifier {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return this
    val active = bottomBarRect.width > 1f && (bottomBlurMode != 2 || isLiquidGlass)
    if (!active) return this

    return this.graphicsLayer {
        val shader = RuntimeShader(BOTTOM_CAPSULE_BLUR_AGSL)
        shader.setFloatUniform(
            "bottomRect",
            bottomBarRect.left,
            bottomBarRect.top,
            bottomBarRect.right,
            bottomBarRect.bottom
        )
        val bottomR = when {
            isLiquidGlass -> 26f
            bottomBlurMode == 0 -> 28f
            bottomBlurMode == 1 -> 14f
            else -> 0f
        }
        shader.setFloatUniform("bottomRadius", bottomR)
        shader.setFloatUniform("isLiquidGlass", if (isLiquidGlass) 1f else 0f)
        val tintAlpha = when (bottomBlurMode) {
            0 -> if (isDark) 0.50f else 0.58f
            1 -> if (isDark) 0.68f else 0.74f
            else -> if (isDark) 0.36f else 0.42f
        }
        shader.setFloatUniform(
            "tintColor",
            surfaceColor.red,
            surfaceColor.green,
            surfaceColor.blue,
            tintAlpha
        )
        renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
    }
}

@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val globalConfig by viewModel.globalConfig.collectAsState()
    val themeConfig by viewModel.themeConfig.collectAsState()
    val dashboardState by viewModel.dashboardState.collectAsState()
    val appList by viewModel.appList.collectAsState()
    val isLoadingApps by viewModel.isLoadingApps.collectAsState()
    val runningProcesses by viewModel.runningProcesses.collectAsState()
    val isLoadingRunning by viewModel.isLoadingRunning.collectAsState()
    val logs by viewModel.logs.collectAsState()

    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 4 })
    var secondaryRoute by remember { mutableStateOf<SecondaryRoute>(SecondaryRoute.None) }

    var appSearchQuery by rememberSaveable { mutableStateOf("") }
    var includeSystemApps by rememberSaveable { mutableStateOf(false) }
    var appFilterIndex by rememberSaveable { mutableIntStateOf(0) }

    var runningSearchQuery by rememberSaveable { mutableStateOf("") }
    var showFrozenOnly by rememberSaveable { mutableStateOf(false) }
    var showOnlyTargetApps by rememberSaveable { mutableStateOf(false) }

    var showAppFilterPopup by remember { mutableStateOf(false) }
    var showAppMorePopup by remember { mutableStateOf(false) }
    var showRunningFilterPopup by remember { mutableStateOf(false) }

    // Cross-axis gesture lock for "跨轴拦截" (pageSwitchGesture == 0)
    var isVerticalListScrolling by remember { mutableStateOf(false) }
    val crossAxisScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (kotlin.math.abs(available.y) > kotlin.math.abs(available.x) * 1.15f && kotlin.math.abs(available.y) > 1.5f) {
                    isVerticalListScrolling = true
                }
                return Offset.Zero
            }

            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                if (kotlin.math.abs(consumed.y) > 1.5f) {
                    isVerticalListScrolling = true
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                isVerticalListScrolling = false
                return Velocity.Zero
            }
        }
    }

    // Horizontal drag-to-switch-tabs state on the bottom bar
    var bottomBarDragTab by remember { mutableStateOf<Float?>(null) }

    // Auto-refresh battery optimization whitelist status whenever entering AppList tab or returning from AppConfigDialog
    LaunchedEffect(pagerState.currentPage, secondaryRoute) {
        if (pagerState.currentPage == 1 && secondaryRoute == SecondaryRoute.None) {
            viewModel.refreshBatteryOptimizationStates()
        }
    }

    val exportConfigLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(viewModel.exportBackupJson().toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "配置已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { e ->
                Toast.makeText(context, "导出失败: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importConfigLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (!content.isNullOrBlank() && viewModel.importBackupJson(content)) {
                    Toast.makeText(context, "配置已成功恢复", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "配置文件格式无效", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                Toast.makeText(context, "导入失败: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val navLabels = remember { listOf("主页", "应用列表", "运行列表", "设置") }
    val standardNavItems = remember {
        listOf(
            NavigationItem("主页", MiuixIcons.Search),
            NavigationItem("应用列表", MiuixIcons.Search),
            NavigationItem("运行列表", MiuixIcons.Search),
            NavigationItem("设置", MiuixIcons.Search)
        )
    }

    SMilletTheme(themeConfig = themeConfig) {
        val isDark = when (themeConfig.themeMode) {
            1 -> false
            2 -> true
            else -> isSystemInDarkTheme()
        }
        val surfaceColor = MiuixTheme.colorScheme.surface
        val backgroundColor = MiuixTheme.colorScheme.background
        val supportsBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        val topBarClear = supportsBlur && themeConfig.topBarBlurMode != 2
        val bottomBarClear = supportsBlur && (themeConfig.bottomBarBlurMode != 2 || themeConfig.enableLiquidGlass)

        // Back gesture handling:
        // 1) Secondary routes ALWAYS handle back to return to main tabs
        // 2) Non-home tabs return to Home tab when predictive back is enabled
        BackHandler(
            enabled = secondaryRoute != SecondaryRoute.None ||
                (themeConfig.enablePredictiveBack && pagerState.currentPage != 0)
        ) {
            if (secondaryRoute != SecondaryRoute.None) {
                secondaryRoute = SecondaryRoute.None
            } else if (pagerState.currentPage != 0) {
                scope.launch { pagerState.animateScrollToPage(0) }
            }
        }

        AnimatedContent(
            targetState = secondaryRoute,
            transitionSpec = {
                if (targetState != SecondaryRoute.None) {
                    (slideInHorizontally(
                        animationSpec = tween(260, easing = FastOutSlowInEasing),
                        initialOffsetX = { fullWidth -> fullWidth / 3 }
                    ) + fadeIn(tween(200))) togetherWith (slideOutHorizontally(
                        animationSpec = tween(260, easing = FastOutSlowInEasing),
                        targetOffsetX = { fullWidth -> -fullWidth / 5 }
                    ) + fadeOut(tween(180)))
                } else {
                    (slideInHorizontally(
                        animationSpec = tween(250, easing = FastOutSlowInEasing),
                        initialOffsetX = { fullWidth -> -fullWidth / 5 }
                    ) + fadeIn(tween(200))) togetherWith (slideOutHorizontally(
                        animationSpec = tween(250, easing = FastOutSlowInEasing),
                        targetOffsetX = { fullWidth -> fullWidth / 3 }
                    ) + fadeOut(tween(180)))
                }.using(SizeTransform(clip = false))
            },
            label = "SecondaryRouteTransition"
        ) { route ->
            when (route) {
                is SecondaryRoute.AppDetail -> {
                    val latestApp = appList.find {
                        it.packageName == route.app.packageName && it.uid == route.app.uid
                    } ?: route.app
                    val latestRunning = runningProcesses.filter {
                        it.uid == latestApp.uid || it.packageName == latestApp.packageName
                    }

                    AppConfigDialog(
                        app = latestApp,
                        runningProcesses = latestRunning,
                        onBack = {
                            viewModel.refreshBatteryOptimizationStates()
                            secondaryRoute = SecondaryRoute.None
                        },
                        onSavePolicy = { updatedPolicy ->
                            viewModel.updateAppPolicy(updatedPolicy)
                        },
                        onQuickFreeze = {
                            viewModel.freezeAppNow(latestApp)
                            Toast.makeText(context, "已冻结 ${latestApp.label}", Toast.LENGTH_SHORT).show()
                        },
                        onQuickUnfreeze = {
                            viewModel.unfreezeAppNow(latestApp)
                            Toast.makeText(context, "已解冻 ${latestApp.label}", Toast.LENGTH_SHORT).show()
                        }
                    )
                }

                SecondaryRoute.Logs -> {
                    var subTopBarBottomPx by remember { mutableFloatStateOf(0f) }
                    Scaffold(
                        topBar = {
                            Box(
                                modifier = Modifier.onGloballyPositioned { coords ->
                                    subTopBarBottomPx = coords.boundsInWindow().bottom
                                }
                            ) {
                                TopAppBar(
                                    title = "运行日志",
                                    largeTitle = "运行日志",
                                    color = if (topBarClear) Color.Transparent else backgroundColor
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .topBarFrostedBlur(
                                    topBarBottomPx = subTopBarBottomPx,
                                    topBlurMode = themeConfig.topBarBlurMode,
                                    surfaceColor = backgroundColor,
                                    isDark = isDark
                                )
                        ) {
                            LogPage(
                                logs = logs,
                                currentLogLevel = globalConfig.logLevel,
                                onClearLogs = { viewModel.clearLogs() },
                                contentPadding = innerPadding
                            )
                        }
                    }
                }

                SecondaryRoute.Appearance -> {
                    AppearanceSettingsScreen(
                        themeConfig = themeConfig,
                        onUpdateThemeConfig = { updater -> viewModel.updateThemeConfig(updater) },
                        onBack = { secondaryRoute = SecondaryRoute.None },
                        topBarClearColor = false
                    )
                }

                SecondaryRoute.About -> {
                    AboutScreen(
                        onBack = { secondaryRoute = SecondaryRoute.None },
                        topBarClearColor = false
                    )
                }

                SecondaryRoute.None -> {
                    val navInsets = WindowInsets.navigationBars.asPaddingValues()
                    val floatingBottomPadding = PaddingValues(
                        bottom = navInsets.calculateBottomPadding() +
                            if (themeConfig.useFloatingBottomBar) 92.dp else 68.dp
                    )
                    var bottomBarRect by remember { mutableStateOf(Rect.Zero) }

                    // Page switch gesture modes:
                    // 0 = 跨轴拦截 (disables horizontal page swipe while vertical list is actively scrolling)
                    // 1 = 系统原生 (standard HorizontalPager gesture)
                    // 2 = 禁用滑动 (only switch pages via bottom bar tap or bottom bar horizontal slide)
                    val pagerSwipeEnabled = when (themeConfig.pageSwitchGesture) {
                        0 -> !isVerticalListScrolling
                        1 -> true
                        2 -> false
                        else -> true
                    }

                    val pagerSpringSpec = remember(themeConfig.pageSwitchGesture) {
                        spring<Float>(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = if (themeConfig.pageSwitchGesture == 0) {
                                Spring.StiffnessMediumLow
                            } else {
                                Spring.StiffnessLow
                            }
                        )
                    }

                    Box(modifier = Modifier.fillMaxSize()) {
                        // Stationary outer container for bottom capsule frosted blur so HorizontalPager page offsets
                        // NEVER shift the bottom capsule blur region horizontally across the screen!
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .bottomCapsuleFrostedBlur(
                                    bottomBarRect = bottomBarRect,
                                    bottomBlurMode = themeConfig.bottomBarBlurMode,
                                    isLiquidGlass = themeConfig.useFloatingBottomBar && themeConfig.enableLiquidGlass,
                                    surfaceColor = surfaceColor,
                                    isDark = isDark
                                )
                        ) {
                            HorizontalPager(
                                state = pagerState,
                                userScrollEnabled = pagerSwipeEnabled,
                                beyondViewportPageCount = 1,
                                pageSpacing = 0.dp,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .then(
                                        if (themeConfig.pageSwitchGesture == 0) {
                                            Modifier
                                                .nestedScroll(crossAxisScrollConnection)
                                                .pointerInput(Unit) {
                                                    awaitPointerEventScope {
                                                        while (true) {
                                                            val event = awaitPointerEvent()
                                                            if (event.changes.none { it.pressed }) {
                                                                isVerticalListScrolling = false
                                                            }
                                                        }
                                                    }
                                                }
                                        } else {
                                            Modifier
                                        }
                                    )
                            ) { page ->
                                val pageScrollBehavior = MiuixScrollBehavior()
                                var pageTopBarBottomPx by remember { mutableFloatStateOf(0f) }

                                Scaffold(
                                    modifier = Modifier.fillMaxSize(),
                                    topBar = {
                                        Box(
                                            modifier = Modifier.onGloballyPositioned { coords ->
                                                pageTopBarBottomPx = coords.boundsInWindow().bottom
                                            }
                                        ) {
                                            TopAppBar(
                                                title = navLabels[page],
                                                largeTitle = navLabels[page],
                                                scrollBehavior = pageScrollBehavior,
                                                color = if (topBarClear) Color.Transparent else backgroundColor,
                                                actions = {
                                                    when (page) {
                                                        0 -> {
                                                            ActionIconBox(
                                                                onClick = { viewModel.refreshAll() },
                                                                modifier = Modifier.padding(end = 8.dp),
                                                                iconType = 0
                                                            )
                                                        }
                                                        1 -> {
                                                            Row(
                                                                modifier = Modifier.padding(end = 8.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Box {
                                                                    ActionIconBox(
                                                                        onClick = { showAppFilterPopup = true },
                                                                        iconType = 1
                                                                    )
                                                                    MiuixTopPopupMenu(
                                                                        expanded = showAppFilterPopup,
                                                                        onDismissRequest = { showAppFilterPopup = false },
                                                                        width = 188.dp,
                                                                        actions = listOf(
                                                                            MiuixPopupAction("全部应用", selected = appFilterIndex == 0) {
                                                                                appFilterIndex = 0
                                                                            },
                                                                            MiuixPopupAction("推荐配置", selected = appFilterIndex == 1) {
                                                                                appFilterIndex = 1
                                                                            },
                                                                            MiuixPopupAction("受控 (SMillet)", selected = appFilterIndex == 2) {
                                                                                appFilterIndex = 2
                                                                            },
                                                                            MiuixPopupAction("智能 (系统默认)", selected = appFilterIndex == 3) {
                                                                                appFilterIndex = 3
                                                                            },
                                                                            MiuixPopupAction("白名单 (不冻结)", selected = appFilterIndex == 4) {
                                                                                appFilterIndex = 4
                                                                            },
                                                                            MiuixPopupAction("高耗电 (严管)", selected = appFilterIndex == 5) {
                                                                                appFilterIndex = 5
                                                                            },
                                                                            MiuixPopupAction("无限制", selected = appFilterIndex == 6) {
                                                                                appFilterIndex = 6
                                                                            },
                                                                            MiuixPopupAction("未优化 (电池白名单)", selected = appFilterIndex == 7) {
                                                                                appFilterIndex = 7
                                                                                viewModel.refreshBatteryOptimizationStates()
                                                                            }
                                                                        )
                                                                    )
                                                                }
                                                                Box {
                                                                    ActionIconBox(
                                                                        onClick = { showAppMorePopup = true },
                                                                        iconType = 2
                                                                    )
                                                                    MiuixTopPopupMenu(
                                                                        expanded = showAppMorePopup,
                                                                        onDismissRequest = { showAppMorePopup = false },
                                                                        width = 168.dp,
                                                                        actions = listOf(
                                                                            MiuixPopupAction("刷新列表") {
                                                                                viewModel.refreshApps()
                                                                                Toast.makeText(context, "正在刷新应用列表", Toast.LENGTH_SHORT).show()
                                                                            },
                                                                            MiuixPopupAction(
                                                                                title = if (includeSystemApps) "隐藏系统应用" else "显示系统应用",
                                                                                selected = includeSystemApps
                                                                            ) {
                                                                                includeSystemApps = !includeSystemApps
                                                                                viewModel.refreshBatteryOptimizationStates()
                                                                            }
                                                                        )
                                                                    )
                                                                }
                                                            }
                                                        }
                                                        2 -> {
                                                            Row(
                                                                modifier = Modifier.padding(end = 8.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                ActionIconBox(
                                                                    onClick = { viewModel.refreshRunningProcesses() },
                                                                    iconType = 0
                                                                )
                                                                Box {
                                                                    ActionIconBox(
                                                                        onClick = { showRunningFilterPopup = true },
                                                                        iconType = 1
                                                                    )
                                                                    MiuixTopPopupMenu(
                                                                        expanded = showRunningFilterPopup,
                                                                        onDismissRequest = { showRunningFilterPopup = false },
                                                                        width = 176.dp,
                                                                        actions = listOf(
                                                                            MiuixPopupAction("全部运行进程", selected = !showFrozenOnly) {
                                                                                showFrozenOnly = false
                                                                            },
                                                                            MiuixPopupAction("仅已冻结进程", selected = showFrozenOnly) {
                                                                                showFrozenOnly = true
                                                                            },
                                                                            MiuixPopupAction(
                                                                                title = "仅受控应用进程",
                                                                                selected = showOnlyTargetApps
                                                                            ) {
                                                                                showOnlyTargetApps = !showOnlyTargetApps
                                                                            }
                                                                        )
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            )
                                        }
                                    }
                                ) { innerPadding ->
                                    val combinedPadding = PaddingValues(
                                        top = innerPadding.calculateTopPadding(),
                                        bottom = floatingBottomPadding.calculateBottomPadding()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .topBarFrostedBlur(
                                                topBarBottomPx = pageTopBarBottomPx,
                                                topBlurMode = themeConfig.topBarBlurMode,
                                                surfaceColor = backgroundColor,
                                                isDark = isDark
                                            )
                                            .nestedScroll(pageScrollBehavior.nestedScrollConnection)
                                    ) {
                                        when (page) {
                                            0 -> HomePage(
                                                dashboardState = dashboardState,
                                                globalConfig = globalConfig,
                                                onToggleMasterSwitch = { enabled ->
                                                    viewModel.updateGlobalConfig { it.copy(masterSwitch = enabled) }
                                                },
                                                onUnfreezeAll = {
                                                    viewModel.unfreezeAll()
                                                    Toast.makeText(context, "已解冻全部受管进程", Toast.LENGTH_SHORT).show()
                                                },
                                                onNavigateToLogs = {
                                                    secondaryRoute = SecondaryRoute.Logs
                                                },
                                                contentPadding = combinedPadding
                                            )
                                            1 -> AppListPage(
                                                apps = appList,
                                                isLoading = isLoadingApps,
                                                searchQuery = appSearchQuery,
                                                onSearchQueryChange = { appSearchQuery = it },
                                                includeSystemApps = includeSystemApps,
                                                selectedFilterIndex = appFilterIndex,
                                                onSelectApp = { app ->
                                                    secondaryRoute = SecondaryRoute.AppDetail(app)
                                                },
                                                onRefresh = { viewModel.refreshApps() },
                                                contentPadding = combinedPadding
                                            )
                                            2 -> RunningListPage(
                                                processes = runningProcesses,
                                                isLoading = isLoadingRunning,
                                                searchQuery = runningSearchQuery,
                                                onSearchQueryChange = { runningSearchQuery = it },
                                                showFrozenOnly = showFrozenOnly,
                                                showOnlyTargetApps = showOnlyTargetApps,
                                                onRefresh = { viewModel.refreshRunningProcesses() },
                                                onToggleFreezeUid = { proc ->
                                                    viewModel.toggleFreezeProcess(proc)
                                                },
                                                onKillPid = { proc ->
                                                    viewModel.killProcess(proc)
                                                    Toast.makeText(
                                                        context,
                                                        "已结束 ${proc.processName} (PID ${proc.pid})",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                },
                                                contentPadding = combinedPadding
                                            )
                                            3 -> SettingsPage(
                                                globalConfig = globalConfig,
                                                onUpdateGlobalConfig = { updater -> viewModel.updateGlobalConfig(updater) },
                                                onResetGlobalConfig = { viewModel.resetGlobalConfig() },
                                                onClearLogs = { viewModel.clearLogs() },
                                                onNavigateToLogs = { secondaryRoute = SecondaryRoute.Logs },
                                                onExportConfig = {
                                                    exportConfigLauncher.launch("smillet_backup_${System.currentTimeMillis()}.json")
                                                },
                                                onImportConfig = {
                                                    importConfigLauncher.launch(arrayOf("application/json", "*/*"))
                                                },
                                                onOpenAppearance = {
                                                    secondaryRoute = SecondaryRoute.Appearance
                                                },
                                                onOpenAbout = {
                                                    secondaryRoute = SecondaryRoute.About
                                                },
                                                contentPadding = combinedPadding
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Bottom Navigation Bar (supports both tap and horizontal slide to switch tabs!)
                        val pagerFraction = (pagerState.currentPage + pagerState.currentPageOffsetFraction).coerceIn(0f, 3f)
                        val activePageFraction = bottomBarDragTab ?: pagerFraction

                        if (themeConfig.useFloatingBottomBar) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .padding(
                                        bottom = navInsets.calculateBottomPadding() + 14.dp,
                                        start = 22.dp,
                                        end = 22.dp
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (themeConfig.enableLiquidGlass) {
                                    LiquidGlassFloatingNavigationBar(
                                        items = navLabels,
                                        selectedIndex = pagerState.currentPage,
                                        pagePosition = activePageFraction,
                                        isDark = isDark,
                                        onBoundsChanged = { rect -> bottomBarRect = rect },
                                        onDragTabFraction = { dragFraction ->
                                            bottomBarDragTab = dragFraction
                                            val targetIdx = dragFraction.roundToInt().coerceIn(0, 3)
                                            if (targetIdx != pagerState.currentPage && !pagerState.isScrollInProgress) {
                                                scope.launch {
                                                    pagerState.animateScrollToPage(
                                                        page = targetIdx,
                                                        animationSpec = pagerSpringSpec
                                                    )
                                                }
                                            }
                                        },
                                        onDragTabEnd = {
                                            val finalIdx = (bottomBarDragTab ?: pagerFraction).roundToInt().coerceIn(0, 3)
                                            bottomBarDragTab = null
                                            if (finalIdx != pagerState.currentPage) {
                                                scope.launch {
                                                    pagerState.animateScrollToPage(
                                                        page = finalIdx,
                                                        animationSpec = pagerSpringSpec
                                                    )
                                                }
                                            }
                                        },
                                        onSelect = { idx ->
                                            bottomBarDragTab = null
                                            scope.launch {
                                                pagerState.animateScrollToPage(
                                                    page = idx,
                                                    animationSpec = pagerSpringSpec
                                                )
                                            }
                                        }
                                    )
                                } else {
                                    MiuixFloatingNavigationBar(
                                        items = navLabels,
                                        selectedIndex = pagerState.currentPage,
                                        pagePosition = activePageFraction,
                                        isDark = isDark,
                                        translucent = bottomBarClear,
                                        onBoundsChanged = { rect -> bottomBarRect = rect },
                                        onDragTabFraction = { dragFraction ->
                                            bottomBarDragTab = dragFraction
                                            val targetIdx = dragFraction.roundToInt().coerceIn(0, 3)
                                            if (targetIdx != pagerState.currentPage && !pagerState.isScrollInProgress) {
                                                scope.launch {
                                                    pagerState.animateScrollToPage(
                                                        page = targetIdx,
                                                        animationSpec = pagerSpringSpec
                                                    )
                                                }
                                            }
                                        },
                                        onDragTabEnd = {
                                            val finalIdx = (bottomBarDragTab ?: pagerFraction).roundToInt().coerceIn(0, 3)
                                            bottomBarDragTab = null
                                            if (finalIdx != pagerState.currentPage) {
                                                scope.launch {
                                                    pagerState.animateScrollToPage(
                                                        page = finalIdx,
                                                        animationSpec = pagerSpringSpec
                                                    )
                                                }
                                            }
                                        },
                                        onSelect = { idx ->
                                            bottomBarDragTab = null
                                            scope.launch {
                                                pagerState.animateScrollToPage(
                                                    page = idx,
                                                    animationSpec = pagerSpringSpec
                                                )
                                            }
                                        }
                                    )
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .onGloballyPositioned { coords ->
                                        bottomBarRect = coords.boundsInWindow()
                                    }
                                    .pointerInput(Unit) {
                                        detectHorizontalDragGestures(
                                            onDragEnd = { bottomBarDragTab = null },
                                            onDragCancel = { bottomBarDragTab = null }
                                        ) { change, _ ->
                                            change.consume()
                                            val w = size.width.toFloat().coerceAtLeast(1f)
                                            val f = ((change.position.x / w) * 4f - 0.5f).coerceIn(0f, 3f)
                                            bottomBarDragTab = f
                                            val targetIdx = f.roundToInt().coerceIn(0, 3)
                                            if (targetIdx != pagerState.currentPage && !pagerState.isScrollInProgress) {
                                                scope.launch {
                                                    pagerState.animateScrollToPage(
                                                        page = targetIdx,
                                                        animationSpec = pagerSpringSpec
                                                    )
                                                }
                                            }
                                        }
                                    }
                            ) {
                                NavigationBar(
                                    items = standardNavItems,
                                    selected = pagerState.currentPage,
                                    onClick = { idx ->
                                        scope.launch {
                                            pagerState.animateScrollToPage(
                                                page = idx,
                                                animationSpec = pagerSpringSpec
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiuixFloatingNavigationBar(
    items: List<String>,
    selectedIndex: Int,
    pagePosition: Float,
    isDark: Boolean,
    translucent: Boolean,
    onBoundsChanged: (Rect) -> Unit,
    onDragTabFraction: (Float) -> Unit,
    onDragTabEnd: () -> Unit,
    onSelect: (Int) -> Unit
) {
    val capsuleShape = RoundedCornerShape(33.dp)
    val baseSurface = MiuixTheme.colorScheme.surface
    val containerColor = when {
        translucent -> if (isDark) baseSurface.copy(alpha = 0.72f) else baseSurface.copy(alpha = 0.82f)
        else -> if (isDark) Color(0xFF242427) else Color(0xFFFFFFFF)
    }
    val borderColor = if (isDark) {
        Color.White.copy(alpha = 0.12f)
    } else {
        Color.Black.copy(alpha = 0.07f)
    }

    val smoothIndicatorPos by animateFloatAsState(
        targetValue = pagePosition.coerceIn(0f, (items.size - 1).toFloat()),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "FloatingNavIndicator"
    )
    val primaryColor = MiuixTheme.colorScheme.primary
    val pillFill = if (isDark) {
        primaryColor.copy(alpha = 0.22f)
    } else {
        primaryColor.copy(alpha = 0.12f)
    }

    Box(
        modifier = Modifier
            .widthIn(max = 376.dp)
            .fillMaxWidth()
            .height(64.dp)
            .onGloballyPositioned { coords ->
                onBoundsChanged(coords.boundsInWindow())
            }
            .then(
                if (!translucent) {
                    Modifier.shadow(
                        elevation = if (isDark) 12.dp else 8.dp,
                        shape = capsuleShape,
                        ambientColor = Color.Black.copy(alpha = 0.14f),
                        spotColor = Color.Black.copy(alpha = 0.16f)
                    )
                } else {
                    Modifier
                }
            )
            .clip(capsuleShape)
            .background(containerColor)
            .border(width = 0.8.dp, color = borderColor, shape = capsuleShape)
            .pointerInput(items.size) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        val w = size.width.toFloat().coerceAtLeast(1f)
                        val f = ((offset.x / w) * items.size - 0.5f).coerceIn(0f, (items.size - 1).toFloat())
                        onDragTabFraction(f)
                    },
                    onDragEnd = { onDragTabEnd() },
                    onDragCancel = { onDragTabEnd() }
                ) { change, _ ->
                    change.consume()
                    val w = size.width.toFloat().coerceAtLeast(1f)
                    val f = ((change.position.x / w) * items.size - 0.5f).coerceIn(0f, (items.size - 1).toFloat())
                    onDragTabFraction(f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val padH = 6.dp.toPx()
            val padV = 5.dp.toPx()
            val slotW = (size.width - padH * 2f) / items.size.coerceAtLeast(1)
            val pillH = size.height - padV * 2f
            val pillLeft = padH + slotW * smoothIndicatorPos
            drawRoundRect(
                color = pillFill,
                topLeft = Offset(pillLeft, padV),
                size = Size(slotW, pillH),
                cornerRadius = CornerRadius(pillH / 2f, pillH / 2f)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { idx, label ->
                val isSelected = selectedIndex == idx
                val tint = if (isSelected) {
                    MiuixTheme.colorScheme.primary
                } else {
                    if (isDark) Color(0xFFA0A4AB) else Color(0xFF3A3D42)
                }
                val interactionSource = remember { MutableInteractionSource() }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null
                        ) { onSelect(idx) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    NavTabVectorIcon(
                        index = idx,
                        tint = tint,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                        color = tint
                    )
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassFloatingNavigationBar(
    items: List<String>,
    selectedIndex: Int,
    pagePosition: Float,
    isDark: Boolean,
    onBoundsChanged: (Rect) -> Unit,
    onDragTabFraction: (Float) -> Unit,
    onDragTabEnd: () -> Unit,
    onSelect: (Int) -> Unit
) {
    val capsuleShape = RoundedCornerShape(33.dp)
    val smoothIndicatorPos by animateFloatAsState(
        targetValue = pagePosition.coerceIn(0f, (items.size - 1).toFloat()),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "LiquidPillOffset"
    )
    val primaryColor = MiuixTheme.colorScheme.primary

    // Notice: NO .shadow() on LiquidGlassFloatingNavigationBar because Android's elevation shadow
    // fills the interior behind a translucent view with dark/gray ambient shadow!
    // Everything is drawn cleanly inside Canvas clipped to capsuleShape.
    Box(
        modifier = Modifier
            .widthIn(max = 376.dp)
            .fillMaxWidth()
            .height(64.dp)
            .onGloballyPositioned { coords ->
                onBoundsChanged(coords.boundsInWindow())
            }
            .clip(capsuleShape)
            .pointerInput(items.size) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        val w = size.width.toFloat().coerceAtLeast(1f)
                        val f = ((offset.x / w) * items.size - 0.5f).coerceIn(0f, (items.size - 1).toFloat())
                        onDragTabFraction(f)
                    },
                    onDragEnd = { onDragTabEnd() },
                    onDragCancel = { onDragTabEnd() }
                ) { change, _ ->
                    change.consume()
                    val w = size.width.toFloat().coerceAtLeast(1f)
                    val f = ((change.position.x / w) * items.size - 0.5f).coerceIn(0f, (items.size - 1).toFloat())
                    onDragTabFraction(f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val outerR = size.height / 2f
            // 1. Translucent liquid glass body fill
            val glassBrush = if (isDark) {
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.16f),
                        Color(0xFF1E222B).copy(alpha = 0.44f),
                        Color.White.copy(alpha = 0.10f)
                    )
                )
            } else {
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.68f),
                        Color(0xFFF6F9FF).copy(alpha = 0.42f),
                        Color.White.copy(alpha = 0.60f)
                    )
                )
            }
            drawRoundRect(
                brush = glassBrush,
                topLeft = Offset.Zero,
                size = size,
                cornerRadius = CornerRadius(outerR, outerR)
            )

            // 2. Specular outer rim highlight
            val outerRimBrush = Brush.linearGradient(
                colors = if (isDark) {
                    listOf(
                        Color.White.copy(alpha = 0.42f),
                        Color.White.copy(alpha = 0.10f),
                        Color.White.copy(alpha = 0.28f)
                    )
                } else {
                    listOf(
                        Color.White.copy(alpha = 0.92f),
                        Color.Black.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.78f)
                    )
                },
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            )
            drawRoundRect(
                brush = outerRimBrush,
                topLeft = Offset(0.6.dp.toPx(), 0.6.dp.toPx()),
                size = Size(size.width - 1.2.dp.toPx(), size.height - 1.2.dp.toPx()),
                cornerRadius = CornerRadius(outerR, outerR),
                style = Stroke(width = 1.15.dp.toPx())
            )

            // 3. Sliding active Liquid Glass pill indicator (exact 1/4 slot width, properly inset)
            val padH = 6.dp.toPx()
            val padV = 5.dp.toPx()
            val slotW = (size.width - padH * 2f) / items.size.coerceAtLeast(1)
            val pillH = size.height - padV * 2f
            val pillR = pillH / 2f
            val pillLeft = padH + slotW * smoothIndicatorPos

            val pillFillBrush = Brush.verticalGradient(
                colors = if (isDark) {
                    listOf(
                        Color.White.copy(alpha = 0.22f),
                        primaryColor.copy(alpha = 0.24f),
                        Color.White.copy(alpha = 0.12f)
                    )
                } else {
                    listOf(
                        Color.White.copy(alpha = 0.88f),
                        primaryColor.copy(alpha = 0.14f),
                        Color.White.copy(alpha = 0.72f)
                    )
                },
                startY = padV,
                endY = padV + pillH
            )
            drawRoundRect(
                brush = pillFillBrush,
                topLeft = Offset(pillLeft, padV),
                size = Size(slotW, pillH),
                cornerRadius = CornerRadius(pillR, pillR)
            )

            val pillRimBrush = Brush.verticalGradient(
                colors = if (isDark) {
                    listOf(
                        Color.White.copy(alpha = 0.45f),
                        primaryColor.copy(alpha = 0.25f)
                    )
                } else {
                    listOf(
                        Color.White.copy(alpha = 0.96f),
                        primaryColor.copy(alpha = 0.22f)
                    )
                },
                startY = padV,
                endY = padV + pillH
            )
            drawRoundRect(
                brush = pillRimBrush,
                topLeft = Offset(pillLeft, padV),
                size = Size(slotW, pillH),
                cornerRadius = CornerRadius(pillR, pillR),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { idx, label ->
                val isSelected = selectedIndex == idx
                val tint = if (isSelected) {
                    primaryColor
                } else {
                    if (isDark) Color(0xFFD5D9E0) else Color(0xFF2E3136)
                }
                val interactionSource = remember { MutableInteractionSource() }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null
                        ) { onSelect(idx) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    NavTabVectorIcon(
                        index = idx,
                        tint = tint,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                        color = tint
                    )
                }
            }
        }
    }
}

@Composable
private fun NavTabVectorIcon(
    index: Int,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val sw = 2.05.dp.toPx()
        val r = 2.6.dp.toPx()

        when (index) {
            0 -> {
                // Home: left tall rounded rect + right two stacked rounded squares (Mishka style)
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.13f, h * 0.14f),
                    size = Size(w * 0.31f, h * 0.72f),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = sw)
                )
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.55f, h * 0.14f),
                    size = Size(w * 0.31f, h * 0.31f),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = sw)
                )
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.55f, h * 0.55f),
                    size = Size(w * 0.31f, h * 0.31f),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = sw)
                )
            }
            1 -> {
                // App List: 2x2 grid with top-right circle (Mishka style)
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.14f, h * 0.14f),
                    size = Size(w * 0.30f, h * 0.30f),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = sw)
                )
                drawCircle(
                    color = tint,
                    radius = w * 0.155f,
                    center = Offset(w * 0.70f, h * 0.29f),
                    style = Stroke(width = sw)
                )
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.14f, h * 0.56f),
                    size = Size(w * 0.30f, h * 0.30f),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = sw)
                )
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.55f, h * 0.56f),
                    size = Size(w * 0.30f, h * 0.30f),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = sw)
                )
            }
            2 -> {
                // Running List: rounded square with pulse waveform (Mishka style)
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.14f, h * 0.14f),
                    size = Size(w * 0.72f, h * 0.72f),
                    cornerRadius = CornerRadius(r * 1.3f, r * 1.3f),
                    style = Stroke(width = sw)
                )
                val pulsePath = Path().apply {
                    moveTo(w * 0.26f, h * 0.52f)
                    lineTo(w * 0.38f, h * 0.52f)
                    lineTo(w * 0.45f, h * 0.34f)
                    lineTo(w * 0.55f, h * 0.68f)
                    lineTo(w * 0.62f, h * 0.52f)
                    lineTo(w * 0.74f, h * 0.52f)
                }
                drawPath(
                    path = pulsePath,
                    color = tint,
                    style = Stroke(width = sw * 0.92f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
            else -> {
                // Settings: hexagon nut + inner circle (Mishka style)
                val cx = w / 2f
                val cy = h / 2f
                val hexR = w * 0.39f
                val hexPath = Path()
                for (i in 0 until 6) {
                    val deg = -90.0 + i * 60.0
                    val rad = Math.toRadians(deg)
                    val px = cx + (hexR * kotlin.math.cos(rad)).toFloat()
                    val py = cy + (hexR * kotlin.math.sin(rad)).toFloat()
                    if (i == 0) hexPath.moveTo(px, py) else hexPath.lineTo(px, py)
                }
                hexPath.close()
                drawPath(
                    path = hexPath,
                    color = tint,
                    style = Stroke(width = sw, join = StrokeJoin.Round)
                )
                drawCircle(
                    color = tint,
                    radius = w * 0.125f,
                    center = Offset(cx, cy),
                    style = Stroke(width = sw)
                )
            }
        }
    }
}
