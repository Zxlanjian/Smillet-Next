package com.sidesand.millet.ui.pages

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.model.GlobalConfig
import com.sidesand.millet.model.ThemeConfig
import com.sidesand.millet.ui.theme.KEY_COLORS
import com.sidesand.millet.util.RootShell
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.extra.SuperArrow
import top.yukonga.miuix.kmp.extra.SuperDialog
import top.yukonga.miuix.kmp.extra.SuperDropdown
import top.yukonga.miuix.kmp.extra.SuperSwitch
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Back
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import kotlin.math.roundToInt

@Composable
fun SettingsPage(
    globalConfig: GlobalConfig,
    onUpdateGlobalConfig: ((GlobalConfig) -> GlobalConfig) -> Unit,
    onResetGlobalConfig: () -> Unit,
    onClearLogs: () -> Unit,
    onNavigateToLogs: () -> Unit,
    onExportConfig: () -> Unit,
    onImportConfig: () -> Unit,
    onOpenAppearance: () -> Unit,
    onOpenAbout: () -> Unit,
    contentPadding: PaddingValues = PaddingValues(0.dp)
) {
    val context = LocalContext.current

    var editingDialogTitle by remember { mutableStateOf("") }
    var editingDialogHint by remember { mutableStateOf("") }
    var editingDialogValue by remember { mutableStateOf("") }
    var onDialogConfirm by remember { mutableStateOf<(String) -> Unit>({}) }
    val showEditDialog = remember { mutableStateOf(false) }
    val showResetDialog = remember { mutableStateOf(false) }

    fun openNumberEditor(title: String, hint: String, currentValue: String, onSave: (String) -> Unit) {
        editingDialogTitle = title
        editingDialogHint = hint
        editingDialogValue = currentValue
        onDialogConfirm = onSave
        showEditDialog.value = true
    }

    val logLevelLabels = listOf("调试", "信息", "无")
    val logLevelValues = listOf("debug", "info", "none")
    val currentLogLevelIdx = logLevelValues.indexOf(globalConfig.logLevel.lowercase()).coerceAtLeast(0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .overScrollVertical(),
        contentPadding = PaddingValues(
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 28.dp
        )
    ) {
        item {
            SmallTitle(text = "核心与全局引擎")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                SwitchPreference(
                    title = "启用 SMillet 冻结引擎",
                    summary = "全局总开关，关闭后暂停所有自动压制与解冻逻辑",
                    checked = globalConfig.masterSwitch,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(masterSwitch = v) } }
                )
                SwitchPreference(
                    title = "接管并禁用小米自带 Millet",
                    summary = "拦截系统 PowerKeeper 对 Cgroup Freezer 的冲突写入",
                    checked = globalConfig.disableMillet,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(disableMillet = v) } }
                )
                SwitchPreference(
                    title = "同步省电策略为无限制",
                    summary = "启用时将已纳管应用省电策略设为无限制，关闭时恢复系统默认智能省电",
                    checked = globalConfig.syncNoRestrictPower,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(syncNoRestrictPower = v) } }
                )
                DropdownPreference(
                    title = "默认冻结底层方式",
                    summary = "优先推荐使用 Cgroup v2 Freezer，兼容性更佳",
                    items = listOf("Cgroup v2 (uid_0/freeze)", "Cgroup v1 (freezer.state)", "SIGSTOP 信号"),
                    selectedIndex = globalConfig.freezeMethod.coerceIn(0, 2),
                    onSelectedIndexChange = { idx -> onUpdateGlobalConfig { it.copy(freezeMethod = idx) } }
                )
                ArrowPreference(
                    title = "进入后台延迟冻结时间",
                    summary = "应用切入后台后等待多久执行冻结（秒）",
                    value = "${globalConfig.freezeDelaySec} 秒",
                    onClick = {
                        openNumberEditor(
                            title = "进入后台延迟冻结时间 (秒)",
                            hint = "推荐值 3 ~ 30 秒",
                            currentValue = globalConfig.freezeDelaySec.toString()
                        ) { input ->
                            val v = input.toIntOrNull()?.coerceIn(1, 3600) ?: globalConfig.freezeDelaySec
                            onUpdateGlobalConfig { it.copy(freezeDelaySec = v) }
                        }
                    }
                )
                ArrowPreference(
                    title = "亮屏周期性巡检间隔",
                    summary = "定期复查后台进程状态的时间间隔（秒）",
                    value = "${globalConfig.periodicCheckSec} 秒",
                    onClick = {
                        openNumberEditor(
                            title = "周期性巡检间隔 (秒)",
                            hint = "推荐值 30 ~ 300 秒",
                            currentValue = globalConfig.periodicCheckSec.toString()
                        ) { input ->
                            val v = input.toIntOrNull()?.coerceIn(5, 7200) ?: globalConfig.periodicCheckSec
                            onUpdateGlobalConfig { it.copy(periodicCheckSec = v) }
                        }
                    }
                )
            }
        }

        item {
            SmallTitle(text = "后台豁免与临时解冻")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                SwitchPreference(
                    title = "音频播放豁免冻结",
                    summary = "应用持有活跃 AudioFocus 或正在播放媒体时跳过冻结",
                    checked = globalConfig.exemptAudioPlayback,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(exemptAudioPlayback = v) } }
                )
                SwitchPreference(
                    title = "前台服务豁免冻结",
                    summary = "带有通知栏常驻或定位/导航前台服务时暂缓冻结",
                    checked = globalConfig.exemptForegroundService,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(exemptForegroundService = v) } }
                )
                SwitchPreference(
                    title = "悬浮窗可见豁免冻结",
                    summary = "应用存在可见 SYSTEM_ALERT_WINDOW 悬浮窗时不冻结",
                    checked = globalConfig.exemptOverlayWindow,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(exemptOverlayWindow = v) } }
                )
                SwitchPreference(
                    title = "VPN / 代理服务豁免",
                    summary = "保护活跃的 VPN 隧道进程防止断流",
                    checked = globalConfig.exemptVpnService,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(exemptVpnService = v) } }
                )
                SwitchPreference(
                    title = "息屏深度压制模式",
                    summary = "屏幕关闭后缩短延迟并收紧临时唤醒配额",
                    checked = globalConfig.screenOffDeepFreeze,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(screenOffDeepFreeze = v) } }
                )
                SwitchPreference(
                    title = "Binder 阻塞自动临时解冻",
                    summary = "当冻结进程收到关键同步 Binder 事务或通知时短暂解冻",
                    checked = globalConfig.autoUnfreezeOnBinder,
                    onCheckedChange = { v -> onUpdateGlobalConfig { it.copy(autoUnfreezeOnBinder = v) } }
                )
                ArrowPreference(
                    title = "临时解冻维持时长",
                    summary = "唤醒处理完消息后重新冻结的等待窗口（毫秒）",
                    value = "${globalConfig.tempUnfreezeDurationMs} ms",
                    onClick = {
                        openNumberEditor(
                            title = "临时解冻维持时长 (ms)",
                            hint = "推荐值 1500 ~ 10000 毫秒",
                            currentValue = globalConfig.tempUnfreezeDurationMs.toString()
                        ) { input ->
                            val v = input.toLongOrNull()?.coerceIn(500L, 60000L) ?: globalConfig.tempUnfreezeDurationMs
                            onUpdateGlobalConfig { it.copy(tempUnfreezeDurationMs = v) }
                        }
                    }
                )
            }
        }

        item {
            SmallTitle(text = "日志与备份")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                ArrowPreference(
                    title = "日志",
                    summary = "查看当前运行日志、按级别筛选或导出日志文件",
                    onClick = onNavigateToLogs
                )
                DropdownPreference(
                    title = "日志级别",
                    summary = "设置运行日志输出档位（调试 / 信息 / 无）",
                    items = logLevelLabels,
                    selectedIndex = currentLogLevelIdx,
                    onSelectedIndexChange = { idx ->
                        onUpdateGlobalConfig { it.copy(logLevel = logLevelValues[idx]) }
                    }
                )
                ArrowPreference(
                    title = "清空运行日志",
                    summary = "立即清除内存与本地缓存的运行日志",
                    onClick = {
                        onClearLogs()
                        Toast.makeText(context, "日志已清空", Toast.LENGTH_SHORT).show()
                    }
                )
                ArrowPreference(
                    title = "备份配置到本地",
                    summary = "导出全局设置与应用专属规则为 JSON 文件",
                    onClick = onExportConfig
                )
                ArrowPreference(
                    title = "从本地恢复配置",
                    summary = "选择已备份的 JSON 配置文件进行导入",
                    onClick = onImportConfig
                )
                ArrowPreference(
                    title = "恢复默认配置",
                    summary = "将全局参数还原为初始推荐值",
                    onClick = { showResetDialog.value = true }
                )
            }
        }

        item {
            SmallTitle(text = "快捷系统操作")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                ArrowPreference(
                    title = "一键解冻全部进程",
                    summary = "遇到异常卡死时立即恢复所有 Cgroup v1/v2 冻结状态",
                    onClick = {
                        val count = RootShell.unfreezeAllWatchedUids()
                        Toast.makeText(context, "已触发全量解冻 ($count 项)", Toast.LENGTH_SHORT).show()
                    }
                )
                ArrowPreference(
                    title = "重启电量与性能 (PowerKeeper)",
                    summary = "杀死 com.miui.powerkeeper 进程以重新触发 Hook 注入",
                    onClick = {
                        val res = RootShell.exec("killall com.miui.powerkeeper || pkill -f com.miui.powerkeeper")
                        Toast.makeText(
                            context,
                            if (res.isSuccess) "已重启 PowerKeeper" else "执行完成: ${res.stderr.ifBlank { "OK" }}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }

        item {
            SmallTitle(text = "其他")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                ArrowPreference(
                    title = "外观与主题",
                    summary = "颜色、模糊效果与界面缩放，导航与手势选项",
                    onClick = onOpenAppearance
                )
                ArrowPreference(
                    title = "关于",
                    summary = "Smillet-Next v1.0.0",
                    onClick = onOpenAbout
                )
            }
        }
    }

    SuperDialog(
        title = editingDialogTitle,
        summary = editingDialogHint,
        show = showEditDialog,
        onDismissRequest = { showEditDialog.value = false }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            TextField(
                value = editingDialogValue,
                onValueChange = { editingDialogValue = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TextButton(
                    text = "取消",
                    onClick = { showEditDialog.value = false },
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    text = "保存",
                    onClick = {
                        onDialogConfirm(editingDialogValue.trim())
                        showEditDialog.value = false
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColorsPrimary()
                )
            }
        }
    }

    SuperDialog(
        title = "恢复默认配置",
        summary = "确定要将所有全局冻结参数恢复为出厂推荐值吗？",
        show = showResetDialog,
        onDismissRequest = { showResetDialog.value = false }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TextButton(
                text = "取消",
                onClick = { showResetDialog.value = false },
                modifier = Modifier.weight(1f)
            )
            TextButton(
                text = "确认恢复",
                onClick = {
                    onResetGlobalConfig()
                    showResetDialog.value = false
                    Toast.makeText(context, "已恢复默认全局配置", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary()
            )
        }
    }
}

@Composable
fun AppearanceSettingsScreen(
    themeConfig: ThemeConfig,
    onUpdateThemeConfig: ((ThemeConfig) -> ThemeConfig) -> Unit,
    onBack: () -> Unit,
    topBarBlurModifier: Modifier = Modifier,
    topBarClearColor: Boolean = false
) {
    val scrollBehavior = MiuixScrollBehavior()
    val supportsBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    Scaffold(
        topBar = {
            TopAppBar(
                title = "外观与主题",
                largeTitle = "外观与主题",
                scrollBehavior = scrollBehavior,
                color = if (topBarClearColor) Color.Transparent else MiuixTheme.colorScheme.background,
                navigationIcon = {
                    Box(
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable { onBack() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = MiuixIcons.Back,
                            contentDescription = "返回",
                            tint = MiuixTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(topBarBlurModifier)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .nestedScroll(scrollBehavior.nestedScrollConnection)
                    .overScrollVertical(),
                contentPadding = PaddingValues(
                    top = innerPadding.calculateTopPadding() + 8.dp,
                    bottom = innerPadding.calculateBottomPadding() + 36.dp
                )
            ) {
                item {
                    SmallTitle(text = "主题")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        DropdownPreference(
                            title = "深色模式",
                            items = ThemeConfig.THEME_MODE_LABELS,
                            selectedIndex = themeConfig.themeMode.coerceIn(0, ThemeConfig.THEME_MODE_LABELS.lastIndex),
                            onSelectedIndexChange = { idx -> onUpdateThemeConfig { it.copy(themeMode = idx) } }
                        )
                        DropdownPreference(
                            title = "调色板风格",
                            items = ThemeConfig.PALETTE_STYLE_LABELS,
                            selectedIndex = themeConfig.paletteStyle.coerceIn(0, ThemeConfig.PALETTE_STYLE_LABELS.lastIndex),
                            onSelectedIndexChange = { idx -> onUpdateThemeConfig { it.copy(paletteStyle = idx) } }
                        )
                        DropdownPreference(
                            title = "色彩规格",
                            items = ThemeConfig.COLOR_SPEC_LABELS,
                            selectedIndex = themeConfig.colorSpec.coerceIn(0, ThemeConfig.COLOR_SPEC_LABELS.lastIndex),
                            onSelectedIndexChange = { idx -> onUpdateThemeConfig { it.copy(colorSpec = idx) } }
                        )
                        SwitchPreference(
                            title = "动态取色",
                            summary = "跟随系统壁纸自动生成莫奈主题色 (Android 12+)",
                            checked = themeConfig.useDynamicColor,
                            onCheckedChange = { v -> onUpdateThemeConfig { it.copy(useDynamicColor = v) } }
                        )
                        if (!themeConfig.useDynamicColor) {
                            ColorPaletteSelectorRow(
                                selectedIndex = themeConfig.keyColorIndex,
                                onSelect = { idx -> onUpdateThemeConfig { it.copy(keyColorIndex = idx) } }
                            )
                        }
                    }
                }

                item {
                    SmallTitle(text = "模糊效果")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        DropdownPreference(
                            title = "顶部应用栏模糊效果",
                            items = ThemeConfig.BLUR_MODE_LABELS,
                            selectedIndex = if (supportsBlur) {
                                themeConfig.topBarBlurMode.coerceIn(0, ThemeConfig.BLUR_MODE_LABELS.lastIndex)
                            } else {
                                2
                            },
                            onSelectedIndexChange = { idx ->
                                if (supportsBlur) {
                                    onUpdateThemeConfig { it.copy(topBarBlurMode = idx) }
                                }
                            }
                        )
                        DropdownPreference(
                            title = "底部导航栏模糊效果",
                            items = ThemeConfig.BLUR_MODE_LABELS,
                            selectedIndex = if (supportsBlur) {
                                themeConfig.bottomBarBlurMode.coerceIn(0, ThemeConfig.BLUR_MODE_LABELS.lastIndex)
                            } else {
                                2
                            },
                            onSelectedIndexChange = { idx ->
                                if (supportsBlur) {
                                    onUpdateThemeConfig { it.copy(bottomBarBlurMode = idx) }
                                }
                            }
                        )
                    }
                }

                item {
                    SmallTitle(text = "导航栏")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        SwitchPreference(
                            title = "启用浮动底栏",
                            summary = "使用胶囊悬浮式底部导航栏，可在底栏左右滑动切换页面",
                            checked = themeConfig.useFloatingBottomBar,
                            onCheckedChange = { v -> onUpdateThemeConfig { it.copy(useFloatingBottomBar = v) } }
                        )
                        if (themeConfig.useFloatingBottomBar) {
                            SwitchPreference(
                                title = "启用iOS液态玻璃效果",
                                summary = "为浮动底栏启用高通透液态折射质感及滑动胶囊高光",
                                checked = themeConfig.enableLiquidGlass,
                                onCheckedChange = { v -> onUpdateThemeConfig { it.copy(enableLiquidGlass = v) } }
                            )
                        }
                    }
                }

                item {
                    SmallTitle(text = "界面与动画")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        DropdownPreference(
                            title = "页面切换手势",
                            items = ThemeConfig.PAGE_SWITCH_GESTURE_LABELS,
                            selectedIndex = themeConfig.pageSwitchGesture.coerceIn(
                                0,
                                ThemeConfig.PAGE_SWITCH_GESTURE_LABELS.lastIndex
                            ),
                            onSelectedIndexChange = { idx ->
                                onUpdateThemeConfig { it.copy(pageSwitchGesture = idx) }
                            }
                        )
                        SwitchPreference(
                            title = "启用预测性返回手势",
                            summary = "在二级页面及非主页标签支持系统预测性返回手势",
                            checked = themeConfig.enablePredictiveBack,
                            onCheckedChange = { v -> onUpdateThemeConfig { it.copy(enablePredictiveBack = v) } }
                        )
                        UiScalePreferenceItem(
                            scalePercent = themeConfig.uiScalePercent,
                            onScaleCommitted = { newScale ->
                                onUpdateThemeConfig { it.copy(uiScalePercent = newScale) }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UiScalePreferenceItem(
    scalePercent: Int,
    onScaleCommitted: (Int) -> Unit
) {
    // Wait until pointer release before committing density scale so dragging stays smooth
    var sliderVal by remember(scalePercent) {
        mutableFloatStateOf(scalePercent.coerceIn(75, 125).toFloat())
    }
    val displayInt = ((sliderVal / 5f).roundToInt() * 5).coerceIn(75, 125)
    val fraction = ((sliderVal - 75f) / 50f).coerceIn(0f, 1f)

    val activeTrackColor = MiuixTheme.colorScheme.primary
    val inactiveTrackColor = MiuixTheme.colorScheme.secondaryContainer.copy(alpha = 0.72f)
    val thumbColor = Color.White

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "界面缩放比例",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = MiuixTheme.colorScheme.onSurface
            )
            Text(
                text = "${displayInt}%",
                fontSize = 15.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        // Matches Miuix Switch track height (28.5.dp) and Switch white thumb circle (20.5.dp diameter) 1:1
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.5.dp)
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val f = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        sliderVal = 75f + f * 50f
                        val committed = ((sliderVal / 5f).roundToInt() * 5).coerceIn(75, 125)
                        sliderVal = committed.toFloat()
                        onScaleCommitted(committed)
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            val committed = ((sliderVal / 5f).roundToInt() * 5).coerceIn(75, 125)
                            sliderVal = committed.toFloat()
                            onScaleCommitted(committed)
                        },
                        onDragCancel = {
                            val committed = ((sliderVal / 5f).roundToInt() * 5).coerceIn(75, 125)
                            sliderVal = committed.toFloat()
                            onScaleCommitted(committed)
                        }
                    ) { change, _ ->
                        change.consume()
                        val f = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                        sliderVal = 75f + f * 50f
                    }
                }
        ) {
            val trackH = size.height
            val radius = trackH / 2f
            // Thumb radius matches Miuix Switch white thumb circle (10.25.dp radius = 20.5.dp diameter)
            val thumbRadius = 10.25.dp.toPx()
            val minThumbX = radius
            val maxThumbX = (size.width - radius).coerceAtLeast(minThumbX)
            val thumbX = minThumbX + (maxThumbX - minThumbX) * fraction

            // Inactive background capsule
            drawRoundRect(
                color = inactiveTrackColor,
                topLeft = Offset.Zero,
                size = Size(size.width, trackH),
                cornerRadius = CornerRadius(radius, radius)
            )
            // Active fill capsule up to thumb right edge
            val activeW = (thumbX + radius).coerceIn(trackH, size.width)
            drawRoundRect(
                color = activeTrackColor,
                topLeft = Offset.Zero,
                size = Size(activeW, trackH),
                cornerRadius = CornerRadius(radius, radius)
            )
            // White thumb circle matching Switch thumb size
            drawCircle(
                color = thumbColor,
                radius = thumbRadius,
                center = Offset(thumbX, trackH / 2f)
            )
        }
    }
}

@Composable
fun AboutScreen(
    onBack: () -> Unit,
    topBarBlurModifier: Modifier = Modifier,
    topBarClearColor: Boolean = false
) {
    val context = LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()

    Scaffold(
        topBar = {
            TopAppBar(
                title = "关于",
                largeTitle = "关于",
                scrollBehavior = scrollBehavior,
                color = if (topBarClearColor) Color.Transparent else MiuixTheme.colorScheme.background,
                navigationIcon = {
                    Box(
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable { onBack() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = MiuixIcons.Back,
                            contentDescription = "返回",
                            tint = MiuixTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(topBarBlurModifier)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .nestedScroll(scrollBehavior.nestedScrollConnection)
                    .overScrollVertical(),
                contentPadding = PaddingValues(
                    top = innerPadding.calculateTopPadding() + 18.dp,
                    bottom = innerPadding.calculateBottomPadding() + 36.dp
                )
            ) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color(0xFF1F2733)),
                            contentAlignment = Alignment.Center
                        ) {
                            SnowflakeVectorGraphic(modifier = Modifier.size(54.dp))
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Smillet-Next",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MiuixTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "v1.0.0 (1)",
                            fontSize = 14.sp,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "针对 HyperOS / MIUI 深度定制的墓碑与 Cgroup 冻结增强模块",
                            fontSize = 13.sp,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )
                    }
                }

                item {
                    SmallTitle(text = "开发者与开源")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        ArrowPreference(
                            title = "开发者",
                            summary = "Sidesand",
                            onClick = {}
                        )
                        ArrowPreference(
                            title = "UI 组件库",
                            summary = "Miuix KMP (top.yukonga.miuix.kmp)",
                            onClick = {
                                runCatching {
                                    context.startActivity(
                                        Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse("https://github.com/miuix-kotlin-multiplatform/miuix")
                                        )
                                    )
                                }
                            }
                        )
                        ArrowPreference(
                            title = "Xposed API 框架",
                            summary = "libxposed API 102 + Legacy Xposed 82 双轨兼容",
                            onClick = {}
                        )
                        ArrowPreference(
                            title = "开源许可协议",
                            summary = "GPL-3.0 License",
                            onClick = {}
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ColorPaletteSelectorRow(
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = "主题强调色",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = MiuixTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            KEY_COLORS.forEachIndexed { idx, (_, color) ->
                val isSelected = selectedIndex == idx
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color)
                        .then(
                            if (isSelected) {
                                Modifier.border(3.dp, MiuixTheme.colorScheme.onSurface, CircleShape)
                            } else {
                                Modifier
                            }
                        )
                        .clickable { onSelect(idx) },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SnowflakeVectorGraphic(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.42f
        val stroke = size.minDimension * 0.08f
        val iceBlue = Color(0xFF5AB2FF)

        for (i in 0 until 3) {
            val angleRad = Math.toRadians((i * 60).toDouble())
            val dx = (r * kotlin.math.cos(angleRad)).toFloat()
            val dy = (r * kotlin.math.sin(angleRad)).toFloat()
            drawLine(
                color = iceBlue,
                start = Offset(cx - dx, cy - dy),
                end = Offset(cx + dx, cy + dy),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
        drawCircle(
            color = Color.White,
            radius = stroke * 1.15f,
            center = Offset(cx, cy)
        )
    }
}

@Composable
fun SwitchPreference(
    title: String,
    summary: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    SuperSwitch(
        title = title,
        summary = summary,
        checked = checked,
        onCheckedChange = onCheckedChange
    )
}

@Composable
fun DropdownPreference(
    title: String,
    summary: String? = null,
    items: List<String>,
    selectedIndex: Int,
    onSelectedIndexChange: (Int) -> Unit
) {
    SuperDropdown(
        title = title,
        summary = summary,
        items = items,
        selectedIndex = selectedIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0)),
        onSelectedIndexChange = onSelectedIndexChange
    )
}

@Composable
fun ArrowPreference(
    title: String,
    summary: String? = null,
    value: String? = null,
    onClick: () -> Unit
) {
    SuperArrow(
        title = title,
        summary = summary,
        rightActions = {
            if (!value.isNullOrBlank()) {
                Text(
                    text = value,
                    fontSize = 14.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                )
            }
        },
        onClick = onClick
    )
}

@Composable
fun SettingCardHeader(title: String) {
    SmallTitle(text = title)
}

@Composable
fun ActionIconBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconType: Int = 0
) {
    val tint = MiuixTheme.colorScheme.onSurface
    Box(
        modifier = modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(21.dp)) {
            val w = size.width
            val h = size.height
            val sw = 2.dp.toPx()
            when (iconType) {
                0 -> {
                    // Refresh arc with arrow
                    drawArc(
                        color = tint,
                        startAngle = 35f,
                        sweepAngle = 285f,
                        useCenter = false,
                        style = Stroke(width = sw, cap = StrokeCap.Round)
                    )
                    val arrowPath = Path().apply {
                        moveTo(w * 0.72f, h * 0.10f)
                        lineTo(w * 0.88f, h * 0.28f)
                        lineTo(w * 0.64f, h * 0.32f)
                    }
                    drawPath(
                        path = arrowPath,
                        color = tint,
                        style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
                1 -> {
                    // Filter funnel / sliders
                    drawLine(tint, Offset(w * 0.14f, h * 0.25f), Offset(w * 0.86f, h * 0.25f), strokeWidth = sw, cap = StrokeCap.Round)
                    drawLine(tint, Offset(w * 0.26f, h * 0.50f), Offset(w * 0.74f, h * 0.50f), strokeWidth = sw, cap = StrokeCap.Round)
                    drawLine(tint, Offset(w * 0.40f, h * 0.75f), Offset(w * 0.60f, h * 0.75f), strokeWidth = sw, cap = StrokeCap.Round)
                }
                else -> {
                    // More vertical dots
                    val r = 1.75.dp.toPx()
                    drawCircle(tint, radius = r, center = Offset(w / 2f, h * 0.22f))
                    drawCircle(tint, radius = r, center = Offset(w / 2f, h * 0.50f))
                    drawCircle(tint, radius = r, center = Offset(w / 2f, h * 0.78f))
                }
            }
        }
    }
}

@Composable
fun SectionSpacer(height: Dp = 8.dp) {
    Spacer(modifier = Modifier.height(height))
}
