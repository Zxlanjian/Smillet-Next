package com.sidesand.millet.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme

private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(6.8f, 3.2f)
            horizontalLineTo(17.2f)
            curveTo(19.2f, 3.2f, 20.8f, 4.8f, 20.8f, 6.8f)
            verticalLineTo(17.2f)
            curveTo(20.8f, 19.2f, 19.2f, 20.8f, 17.2f, 20.8f)
            horizontalLineTo(6.8f)
            curveTo(4.8f, 20.8f, 3.2f, 19.2f, 3.2f, 17.2f)
            verticalLineTo(6.8f)
            curveTo(3.2f, 4.8f, 4.8f, 3.2f, 6.8f, 3.2f)
            close()
            moveTo(13.6f, 3.4f)
            verticalLineTo(20.6f)
        }
        path(fill = SolidColor(Color.Black)) {
            val cols = floatArrayOf(6.8f, 10.1f)
            val rows = floatArrayOf(7.8f, 12.0f, 16.2f)
            val r = 1.05f
            for (cx in cols) {
                for (cy in rows) {
                    moveTo(cx + r, cy)
                    curveTo(cx + r, cy + r * 0.55f, cx + r * 0.55f, cy + r, cx, cy + r)
                    curveTo(cx - r * 0.55f, cy + r, cx - r, cy + r * 0.55f, cx - r, cy)
                    curveTo(cx - r, cy - r * 0.55f, cx - r * 0.55f, cy - r, cx, cy - r)
                    curveTo(cx + r * 0.55f, cy - r, cx + r, cy - r * 0.55f, cx + r, cy)
                    close()
                }
            }
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(7.0f, 2.8f)
            horizontalLineTo(17.0f)
            curveTo(18.8f, 2.8f, 20.2f, 4.2f, 20.2f, 6.0f)
            verticalLineTo(15.2f)
            lineTo(14.4f, 21.2f)
            horizontalLineTo(7.0f)
            curveTo(5.2f, 21.2f, 3.8f, 19.8f, 3.8f, 18.0f)
            verticalLineTo(6.0f)
            curveTo(3.8f, 4.2f, 5.2f, 2.8f, 7.0f, 2.8f)
            close()
            moveTo(14.2f, 21.0f)
            verticalLineTo(16.6f)
            curveTo(14.2f, 15.6f, 15.0f, 14.8f, 16.0f, 14.8f)
            horizontalLineTo(20.0f)
            moveTo(8.0f, 8.2f)
            horizontalLineTo(16.0f)
            moveTo(8.0f, 12.0f)
            horizontalLineTo(13.4f)
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            fill = SolidColor(Color.Black),
            pathFillType = PathFillType.EvenOdd
        ) {
            moveTo(7.0f, 3.0f)
            horizontalLineTo(17.0f)
            curveTo(19.2f, 3.0f, 21.0f, 4.8f, 21.0f, 7.0f)
            verticalLineTo(17.0f)
            curveTo(21.0f, 19.2f, 19.2f, 21.0f, 17.0f, 21.0f)
            horizontalLineTo(7.0f)
            curveTo(4.8f, 21.0f, 3.0f, 19.2f, 3.0f, 17.0f)
            verticalLineTo(7.0f)
            curveTo(3.0f, 4.8f, 4.8f, 3.0f, 7.0f, 3.0f)
            close()
            moveTo(10.4f, 16.4f)
            lineTo(6.7f, 12.7f)
            lineTo(8.2f, 11.2f)
            lineTo(10.4f, 13.4f)
            lineTo(15.8f, 8.0f)
            lineTo(17.3f, 9.5f)
            close()
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(12.0f, 2.7f)
            lineTo(19.8f, 7.2f)
            verticalLineTo(16.8f)
            lineTo(12.0f, 21.3f)
            lineTo(4.2f, 16.8f)
            verticalLineTo(7.2f)
            close()
            val r = 3.1f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.55f, 12f + r * 0.55f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.55f, 12f + r, 12f - r, 12f + r * 0.55f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.55f, 12f - r * 0.55f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.55f, 12f - r, 12f + r, 12f - r * 0.55f, 12f + r, 12f)
            close()
        }
    }.build()
}

/**
 * 1:1 还原参考图片 (1000110447_53075c.png) 的右上角圆圈三点图标 ⋯
 */
private val IconMoreCircle: ImageVector by lazy {
    ImageVector.Builder("MoreCircle", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.85f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            val r = 9.0f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
        path(fill = SolidColor(Color.Black)) {
            val xs = floatArrayOf(8.2f, 12.0f, 15.8f)
            val dotR = 1.15f
            for (cx in xs) {
                moveTo(cx + dotR, 12f)
                curveTo(cx + dotR, 12f + dotR * 0.55f, cx + dotR * 0.55f, 12f + dotR, cx, 12f + dotR)
                curveTo(cx - dotR * 0.55f, 12f + dotR, cx - dotR, 12f + dotR * 0.55f, cx - dotR, 12f)
                curveTo(cx - dotR, 12f - dotR * 0.55f, cx - dotR * 0.55f, 12f - dotR, cx, 12f - dotR)
                curveTo(cx + dotR * 0.55f, 12f - dotR, cx + dotR, 12f - dotR * 0.55f, cx + dotR, 12f)
                close()
            }
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(18.2f, 7.6f)
            curveTo(16.8f, 5.6f, 14.5f, 4.4f, 12.0f, 4.4f)
            curveTo(7.8f, 4.4f, 4.4f, 7.8f, 4.4f, 12.0f)
            curveTo(4.4f, 16.2f, 7.8f, 19.6f, 12.0f, 19.6f)
            curveTo(15.6f, 19.6f, 18.6f, 17.1f, 19.4f, 13.7f)
            moveTo(18.6f, 4.4f)
            verticalLineTo(8.2f)
            horizontalLineTo(14.8f)
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.1f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(14.8f, 5.8f)
            lineTo(8.6f, 12.0f)
            lineTo(14.8f, 18.2f)
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showLogPage by remember { mutableStateOf(false) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()

    val config by viewModel.config.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val mainScrollBehavior = MiuixScrollBehavior()
    val subPageScrollBehavior = MiuixScrollBehavior()
    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")
    val isDark = isSystemInDarkTheme()

    BackHandler(enabled = showAppFilterSheet || showLogTopMenu || selectedAppForConfig != null || showLogPage) {
        when {
            showAppFilterSheet -> showAppFilterSheet = false
            showLogTopMenu -> showLogTopMenu = false
            selectedAppForConfig != null -> selectedAppForConfig = null
            showLogPage -> showLogPage = false
        }
    }

    Scaffold(
        topBar = {
            val activeApp = selectedAppForConfig
            FrostedTopAppBarWrapper(isDark = isDark) {
                when {
                    activeApp != null -> {
                        SmallTopAppBar(
                            title = activeApp.second,
                            scrollBehavior = subPageScrollBehavior,
                            color = Color.Transparent,
                            navigationIcon = {
                                IconButton(onClick = { selectedAppForConfig = null }) {
                                    Icon(
                                        imageVector = IconBack,
                                        contentDescription = "返回",
                                        tint = MiuixTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        )
                    }
                    showLogPage -> {
                        SmallTopAppBar(
                            title = "日志",
                            scrollBehavior = subPageScrollBehavior,
                            color = Color.Transparent,
                            navigationIcon = {
                                IconButton(onClick = {
                                    showLogTopMenu = false
                                    showLogPage = false
                                }) {
                                    Icon(
                                        imageVector = IconBack,
                                        contentDescription = "返回",
                                        tint = MiuixTheme.colorScheme.onSurface
                                    )
                                }
                            },
                            actions = {
                                TopMenuActionButton(
                                    active = showLogTopMenu,
                                    isDark = isDark,
                                    contentDescription = "日志选项",
                                    onClick = { showLogTopMenu = !showLogTopMenu }
                                )
                            }
                        )
                    }
                    else -> {
                        TopAppBar(
                            title = tabTitles[selectedTab],
                            scrollBehavior = mainScrollBehavior,
                            color = Color.Transparent,
                            actions = {
                                when (selectedTab) {
                                    1 -> {
                                        TopMenuActionButton(
                                            active = showAppFilterSheet,
                                            isDark = isDark,
                                            contentDescription = "筛选",
                                            onClick = { showAppFilterSheet = !showAppFilterSheet }
                                        )
                                    }
                                    2 -> {
                                        IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                            Icon(
                                                imageVector = IconRefresh,
                                                contentDescription = "刷新",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        },
        bottomBar = {
            if (selectedAppForConfig == null && !showLogPage) {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = {
                            showAppFilterSheet = false
                            selectedTab = 0
                        },
                        icon = IconHome,
                        label = "主页"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = IconAppList,
                        label = "应用列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = {
                            showAppFilterSheet = false
                            selectedTab = 2
                            viewModel.refreshRunningApps(includeSystemApps)
                        },
                        icon = IconRunningCheck,
                        label = "运行列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = {
                            showAppFilterSheet = false
                            selectedTab = 3
                        },
                        icon = IconHexSettings,
                        label = "设置"
                    )
                }
            }
        }
    ) { innerPadding ->
        val topBarHeight = innerPadding.calculateTopPadding()
        val bottomBarHeight = innerPadding.calculateBottomPadding()
        val pageContentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = topBarHeight + 10.dp,
            bottom = bottomBarHeight + 12.dp
        )

        // 全部页面内容均可延伸至顶栏下方，配合顶栏背景模糊与底部边缘羽化过渡
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    compositingStrategy = CompositingStrategy.Offscreen
                }
                .drawWithContent {
                    drawContent()
                    val topPx = topBarHeight.toPx()
                    val featherPx = 30.dp.toPx()
                    if (topPx > 0f) {
                        drawRect(
                            brush = Brush.verticalGradient(
                                0.0f to Color.White.copy(alpha = 0.12f),
                                (topPx / (topPx + featherPx)).coerceIn(0.1f, 0.85f) to Color.White.copy(alpha = 0.55f),
                                1.0f to Color.White,
                                startY = 0f,
                                endY = topPx + featherPx
                            ),
                            topLeft = Offset.Zero,
                            size = Size(size.width, topPx + featherPx),
                            blendMode = BlendMode.DstIn
                        )
                    }
                }
        ) {
            val activeApp = selectedAppForConfig
            when {
                activeApp != null -> {
                    AppConfigDialog(
                        packageName = activeApp.first,
                        appName = activeApp.second,
                        config = config,
                        viewModel = viewModel,
                        scrollBehavior = subPageScrollBehavior,
                        contentPadding = pageContentPadding,
                        onDismiss = { selectedAppForConfig = null }
                    )
                }
                showLogPage -> {
                    LogPage(
                        viewModel = viewModel,
                        listState = logListState,
                        scrollBehavior = subPageScrollBehavior,
                        contentPadding = pageContentPadding,
                        topBarHeight = topBarHeight,
                        filterLevel = logFilterLevel,
                        onFilterLevelChange = { logFilterLevel = it },
                        showTopMenu = showLogTopMenu,
                        onDismissTopMenu = { showLogTopMenu = false }
                    )
                }
                else -> {
                    Crossfade(targetState = selectedTab, label = "MainTabs") { tab ->
                        when (tab) {
                            0 -> HomePage(
                                viewModel = viewModel,
                                config = config,
                                isSystemActive = isSystemActive,
                                isPowerKeeperActive = isPkActive,
                                scrollBehavior = mainScrollBehavior,
                                contentPadding = pageContentPadding,
                                onNavigateToWhitelist = {
                                    appFilterIndex = 2
                                    selectedTab = 1
                                },
                                onNavigateToBlacklist = {
                                    appFilterIndex = 3
                                    selectedTab = 1
                                },
                                onNavigateToRunning = { selectedTab = 2 },
                                onNavigateToLogs = {
                                    showLogTopMenu = false
                                    showLogPage = true
                                }
                            )
                            1 -> AppListPage(
                                viewModel = viewModel,
                                config = config,
                                scrollBehavior = mainScrollBehavior,
                                contentPadding = pageContentPadding,
                                topBarHeight = topBarHeight,
                                showFilterSheet = showAppFilterSheet,
                                onDismissFilterSheet = { showAppFilterSheet = false },
                                includeSystemApps = includeSystemApps,
                                onIncludeSystemAppsChange = { includeSystemApps = it },
                                filterIndex = appFilterIndex,
                                onFilterIndexChange = { appFilterIndex = it },
                                onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name }
                            )
                            2 -> RunningListPage(
                                viewModel = viewModel,
                                scrollBehavior = mainScrollBehavior,
                                contentPadding = pageContentPadding,
                                onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                                onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                            )
                            3 -> SettingsPage(
                                viewModel = viewModel,
                                config = config,
                                scrollBehavior = mainScrollBehavior,
                                contentPadding = pageContentPadding
                            )
                        }
                    }
                }
            }

            diagnosticPair?.let { (pkg, reason) ->
                OverlayDialog(
                    show = true,
                    title = "诊断冻结状态",
                    summary = pkg,
                    onDismissRequest = { viewModel.dismissDiagnosticDialog() }
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(text = reason)
                        Spacer(modifier = Modifier.height(16.dp))
                        TextButton(
                            text = "我知道了",
                            onClick = { viewModel.dismissDiagnosticDialog() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }
    }
}

/**
 * 为所有顶栏标题提供统一的背景高斯模糊 + 底部边缘渐进模糊过渡带
 */
@Composable
private fun FrostedTopAppBarWrapper(
    isDark: Boolean,
    content: @Composable () -> Unit
) {
    val baseBg = MiuixTheme.colorScheme.background
    val frostedTop = baseBg.copy(alpha = if (isDark) 0.86f else 0.88f)
    val frostedMid = baseBg.copy(alpha = if (isDark) 0.72f else 0.76f)
    val edgeGlow = baseBg.copy(alpha = if (isDark) 0.42f else 0.48f)

    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .blur(radius = 22.dp, edgeTreatment = BlurredEdgeTreatment.Unbounded)
                .background(
                    brush = Brush.verticalGradient(
                        0.0f to frostedTop,
                        0.75f to frostedMid,
                        0.92f to edgeGlow,
                        1.0f to Color.Transparent
                    )
                )
        )
        content()
    }
}

/**
 * 1:1 还原参考图的右上角菜单触发按钮（展开时显示圆形半透明底色高亮）
 */
@Composable
private fun TopMenuActionButton(
    active: Boolean,
    isDark: Boolean,
    contentDescription: String,
    onClick: () -> Unit
) {
    val activeCircleColor = if (isDark) {
        Color.White.copy(alpha = 0.14f)
    } else {
        Color.Black.copy(alpha = 0.08f)
    }

    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) activeCircleColor else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = IconMoreCircle,
                contentDescription = contentDescription,
                tint = MiuixTheme.colorScheme.onSurface
            )
        }
    }
}
