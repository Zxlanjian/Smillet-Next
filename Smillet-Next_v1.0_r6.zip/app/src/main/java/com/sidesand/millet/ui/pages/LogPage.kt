package com.sidesand.millet.ui.pages

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.ui.MainViewModel
import com.sidesand.millet.ui.components.MiuixPopupActionRow
import com.sidesand.millet.ui.components.MiuixPopupOptionRow
import com.sidesand.millet.ui.components.MiuixTopPopupMenu
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme

enum class LogFilterLevel(val label: String) {
    ALL("全部日志"),
    DEBUG("调试与信息"),
    WARN("仅警告"),
    ERROR("仅错误")
}

@Composable
fun LogPage(
    viewModel: MainViewModel,
    listState: LazyListState,
    scrollBehavior: ScrollBehavior,
    contentPadding: PaddingValues,
    topBarHeight: Dp,
    filterLevel: LogFilterLevel,
    onFilterLevelChange: (LogFilterLevel) -> Unit,
    showTopMenu: Boolean,
    onDismissTopMenu: () -> Unit
) {
    val logs by viewModel.logsList.collectAsState()
    val isLoading by viewModel.isLoadingLogs.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()
    val cardBgColor = if (isDark) Color(0xFF242426) else Color(0xFFFFFFFF)
    val dividerColor = if (isDark) Color.White.copy(alpha = 0.06f) else Color.Black.copy(alpha = 0.05f)

    var exportResultMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refreshLogs(silent = false)
        while (true) {
            delay(1000L)
            viewModel.refreshLogs(silent = true)
        }
    }

    val filteredLogs = remember(logs, filterLevel) {
        when (filterLevel) {
            LogFilterLevel.ALL -> logs
            LogFilterLevel.DEBUG -> logs.filter { line ->
                line.contains("[DEBUG]", ignoreCase = true) ||
                    line.contains(" D/", ignoreCase = true) ||
                    line.contains("[INFO]", ignoreCase = true) ||
                    line.contains(" I/", ignoreCase = true)
            }
            LogFilterLevel.WARN -> logs.filter { line ->
                line.contains("[WARN]", ignoreCase = true) ||
                    line.contains(" W/", ignoreCase = true)
            }
            LogFilterLevel.ERROR -> logs.filter { line ->
                line.contains("[ERROR]", ignoreCase = true) ||
                    line.contains(" E/", ignoreCase = true) ||
                    line.contains("Exception", ignoreCase = true)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = contentPadding
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${filterLevel.label} (${filteredLogs.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 6.dp)
                    )
                    if (filterLevel != LogFilterLevel.ALL) {
                        Text(
                            text = "显示全部",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MiuixTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onFilterLevelChange(LogFilterLevel.ALL) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            if (filteredLogs.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 64.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isLoading) {
                                "正在加载当前日志..."
                            } else {
                                "当前筛选下暂无日志记录"
                            },
                            fontSize = 15.sp,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                        )
                    }
                }
            } else {
                itemsIndexed(filteredLogs) { index, line ->
                    val isFirst = index == 0
                    val isLast = index == filteredLogs.lastIndex
                    val shape = when {
                        isFirst && isLast -> RoundedCornerShape(18.dp)
                        isFirst -> RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
                        isLast -> RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp)
                        else -> RoundedCornerShape(0.dp)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(cardBgColor)
                    ) {
                        LogGroupedRow(
                            line = line,
                            isFirst = isFirst,
                            isLast = isLast
                        )
                        if (!isLast) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp)
                                    .height(0.5.dp)
                                    .background(dividerColor)
                            )
                        }
                    }
                }
            }
        }

        // 右上角菜单：1:1 对齐参考图片样式
        MiuixTopPopupMenu(
            visible = showTopMenu,
            onDismiss = onDismissTopMenu,
            topOffset = topBarHeight + 6.dp,
            width = 228.dp
        ) {
            LogFilterLevel.entries.forEach { level ->
                MiuixPopupOptionRow(
                    text = level.label,
                    selected = level == filterLevel,
                    onClick = {
                        onFilterLevelChange(level)
                        onDismissTopMenu()
                    }
                )
            }

            MiuixPopupActionRow(
                text = "滚动到顶部",
                onClick = {
                    onDismissTopMenu()
                    if (filteredLogs.isNotEmpty()) {
                        scope.launch { listState.animateScrollToItem(0) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "滚动到底部",
                onClick = {
                    onDismissTopMenu()
                    if (filteredLogs.isNotEmpty()) {
                        scope.launch { listState.animateScrollToItem(filteredLogs.size - 1) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "导出日志文件",
                onClick = {
                    onDismissTopMenu()
                    scope.launch {
                        val res = viewModel.exportLogsToDownloads(filteredLogs)
                        exportResultMessage = res.fold(
                            onSuccess = { path -> "日志已成功导出至：\n$path" },
                            onFailure = { err -> "导出日志失败：${err.message}" }
                        )
                    }
                }
            )
        }

        exportResultMessage?.let { msg ->
            OverlayDialog(
                show = true,
                title = "导出日志",
                summary = "Smillet-Next 日志导出结果",
                onDismissRequest = { exportResultMessage = null }
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = msg,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TextButton(
                            text = "分享文本",
                            onClick = {
                                val textToShare = if (filteredLogs.isEmpty()) "暂无日志" else filteredLogs.joinToString("\n")
                                runCatching {
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "Smillet-Next 运行日志")
                                        putExtra(Intent.EXTRA_TEXT, textToShare.takeLast(120_000))
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "分享或保存日志"))
                                }
                                exportResultMessage = null
                            },
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            text = "我知道了",
                            onClick = { exportResultMessage = null },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LogGroupedRow(
    line: String,
    isFirst: Boolean,
    isLast: Boolean
) {
    val isError = line.contains("[ERROR]", ignoreCase = true) || line.contains(" E/", ignoreCase = true)
    val isWarn = !isError && (line.contains("[WARN]", ignoreCase = true) || line.contains(" W/", ignoreCase = true))
    val isDebug = !isError && !isWarn && (line.contains("[DEBUG]", ignoreCase = true) || line.contains(" D/", ignoreCase = true))

    val (badgeText, badgeColor) = when {
        isError -> "ERROR" to Color(0xFFD94A4A)
        isWarn -> "WARN" to Color(0xFFE67E22)
        isDebug -> "DEBUG" to Color(0xFF2874F0)
        else -> "INFO" to Color(0xFF169976)
    }

    val timePart = line.take(23).takeIf { it.startsWith("20") } ?: ""
    val bodyText = if (line.length > 24 && line.startsWith("20")) {
        line.substring(24)
            .replaceFirst("[INFO] ", "")
            .replaceFirst("[DEBUG] ", "")
            .replaceFirst("[WARN] ", "")
            .replaceFirst("[ERROR] ", "")
            .replaceFirst("[Smillet-Next] ", "")
            .trim()
    } else {
        line.trim()
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = 16.dp,
                end = 16.dp,
                top = if (isFirst) 16.dp else 12.dp,
                bottom = if (isLast) 16.dp else 12.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = bodyText,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.Normal,
                color = if (isError) badgeColor else MiuixTheme.colorScheme.onSurface
            )
            if (timePart.isNotEmpty()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = timePart,
                    fontSize = 12.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                )
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(badgeColor)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                text = badgeText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
        }
    }
}
