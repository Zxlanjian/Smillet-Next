# Changelog

## [v1.0] - 2026-10-15

### Added
- 全面迁移至 **LSPosed Modern API 102 (`io.github.libxposed`)**，支持动态作用域与 `XposedService` 配置同步。
- 使用 **[compose-miuix-ui/miuix](https://github.com/compose-miuix-ui/miuix)** 重构全套 HyperOS 原生风格界面。
- 适配 **HyperOS 2.0 / 3.0 (Android 16 / SDK 37)** 的 `com.miui.server.greeze.power.ListAppsManager` 与 `PowerStrategyMode` 名单管控。
- 主页新增独立「已冻结」统计卡片、「当前运行内存 (RAM) 与 ZRAM 当前占用」实时监控卡片。
- 新增内置「当前日志」页面（`LogPage`），支持右上角菜单按「全部 / 调试 / 警告 / 错误」筛选、滚动到顶部/底部、一键导出日志到 `/sdcard/Download/` 及系统分享。
- 在「设置 -> 冻结设置 -> 冻结模式」中新增关于「为什么 PID 模式无法选择」的底层机制说明弹窗。
- 补齐 `thawUid`、`thawUids`、`thawProcess` 与 `ProcessList.handleProcessStartedLocked` 解冻日志记录。

### Fixed
- 修复 SDK 37 下冻结/解冻 `reason` 字符串变为小写或下划线格式（`packet`、`check binder`、`sync binder`、`screen_on`）导致部分策略漏判的问题。
- 修复 `GreezeManagerService$Lifecycle` 内部类包装导致的实例反射报错问题。
- 修复配置同步、电池优化白名单与 `from system` 周期巡检引起的重复日志刷屏问题。
