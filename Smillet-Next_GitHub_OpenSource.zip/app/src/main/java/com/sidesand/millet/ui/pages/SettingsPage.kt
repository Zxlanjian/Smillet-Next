package com.sidesand.millet.ui.pages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference

@Composable
fun SettingsPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    scrollBehavior: ScrollBehavior
) {
    var showBackupDialog by remember { mutableStateOf(false) }
    var showPidWhyDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    var importFeedback by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val logLevels = listOf("debug", "info", "warn", "error")
    val logTypes = listOf("xposed", "file")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SmallTitle(text = "冻结设置")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    OverlayDropdownPreference(
                        title = "冻结模式",
                        summary = "当前为 UID 模式（点选 PID 查看为什么无法选择）",
                        items = listOf("UID", "PID (为什么无法选择？)"),
                        selectedIndex = 0,
                        onSelectedIndexChange = { idx ->
                            if (idx == 1) {
                                showPidWhyDialog = true
                            }
                        }
                    )
                    ArrowPreference(
                        title = "为什么冻结模式的 PID 无法选择？",
                        summary = "点击查看 HyperOS 墓碑机制仅支持按 UID 冻结的原因",
                        onClick = { showPidWhyDialog = true }
                    )
                    OverlayDropdownPreference(
                        title = "电池优化模式",
                        items = listOf("按 App 配置", "系统默认"),
                        selectedIndex = if (config.blockAddPowerSaveWhitelistApps) 0 else 1,
                        onSelectedIndexChange = { idx ->
                            viewModel.updateBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, idx == 0)
                        }
                    )
                    SwitchPreference(
                        title = "屏蔽 Millet 杀后台",
                        checked = config.disableKill,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_KILL, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽充电解冻",
                        checked = config.disableCharge,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_CHARGE, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽音量解冻",
                        checked = config.disableVolume,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_VOLUME, it) }
                    )
                    SwitchPreference(
                        title = "记录电量变化",
                        checked = config.batteryChangeObserve,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, it)
                        }
                    )
                }
            }
        }

        item {
            SmallTitle(text = "深度 Doze")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "息屏进入 DeepDoze",
                        checked = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.ENABLE_DOZE, it) }
                    )
                    SwitchPreference(
                        title = "跳过状态检查进入 DeepDoze",
                        checked = config.skipStateCheck,
                        enabled = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SKIP_STATE_CHECK, it) }
                    )
                    SwitchPreference(
                        title = "避免运动退出 DeepDoze",
                        checked = config.disableMotionListener,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, it)
                        }
                    )
                    SwitchPreference(
                        title = "开启 Doze 日志",
                        checked = config.dozeLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DOZE_LOG, it) }
                    )
                }
            }
        }

        item {
            SmallTitle(text = "日志与备份")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "调试日志",
                        checked = config.isLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.IS_LOG, it) }
                    )
                    SwitchPreference(
                        title = "简化冻结日志",
                        checked = config.simplifyLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SIMPLIFY_LOG, it) }
                    )
                    OverlayDropdownPreference(
                        title = "日志级别",
                        items = logLevels,
                        selectedIndex = logLevels.indexOf(config.logLevel).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_LEVEL, logLevels[idx])
                        }
                    )
                    OverlayDropdownPreference(
                        title = "日志输出",
                        items = listOf("LSPosed", "本地文件"),
                        selectedIndex = logTypes.indexOf(config.logType).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_TYPE, logTypes[idx])
                        }
                    )
                    ArrowPreference(
                        title = "备份与恢复",
                        onClick = {
                            backupJsonText = viewModel.prefsManager.exportBackupJson()
                            importFeedback = null
                            showBackupDialog = true
                        }
                    )
                }
            }
        }
    }

    if (showPidWhyDialog) {
        OverlayDialog(
            show = true,
            title = "为什么冻结模式的 PID 无法选择？",
            summary = "HyperOS Greezer 与 Cgroup v2 冻结机制说明",
            onDismissRequest = { showPidWhyDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "1. 系统底层架构限制：\n小米 HyperOS 的原生墓碑服务 (GreezeManagerService) 与内核 Cgroup v2 Freezer (/sys/fs/cgroup/uid_<uid>/cgroup.freeze) 是按应用 UID 为最小原子粒度进行冻结与解冻调度的。\n\n" +
                        "2. 避免主子进程死锁与 ANR：\n同一应用的主进程与子进程（如推送服务、WebView 渲染进程）共享相同的 UID，存在高频的进程间 Binder 同步调用与共享文件锁。如果仅按 PID 单独冻结某一个子进程而主进程仍在运行，会导致主进程等待子进程响应超时，引发界面卡死与系统无响应 (ANR)。\n\n" +
                        "3. 结论：\n为保障系统稳定性与冻结彻底性，冻结模式固定为 UID 模式，不可切换为单 PID 模式。",
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(
                    text = "我知道了",
                    onClick = { showPidWhyDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary()
                )
            }
        }
    }

    if (showBackupDialog) {
        OverlayDialog(
            show = true,
            title = "备份与恢复",
            summary = "复制或粘贴 JSON 配置文本",
            onDismissRequest = { showBackupDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                TextField(
                    value = backupJsonText,
                    onValueChange = { newText ->
                        backupJsonText = newText.replace("\n", "").replace("\r", "")
                    },
                    label = "JSON 配置",
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            keyboardController?.hide()
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .onPreviewKeyEvent { keyEvent ->
                            if (keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter) {
                                if (keyEvent.type == KeyEventType.KeyUp) {
                                    focusManager.clearFocus()
                                    keyboardController?.hide()
                                }
                                true
                            } else {
                                false
                            }
                        }
                )
                importFeedback?.let { msg ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = msg)
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        text = "取消",
                        onClick = { showBackupDialog = false },
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        text = "恢复配置",
                        onClick = {
                            val ok = viewModel.prefsManager.importBackupJson(backupJsonText)
                            if (ok) {
                                viewModel.reloadSnapshot()
                                importFeedback = "恢复成功，已通过 Binder 同步生效"
                            } else {
                                importFeedback = "JSON 解析失败"
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    }
}
