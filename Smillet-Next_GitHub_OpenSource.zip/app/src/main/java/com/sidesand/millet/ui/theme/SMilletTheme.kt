package com.sidesand.millet.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController

@Composable
fun SmilletNextTheme(
    darkTheme: Boolean? = null,
    content: @Composable () -> Unit
) {
    val mode = when (darkTheme) {
        true -> ColorSchemeMode.Dark
        false -> ColorSchemeMode.Light
        null -> ColorSchemeMode.System
    }
    val controller = remember(mode) { ThemeController(mode) }
    MiuixTheme(
        controller = controller,
        smoothRounding = true,
        content = content
    )
}
