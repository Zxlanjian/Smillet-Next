package com.sidesand.millet.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.sidesand.millet.hook.XposedCompat
import io.github.libxposed.service.XposedService
import io.github.libxposed.service.XposedServiceHelper
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

class PrefsManager(
    private val primaryPrefs: SharedPreferences?,
    private val mirrorPrefs: SharedPreferences? = null
) {

    companion object {
        const val SYSTEM_CONFIG_FILE = "/data/system/SMillet/config.json"

        private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
        private val listenerRegistered = AtomicBoolean(false)
        private val serviceStateListeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

        @Volatile
        var xposedService: XposedService? = null
            private set

        @Volatile
        var isLspServiceConnected: Boolean = false
            private set

        @Volatile
        var cachedSystemSnapshot: MilletConfigSnapshot? = null

        @Volatile
        var cachedSystemJson: String? = null

        fun ensureServiceListenerRegistered(onStateChanged: ((Boolean) -> Unit)? = null) {
            if (onStateChanged != null) {
                serviceStateListeners.add(onStateChanged)
            }
            if (listenerRegistered.compareAndSet(false, true)) {
                runCatching {
                    XposedServiceHelper.registerListener(object : XposedServiceHelper.OnServiceListener {
                        override fun onServiceBind(service: XposedService) {
                            xposedService = service
                            isLspServiceConnected = true
                            serviceStateListeners.forEach { it.invoke(true) }
                        }

                        override fun onServiceDied(service: XposedService) {
                            if (xposedService === service) {
                                xposedService = null
                            }
                            isLspServiceConnected = false
                            serviceStateListeners.forEach { it.invoke(false) }
                        }
                    })
                }
            }
        }

        fun isModuleActivatedInLsp(context: Context): Boolean {
            ensureServiceListenerRegistered()
            return isLspServiceConnected || xposedService != null
        }

        private fun openPrefs(ctx: Context): SharedPreferences {
            return ctx.getSharedPreferences(ConfigKeys.PREFS_NAME, Context.MODE_PRIVATE)
        }

        fun fromContext(context: Context): PrefsManager {
            ensureServiceListenerRegistered()
            val deCtx = runCatching { context.createDeviceProtectedStorageContext() }.getOrNull()
            val primary = if (deCtx != null) openPrefs(deCtx) else openPrefs(context)
            val mirror = if (deCtx != null) runCatching { openPrefs(context) }.getOrNull() else null
            if (primary.all.isEmpty() && mirror != null && mirror.all.isNotEmpty()) {
                val snap = readSnapshot(mirror)
                writeSnapshotToPrefs(primary, snap)
            }
            return PrefsManager(primary, mirror)
        }

        fun loadFromXposed(): MilletConfigSnapshot {
            cachedSystemSnapshot?.let { return it }
            runCatching {
                val sysFile = File(SYSTEM_CONFIG_FILE)
                if (sysFile.exists() && sysFile.canRead()) {
                    val text = sysFile.readText()
                    parseSnapshotFromJson(text)?.let {
                        cachedSystemSnapshot = it
                        cachedSystemJson = text
                        return it
                    }
                }
            }
            runCatching {
                val remotePrefs = XposedCompat.module?.getRemotePreferences(ConfigKeys.PREFS_NAME)
                if (remotePrefs != null && remotePrefs.all.isNotEmpty()) {
                    return readSnapshot(remotePrefs).also { cachedSystemSnapshot = it }
                }
            }
            return cachedSystemSnapshot ?: MilletConfigSnapshot()
        }

        fun saveSystemConfigFile(jsonText: String): MilletConfigSnapshot? {
            val parsed = parseSnapshotFromJson(jsonText) ?: return null
            cachedSystemSnapshot = parsed
            cachedSystemJson = jsonText
            runCatching {
                val file = File(SYSTEM_CONFIG_FILE)
                file.parentFile?.mkdirs()
                file.writeText(jsonText)
            }
            return parsed
        }

        fun readSystemConfigJson(): String? {
            cachedSystemJson?.takeIf { it.isNotBlank() }?.let { return it }
            return runCatching {
                val file = File(SYSTEM_CONFIG_FILE)
                if (file.exists() && file.canRead()) {
                    file.readText().also { cachedSystemJson = it }
                } else {
                    null
                }
            }.getOrNull()
        }

        fun serializeSnapshotToJson(s: MilletConfigSnapshot): String {
            val root = JsonObject().apply {
                add("MilletSettings", gson.toJsonTree(mapOf(
                    ConfigKeys.IS_LOG to s.isLog,
                    ConfigKeys.SIMPLIFY_LOG to s.simplifyLog,
                    ConfigKeys.DISABLE_KILL to s.disableKill,
                    ConfigKeys.DISABLE_VOLUME to s.disableVolume,
                    ConfigKeys.DISABLE_CHARGE to s.disableCharge,
                    ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST to s.blockAddPowerSaveWhitelistApps,
                    ConfigKeys.BATTERY_CHANGE_OBSERVE to s.batteryChangeObserve,
                    ConfigKeys.LOG_TO_LOCAL to s.logToLocal
                )))
                add("DozeSettings", gson.toJsonTree(mapOf(
                    ConfigKeys.DOZE_LOG to s.dozeLog,
                    ConfigKeys.ENABLE_DOZE to s.enableDoze,
                    ConfigKeys.SKIP_STATE_CHECK to s.skipStateCheck,
                    ConfigKeys.DISABLE_MOTION_LISTENER to s.disableMotionListener
                )))
                add("BatteryOptSettings", gson.toJsonTree(mapOf(
                    ConfigKeys.BATTERY_OPT_WHITE_SET to s.batteryOptWhiteSet.toSortedSet(),
                    ConfigKeys.BATTERY_OPT_BLACK_SET to s.batteryOptBlackSet.toSortedSet()
                )))
                add("AppSettings", gson.toJsonTree(mapOf(
                    ConfigKeys.WHITE_APP_SET to s.whiteAppSet.toSortedSet(),
                    ConfigKeys.MESSAGE_APP_SET to s.messageAppSet.toSortedSet(),
                    ConfigKeys.FORCE_FREEZE_SET to s.forceFreezeSet.toSortedSet(),
                    ConfigKeys.BLOCK_THAW_SET to s.blockThawSet.toSortedSet(),
                    ConfigKeys.FORBID_SYNC_BINDER_SET to s.forbidSyncBinderSet.toSortedSet(),
                    ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET to s.notFreezeWhenHasFgsSet.toSortedSet()
                )))
                add("LogSettings", gson.toJsonTree(mapOf(
                    ConfigKeys.LOG_LEVEL to s.logLevel,
                    ConfigKeys.LOG_TYPE to s.logType
                )))
            }
            return gson.toJson(root)
        }

        fun parseSnapshotFromJson(jsonText: String): MilletConfigSnapshot? {
            if (jsonText.isBlank()) return null
            return try {
                val root = gson.fromJson(jsonText, JsonObject::class.java) ?: return null
                val s = MilletConfigSnapshot()

                root.getAsJsonObject("MilletSettings")?.let { obj ->
                    obj.get(ConfigKeys.IS_LOG)?.asBoolean?.let { s.isLog = it }
                    obj.get(ConfigKeys.SIMPLIFY_LOG)?.asBoolean?.let { s.simplifyLog = it }
                    obj.get(ConfigKeys.DISABLE_KILL)?.asBoolean?.let { s.disableKill = it }
                    obj.get(ConfigKeys.DISABLE_VOLUME)?.asBoolean?.let { s.disableVolume = it }
                    obj.get(ConfigKeys.DISABLE_CHARGE)?.asBoolean?.let { s.disableCharge = it }
                    obj.get(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST)?.asBoolean?.let {
                        s.blockAddPowerSaveWhitelistApps = it
                    }
                    obj.get(ConfigKeys.BATTERY_CHANGE_OBSERVE)?.asBoolean?.let {
                        s.batteryChangeObserve = it
                    }
                    obj.get(ConfigKeys.LOG_TO_LOCAL)?.asBoolean?.let { s.logToLocal = it }
                }

                root.getAsJsonObject("DozeSettings")?.let { obj ->
                    obj.get(ConfigKeys.DOZE_LOG)?.asBoolean?.let { s.dozeLog = it }
                    obj.get(ConfigKeys.ENABLE_DOZE)?.asBoolean?.let { s.enableDoze = it }
                    obj.get(ConfigKeys.SKIP_STATE_CHECK)?.asBoolean?.let { s.skipStateCheck = it }
                    obj.get(ConfigKeys.DISABLE_MOTION_LISTENER)?.asBoolean?.let {
                        s.disableMotionListener = it
                    }
                }

                fun parseSet(parent: JsonObject?, key: String): Set<String>? {
                    val arr = parent?.getAsJsonArray(key) ?: return null
                    return arr.mapNotNull { it.asString }.toSet()
                }

                root.getAsJsonObject("BatteryOptSettings")?.let { obj ->
                    parseSet(obj, ConfigKeys.BATTERY_OPT_WHITE_SET)?.let { s.batteryOptWhiteSet = it }
                    parseSet(obj, ConfigKeys.BATTERY_OPT_BLACK_SET)?.let { s.batteryOptBlackSet = it }
                }

                root.getAsJsonObject("AppSettings")?.let { obj ->
                    parseSet(obj, ConfigKeys.WHITE_APP_SET)?.let { s.whiteAppSet = it }
                    parseSet(obj, ConfigKeys.MESSAGE_APP_SET)?.let { s.messageAppSet = it }
                    parseSet(obj, ConfigKeys.FORCE_FREEZE_SET)?.let { s.forceFreezeSet = it }
                    parseSet(obj, ConfigKeys.BLOCK_THAW_SET)?.let { s.blockThawSet = it }
                    parseSet(obj, ConfigKeys.FORBID_SYNC_BINDER_SET)?.let { s.forbidSyncBinderSet = it }
                    parseSet(obj, ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET)?.let { s.notFreezeWhenHasFgsSet = it }
                }

                root.getAsJsonObject("LogSettings")?.let { obj ->
                    obj.get(ConfigKeys.LOG_LEVEL)?.asString?.let { s.logLevel = it }
                    obj.get(ConfigKeys.LOG_TYPE)?.asString?.let { s.logType = it }
                }
                s
            } catch (_: Throwable) {
                null
            }
        }

        fun readSnapshot(sp: SharedPreferences): MilletConfigSnapshot {
            return MilletConfigSnapshot(
                isLog = sp.getBoolean(ConfigKeys.IS_LOG, true),
                simplifyLog = sp.getBoolean(ConfigKeys.SIMPLIFY_LOG, false),
                disableKill = sp.getBoolean(ConfigKeys.DISABLE_KILL, true),
                disableVolume = sp.getBoolean(ConfigKeys.DISABLE_VOLUME, true),
                disableCharge = sp.getBoolean(ConfigKeys.DISABLE_CHARGE, true),
                blockAddPowerSaveWhitelistApps = sp.getBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, true),
                batteryChangeObserve = sp.getBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, false),
                logToLocal = sp.getBoolean(ConfigKeys.LOG_TO_LOCAL, false),
                dozeLog = sp.getBoolean(ConfigKeys.DOZE_LOG, false),
                enableDoze = sp.getBoolean(ConfigKeys.ENABLE_DOZE, true),
                skipStateCheck = sp.getBoolean(ConfigKeys.SKIP_STATE_CHECK, true),
                disableMotionListener = sp.getBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, true),
                batteryOptWhiteSet = sp.getStringSet(ConfigKeys.BATTERY_OPT_WHITE_SET, emptySet())?.toSet() ?: emptySet(),
                batteryOptBlackSet = sp.getStringSet(ConfigKeys.BATTERY_OPT_BLACK_SET, emptySet())?.toSet() ?: emptySet(),
                whiteAppSet = sp.getStringSet(ConfigKeys.WHITE_APP_SET, emptySet())?.toSet() ?: emptySet(),
                messageAppSet = sp.getStringSet(ConfigKeys.MESSAGE_APP_SET, ConfigKeys.DEFAULT_MESSAGE_APPS)?.toSet() ?: ConfigKeys.DEFAULT_MESSAGE_APPS,
                forceFreezeSet = sp.getStringSet(ConfigKeys.FORCE_FREEZE_SET, emptySet())?.toSet() ?: emptySet(),
                blockThawSet = sp.getStringSet(ConfigKeys.BLOCK_THAW_SET, emptySet())?.toSet() ?: emptySet(),
                forbidSyncBinderSet = sp.getStringSet(ConfigKeys.FORBID_SYNC_BINDER_SET, emptySet())?.toSet() ?: emptySet(),
                notFreezeWhenHasFgsSet = sp.getStringSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, emptySet())?.toSet() ?: emptySet(),
                logLevel = sp.getString(ConfigKeys.LOG_LEVEL, "info") ?: "info",
                logType = sp.getString(ConfigKeys.LOG_TYPE, "xposed") ?: "xposed"
            )
        }

        private fun writeSnapshotToPrefs(sp: SharedPreferences, parsed: MilletConfigSnapshot) {
            sp.edit().apply {
                putBoolean(ConfigKeys.IS_LOG, parsed.isLog)
                putBoolean(ConfigKeys.SIMPLIFY_LOG, parsed.simplifyLog)
                putBoolean(ConfigKeys.DISABLE_KILL, parsed.disableKill)
                putBoolean(ConfigKeys.DISABLE_VOLUME, parsed.disableVolume)
                putBoolean(ConfigKeys.DISABLE_CHARGE, parsed.disableCharge)
                putBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, parsed.blockAddPowerSaveWhitelistApps)
                putBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, parsed.batteryChangeObserve)
                putBoolean(ConfigKeys.LOG_TO_LOCAL, parsed.logToLocal)
                putBoolean(ConfigKeys.DOZE_LOG, parsed.dozeLog)
                putBoolean(ConfigKeys.ENABLE_DOZE, parsed.enableDoze)
                putBoolean(ConfigKeys.SKIP_STATE_CHECK, parsed.skipStateCheck)
                putBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, parsed.disableMotionListener)
                putStringSet(ConfigKeys.BATTERY_OPT_WHITE_SET, HashSet(parsed.batteryOptWhiteSet))
                putStringSet(ConfigKeys.BATTERY_OPT_BLACK_SET, HashSet(parsed.batteryOptBlackSet))
                putStringSet(ConfigKeys.WHITE_APP_SET, HashSet(parsed.whiteAppSet))
                putStringSet(ConfigKeys.MESSAGE_APP_SET, HashSet(parsed.messageAppSet))
                putStringSet(ConfigKeys.FORCE_FREEZE_SET, HashSet(parsed.forceFreezeSet))
                putStringSet(ConfigKeys.BLOCK_THAW_SET, HashSet(parsed.blockThawSet))
                putStringSet(ConfigKeys.FORBID_SYNC_BINDER_SET, HashSet(parsed.forbidSyncBinderSet))
                putStringSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, HashSet(parsed.notFreezeWhenHasFgsSet))
                putString(ConfigKeys.LOG_LEVEL, parsed.logLevel)
                putString(ConfigKeys.LOG_TYPE, parsed.logType)
            }.commit()
        }
    }

    private fun editAll(block: SharedPreferences.Editor.() -> Unit) {
        primaryPrefs?.edit()?.apply(block)?.commit()
        mirrorPrefs?.edit()?.apply(block)?.commit()
        runCatching {
            xposedService?.getRemotePreferences(ConfigKeys.PREFS_NAME)?.edit()?.apply(block)?.apply()
        }
    }

    fun snapshot(): MilletConfigSnapshot {
        val sp = primaryPrefs ?: return MilletConfigSnapshot()
        return readSnapshot(sp)
    }

    fun putBoolean(key: String, value: Boolean) {
        editAll { putBoolean(key, value) }
    }

    fun putString(key: String, value: String) {
        editAll { putString(key, value) }
    }

    fun getStringSet(key: String, default: Set<String> = emptySet()): Set<String> =
        primaryPrefs?.getStringSet(key, default)?.toSet() ?: default

    fun putStringSet(key: String, value: Set<String>) {
        val copy = HashSet(value)
        editAll { putStringSet(key, copy) }
    }

    fun updateAppSet(key: String, packageName: String, add: Boolean): Set<String> {
        val current = getStringSet(key).toMutableSet()
        if (add) current.add(packageName) else current.remove(packageName)
        putStringSet(key, current)
        return current
    }

    fun setBatteryOptimization(packageName: String, ignoreBatteryOpt: Boolean) {
        val white = getStringSet(ConfigKeys.BATTERY_OPT_WHITE_SET).toMutableSet()
        val black = getStringSet(ConfigKeys.BATTERY_OPT_BLACK_SET).toMutableSet()
        if (ignoreBatteryOpt) {
            white.add(packageName)
            black.remove(packageName)
        } else {
            white.remove(packageName)
            black.add(packageName)
        }
        editAll {
            putStringSet(ConfigKeys.BATTERY_OPT_WHITE_SET, HashSet(white))
            putStringSet(ConfigKeys.BATTERY_OPT_BLACK_SET, HashSet(black))
        }
    }

    fun setWhiteListApp(packageName: String, enabled: Boolean) {
        val white = getStringSet(ConfigKeys.WHITE_APP_SET).toMutableSet()
        if (enabled) white.add(packageName) else white.remove(packageName)
        if (!enabled) {
            putStringSet(ConfigKeys.WHITE_APP_SET, white)
            return
        }
        val msg = getStringSet(ConfigKeys.MESSAGE_APP_SET).toMutableSet().apply { remove(packageName) }
        val force = getStringSet(ConfigKeys.FORCE_FREEZE_SET).toMutableSet().apply { remove(packageName) }
        val block = getStringSet(ConfigKeys.BLOCK_THAW_SET).toMutableSet().apply { remove(packageName) }
        val forbid = getStringSet(ConfigKeys.FORBID_SYNC_BINDER_SET).toMutableSet().apply { remove(packageName) }
        val fgs = getStringSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET).toMutableSet().apply { remove(packageName) }
        editAll {
            putStringSet(ConfigKeys.WHITE_APP_SET, HashSet(white))
            putStringSet(ConfigKeys.MESSAGE_APP_SET, HashSet(msg))
            putStringSet(ConfigKeys.FORCE_FREEZE_SET, HashSet(force))
            putStringSet(ConfigKeys.BLOCK_THAW_SET, HashSet(block))
            putStringSet(ConfigKeys.FORBID_SYNC_BINDER_SET, HashSet(forbid))
            putStringSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, HashSet(fgs))
        }
    }

    fun exportBackupJson(): String = serializeSnapshotToJson(snapshot())

    fun importBackupJson(jsonText: String): Boolean {
        val parsed = parseSnapshotFromJson(jsonText) ?: return false
        primaryPrefs?.let { writeSnapshotToPrefs(it, parsed) }
        mirrorPrefs?.let { writeSnapshotToPrefs(it, parsed) }
        runCatching {
            xposedService?.getRemotePreferences(ConfigKeys.PREFS_NAME)?.let { writeSnapshotToPrefs(it, parsed) }
        }
        return true
    }
}
