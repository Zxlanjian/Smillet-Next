package com.sidesand.millet.ui.pages

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.ui.MainViewModel
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme

enum class LogFilterLevel(val label: String) {
    ALL("全部日志"),
    DEBUG("调试与信息 (DEBUG / INFO)"),
    WARN("仅警告 (WARN)"),
    ERROR("仅错误 (ERROR)")
}

@Composable
fun LogPage(
    viewModel: MainViewModel,
    listState: LazyListState,
    filterLevel: LogFilterLevel,
    onFilterLevelChange: (LogFilterLevel) -> Unit,
    showTopMenu: Boolean,
    onDismissTopMenu: () -> Unit
) {
    val logs by viewModel.logsList.collectAsState()
    val isLoading by viewModel.isLoadingLogs.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()

    var exportResultMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refreshLogs()
    }

    val filteredLogs = remember(logs, filterLevel) {
        when (filterLevel) {
            LogFilterLevel.ALL -> logs
            LogFilterLevel.DEBUG -> logs.filter { line ->
                line.contains("[DEBUG]", ignoreCase = true) ||
                    line.contains(" D/", ignoreCase = true) ||
                    line.contains("[INFO]", ignoreCase = true) ||
                    line.contains(" I/", ignoreCase = true)
            }
            LogFilterLevel.WARN -> logs.filter { line ->
                line.contains("[WARN]", ignoreCase = true) ||
                    line.contains(" W/", ignoreCase = true)
            }
            LogFilterLevel.ERROR -> logs.filter { line ->
                line.contains("[ERROR]", ignoreCase = true) ||
                    line.contains(" E/", ignoreCase = true) ||
                    line.contains("Exception", ignoreCase = true)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 顶部状态栏：显示当前筛选级别、条数与刷新按钮
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filterLevel.label} (${filteredLogs.size})",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (filterLevel != LogFilterLevel.ALL) {
                        Text(
                            text = "显示全部",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MiuixTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onFilterLevelChange(LogFilterLevel.ALL) }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = if (isLoading) "正在读取..." else "点击刷新",
                        fontSize = 13.sp,
                        color = MiuixTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewModel.refreshLogs() }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
            }

            if (filteredLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isLoading) {
                            "正在加载当前日志..."
                        } else {
                            "当前筛选条件（${filterLevel.label}）下暂无日志记录"
                        },
                        fontSize = 15.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(filteredLogs) { _, line ->
                        LogItemCard(line = line, isDark = isDark)
                    }
                }
            }
        }

        // 右上角三个点菜单：与应用列表完全对齐，采用 Miuix OverlayDialog 原生弹窗动画与设计规范
        if (showTopMenu) {
            val levelEntries = LogFilterLevel.entries
            val levelLabels = remember { levelEntries.map { it.label } }
            val currentIdx = levelEntries.indexOf(filterLevel).coerceAtLeast(0)

            OverlayDialog(
                show = true,
                title = "日志选项",
                summary = "按级别筛选日志或执行导出操作",
                onDismissRequest = onDismissTopMenu
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OverlayDropdownPreference(
                        title = "日志级别筛选",
                        items = levelLabels,
                        selectedIndex = currentIdx,
                        onSelectedIndexChange = { idx ->
                            onFilterLevelChange(levelEntries[idx])
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TextButton(
                            text = "滚动到顶部",
                            onClick = {
                                onDismissTopMenu()
                                if (filteredLogs.isNotEmpty()) {
                                    scope.launch {
                                        listState.animateScrollToItem(0)
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            text = "滚动到底部",
                            onClick = {
                                onDismissTopMenu()
                                if (filteredLogs.isNotEmpty()) {
                                    scope.launch {
                                        listState.animateScrollToItem(filteredLogs.size - 1)
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TextButton(
                            text = "导出日志",
                            onClick = {
                                onDismissTopMenu()
                                scope.launch {
                                    val res = viewModel.exportLogsToDownloads(filteredLogs)
                                    exportResultMessage = res.fold(
                                        onSuccess = { path -> "日志已成功导出至：
$path" },
                                        onFailure = { err -> "导出日志失败：${err.message}" }
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            text = "确定",
                            onClick = onDismissTopMenu,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }

        exportResultMessage?.let { msg ->
            OverlayDialog(
                show = true,
                title = "导出日志",
                summary = "Smillet-Next 日志导出结果",
                onDismissRequest = { exportResultMessage = null }
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = msg,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TextButton(
                            text = "分享文本",
                            onClick = {
                                val textToShare = if (filteredLogs.isEmpty()) "暂无日志" else filteredLogs.joinToString("
")
                                runCatching {
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "Smillet-Next 运行日志")
                                        putExtra(Intent.EXTRA_TEXT, textToShare.takeLast(120_000))
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "分享或保存日志"))
                                }
                                exportResultMessage = null
                            },
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            text = "我知道了",
                            onClick = { exportResultMessage = null },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LogItemCard(line: String, isDark: Boolean) {
    val isError = line.contains("[ERROR]", ignoreCase = true) || line.contains(" E/", ignoreCase = true)
    val isWarn = !isError && (line.contains("[WARN]", ignoreCase = true) || line.contains(" W/", ignoreCase = true))
    val isDebug = !isError && !isWarn && (line.contains("[DEBUG]", ignoreCase = true) || line.contains(" D/", ignoreCase = true))

    val badgeText = when {
        isError -> "ERROR"
        isWarn -> "WARN"
        isDebug -> "DEBUG"
        else -> "INFO"
    }

    val badgeColor = when {
        isError -> if (isDark) Color(0xFFFF6B6B) else Color(0xFFD9383A)
        isWarn -> if (isDark) Color(0xFFFFB74D) else Color(0xFFE67E22)
        isDebug -> if (isDark) Color(0xFF64B5F6) else Color(0xFF1976D2)
        else -> if (isDark) Color(0xFF5CE09B) else Color(0xFF2E7D32)
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(badgeColor.copy(alpha = 0.16f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor
                    )
                }
                val timePart = line.take(23).takeIf { it.startsWith("20") } ?: ""
                if (timePart.isNotEmpty()) {
                    Text(
                        text = timePart,
                        fontSize = 11.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            val bodyText = if (line.length > 24 && line.startsWith("20")) {
                line.substring(24).replaceFirst("[INFO] ", "")
                    .replaceFirst("[DEBUG] ", "")
                    .replaceFirst("[WARN] ", "")
                    .replaceFirst("[ERROR] ", "")
                    .replaceFirst("[Smillet-Next] ", "")
            } else {
                line
            }
            Text(
                text = bodyText,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isError) badgeColor else MiuixTheme.colorScheme.onSurface
            )
        }
    }
}
