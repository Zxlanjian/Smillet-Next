package com.sidesand.millet.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.FreezeType
import com.sidesand.millet.data.ProcessDetail
import com.sidesand.millet.data.RunningAppItem
import com.sidesand.millet.ipc.SystemInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

object ProcessScanner {

    data class SysProcDto(
        val pid: Int = 0,
        val uid: Int = 0,
        val processName: String = "",
        val rssKb: Long = 0L,
        val wchan: String = "",
        val state: String = "",
        val isFrozenByGreeze: Boolean = false
    )

    data class MemoryStatus(
        val ramTotalGb: Float = 0f,
        val ramUsedGb: Float = 0f,
        val ramAvailGb: Float = 0f,
        val ramPercent: Int = 0,
        val zramTotalGb: Float = 0f,
        val zramUsedGb: Float = 0f,
        val zramFreeGb: Float = 0f,
        val zramPercent: Int = 0
    )

    private val gson = Gson()
    private val whitespaceRegex = Regex("\\s+")

    suspend fun checkRootAccess(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            val finished = proc.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) {
                proc.destroyForcibly()
                false
            } else {
                output.contains("uid=0")
            }
        }.getOrDefault(false)
    }

    suspend fun readLspVersionInfo(serviceInfo: String?, isLspActivated: Boolean): String = withContext(Dispatchers.IO) {
        if (!serviceInfo.isNullOrBlank()) {
            return@withContext serviceInfo
        }
        val fromRoot = runCatching {
            val cmd = "cat /data/adb/modules/*lsposed*/module.prop /data/adb/modules/*lspd*/module.prop 2>/dev/null"
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val text = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            proc.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
            var version = ""
            var versionCode = ""
            var name = "LSPosed"
            text.lineSequence().forEach { line ->
                val trimmed = line.trim()
                when {
                    trimmed.startsWith("name=") -> {
                        val n = trimmed.substringAfter("name=").trim()
                        if (n.isNotEmpty()) name = n
                    }
                    trimmed.startsWith("version=") -> {
                        version = trimmed.substringAfter("version=").trim()
                    }
                    trimmed.startsWith("versionCode=") -> {
                        versionCode = trimmed.substringAfter("versionCode=").trim()
                    }
                }
            }
            when {
                version.isNotEmpty() && versionCode.isNotEmpty() -> "$name $version ($versionCode)"
                version.isNotEmpty() -> "$name $version"
                else -> null
            }
        }.getOrNull()

        when {
            !fromRoot.isNullOrBlank() -> fromRoot
            isLspActivated -> "LSPosed (已激活)"
            else -> "未检测到 / 未激活"
        }
    }

    suspend fun readMemoryStatus(): MemoryStatus = withContext(Dispatchers.IO) {
        var memTotalKb = 0L
        var memAvailKb = 0L
        var swapTotalKb = 0L
        var swapFreeKb = 0L

        runCatching {
            val lines = File("/proc/meminfo").readLines()
            for (line in lines) {
                when {
                    line.startsWith("MemTotal:") -> {
                        memTotalKb = line.substringAfter("MemTotal:").trim().split(whitespaceRegex).firstOrNull()?.toLongOrNull() ?: 0L
                    }
                    line.startsWith("MemAvailable:") -> {
                        memAvailKb = line.substringAfter("MemAvailable:").trim().split(whitespaceRegex).firstOrNull()?.toLongOrNull() ?: 0L
                    }
                    line.startsWith("SwapTotal:") -> {
                        swapTotalKb = line.substringAfter("SwapTotal:").trim().split(whitespaceRegex).firstOrNull()?.toLongOrNull() ?: 0L
                    }
                    line.startsWith("SwapFree:") -> {
                        swapFreeKb = line.substringAfter("SwapFree:").trim().split(whitespaceRegex).firstOrNull()?.toLongOrNull() ?: 0L
                    }
                }
            }
        }

        val memUsedKb = (memTotalKb - memAvailKb).coerceAtLeast(0L)
        val swapUsedKb = (swapTotalKb - swapFreeKb).coerceAtLeast(0L)

        val kbToGb = 1024f * 1024f
        val ramPct = if (memTotalKb > 0) ((memUsedKb * 100L) / memTotalKb).toInt().coerceIn(0, 100) else 0
        val zramPct = if (swapTotalKb > 0) ((swapUsedKb * 100L) / swapTotalKb).toInt().coerceIn(0, 100) else 0

        MemoryStatus(
            ramTotalGb = memTotalKb / kbToGb,
            ramUsedGb = memUsedKb / kbToGb,
            ramAvailGb = memAvailKb / kbToGb,
            ramPercent = ramPct,
            zramTotalGb = swapTotalKb / kbToGb,
            zramUsedGb = swapUsedKb / kbToGb,
            zramFreeGb = swapFreeKb / kbToGb,
            zramPercent = zramPct
        )
    }

    suspend fun readAllLogs(systemInterface: SystemInterface?): List<String> = withContext(Dispatchers.IO) {
        val merged = LinkedHashSet<String>()

        // 1. Read via Binder IPC from system_server buffer & /data/system/SMillet/log
        runCatching {
            val ipcLogs = systemInterface?.getLogsText().orEmpty()
            if (ipcLogs.isNotBlank()) {
                ipcLogs.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.forEach { merged.add(it) }
            }
        }

        // 2. Fallback/supplement via Root from /data/system/SMillet/log and LSPosed module logs
        runCatching {
            val cmd = "cat ${ConfigKeys.LOCAL_LOG_PATH} 2>/dev/null; " +
                "grep -h 'Smillet-Next' /data/adb/lspd/log/modules_*.log /data/adb/lspd/log.old/modules_*.log 2>/dev/null | tail -n 600"
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            BufferedReader(InputStreamReader(proc.inputStream)).useLines { lines ->
                lines.forEach { raw ->
                    val cleaned = if (raw.contains("[Smillet-Next]")) {
                        val idx = raw.indexOf("20")
                        if (idx >= 0 && raw.indexOf("[Smillet-Next]") > idx) {
                            val subIdx = raw.indexOf("] ", raw.indexOf("Smillet-Next"))
                            if (subIdx >= 0 && subIdx + 2 < raw.length && raw.substring(subIdx + 2).startsWith("20")) {
                                raw.substring(subIdx + 2).trim()
                            } else {
                                raw.trim()
                            }
                        } else {
                            raw.trim()
                        }
                    } else {
                        raw.trim()
                    }
                    if (cleaned.isNotEmpty()) {
                        merged.add(cleaned)
                    }
                }
            }
            proc.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
        }

        merged.toList()
    }

    suspend fun scanRunningApps(
        context: Context,
        includeSystemApps: Boolean,
        systemInterface: SystemInterface? = null
    ): Result<List<RunningAppItem>> = withContext(Dispatchers.IO) {
        try {
            val pm = context.packageManager
            val installedApps = pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            val uidToAppMap = HashMap<Int, ApplicationInfo>()
            val pkgToAppMap = HashMap<String, ApplicationInfo>()

            for (info in installedApps) {
                pkgToAppMap[info.packageName] = info
                if (!uidToAppMap.containsKey(info.uid)) {
                    uidToAppMap[info.uid] = info
                }
            }

            val frozenUidsFromSystem = HashSet<Int>()
            val pidMap = LinkedHashMap<Int, Pair<Int, ProcessDetail>>()

            if (systemInterface != null) {
                runCatching {
                    val json = systemInterface.getRunningProcessesJson(includeSystemApps)
                    if (json.isNotBlank() && json.startsWith("[")) {
                        val type = object : TypeToken<List<SysProcDto>>() {}.type
                        val list: List<SysProcDto> = gson.fromJson(json, type) ?: emptyList()
                        for (dto in list) {
                            if (dto.isFrozenByGreeze) {
                                frozenUidsFromSystem.add(dto.uid)
                            }
                            val fType = classifyFreezeState(dto.wchan, dto.state, dto.isFrozenByGreeze)
                            val detail = ProcessDetail(
                                pid = dto.pid,
                                processName = dto.processName,
                                rssKb = dto.rssKb,
                                wchan = dto.wchan,
                                state = dto.state,
                                isFrozen = fType != FreezeType.RUNNING,
                                freezeType = fType
                            )
                            pidMap[dto.pid] = dto.uid to detail
                        }
                    }
                }
            }

            runCatching {
                val proc = Runtime.getRuntime().exec(
                    arrayOf("su", "-c", "ps -A -o USER,PID,RSS,WCHAN,S,ARGS")
                )
                val reader = BufferedReader(InputStreamReader(proc.inputStream))
                reader.useLines { lines ->
                    lines.forEach { rawLine ->
                        val line = rawLine.trim()
                        if (line.isEmpty() || line.startsWith("USER")) return@forEach

                        val parts = line.split(whitespaceRegex, limit = 6)
                        if (parts.size < 6) return@forEach

                        val userStr = parts[0]
                        val pid = parts[1].toIntOrNull() ?: return@forEach
                        val rssKb = parts[2].toLongOrNull() ?: 0L
                        val wchan = parts[3]
                        val state = parts[4]
                        val cmdArgs = parts[5].trim()

                        if (state == "Z" || cmdArgs.startsWith("[")) return@forEach

                        val uid = parseAndroidUid(userStr) ?: return@forEach
                        val appId = uid % 100000
                        if (!includeSystemApps && appId < 10000) return@forEach

                        val procName = cmdArgs.split(whitespaceRegex).firstOrNull() ?: cmdArgs
                        if (!procName.contains(".")) return@forEach

                        val isUidFrozen = frozenUidsFromSystem.contains(uid)
                        val freezeType = classifyFreezeState(wchan, state, isUidFrozen)
                        val detail = ProcessDetail(
                            pid = pid,
                            processName = procName,
                            rssKb = if (rssKb > 0) rssKb else (pidMap[pid]?.second?.rssKb ?: 0L),
                            wchan = if (wchan != "-" && wchan != "0") wchan else (pidMap[pid]?.second?.wchan ?: wchan),
                            state = state,
                            isFrozen = freezeType != FreezeType.RUNNING,
                            freezeType = freezeType
                        )
                        pidMap[pid] = uid to detail
                    }
                }
                proc.waitFor()
            }

            val grouped = HashMap<String, MutableList<ProcessDetail>>()
            val pkgUidMap = HashMap<String, Int>()

            for ((_, pair) in pidMap) {
                val (uid, detail) = pair
                val basePkgFromProc = detail.processName.substringBefore(":")
                val appInfo = pkgToAppMap[basePkgFromProc]
                    ?: resolveAppInfoForUid(pm, uid, uidToAppMap, pkgToAppMap)
                    ?: continue

                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                if (!includeSystemApps && isSystem) continue

                pkgUidMap[appInfo.packageName] = uid
                grouped.getOrPut(appInfo.packageName) { mutableListOf() }.add(detail)
            }

            val resultList = grouped.mapNotNull { (pkg, processes) ->
                val appInfo = pkgToAppMap[pkg] ?: return@mapNotNull null
                val appName = pm.getApplicationLabel(appInfo).toString().trim()
                val icon = runCatching { pm.getApplicationIcon(appInfo) }.getOrNull()
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val totalRssMb = processes.sumOf { it.rssKb } / 1024f

                RunningAppItem(
                    uid = pkgUidMap[pkg] ?: appInfo.uid,
                    packageName = pkg,
                    appName = appName,
                    icon = icon,
                    isSystemApp = isSystem,
                    totalRssMb = totalRssMb,
                    processes = processes.sortedBy { it.processName }
                )
            }.sortedWith(
                compareByDescending<RunningAppItem> { it.frozenCount > 0 }
                    .thenByDescending { it.totalRssMb }
            )

            Result.success(resultList)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun parseAndroidUid(user: String): Int? {
        user.toIntOrNull()?.let { return it }
        if (user == "system") return 1000
        if (user == "phone" || user == "radio") return 1001
        if (user == "shell") return 2000
        if (!user.startsWith("u")) return null

        val underscoreIdx = user.indexOf('_')
        if (underscoreIdx <= 1) return null
        val userId = user.substring(1, underscoreIdx).toIntOrNull() ?: return null
        val suffix = user.substring(underscoreIdx + 1)
        return when {
            suffix.startsWith("a") -> {
                val offset = suffix.substring(1).toIntOrNull() ?: return null
                userId * 100000 + 10000 + offset
            }
            suffix.startsWith("i") -> {
                val offset = suffix.substring(1).toIntOrNull() ?: return null
                userId * 100000 + 99000 + offset
            }
            else -> null
        }
    }

    private fun resolveAppInfoForUid(
        pm: PackageManager,
        uid: Int,
        uidToAppMap: Map<Int, ApplicationInfo>,
        pkgToAppMap: Map<String, ApplicationInfo>
    ): ApplicationInfo? {
        uidToAppMap[uid]?.let { return it }
        val normalizedUid = if (uid > 19999) {
            val s = uid.toString()
            ("1" + s.substring(s.length - 4)).toIntOrNull() ?: uid
        } else {
            uid
        }
        uidToAppMap[normalizedUid]?.let { return it }
        val pkgs = runCatching { pm.getPackagesForUid(normalizedUid) }.getOrNull()
        val firstPkg = pkgs?.firstOrNull() ?: return null
        return pkgToAppMap[firstPkg]
    }

    private fun classifyFreezeState(
        wchan: String,
        state: String,
        isFrozenByGreeze: Boolean
    ): FreezeType {
        val lower = wchan.lowercase()
        return when {
            lower.contains("do_freezer_trap") ||
                lower.contains("get_signal") ||
                lower.contains("freezable_schedule") ||
                lower.contains("freezer") -> FreezeType.V2
            lower.contains("__refrigerator") || lower.contains("refrigerator") -> FreezeType.V1
            lower.contains("do_signal_stop") || state.equals("T", ignoreCase = true) -> FreezeType.KILL
            isFrozenByGreeze -> FreezeType.V2
            else -> FreezeType.RUNNING
        }
    }
}
