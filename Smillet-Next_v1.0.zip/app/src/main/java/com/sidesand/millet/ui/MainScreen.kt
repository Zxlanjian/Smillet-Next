package com.sidesand.millet.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme

private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(5f, 3f); horizontalLineTo(19f)
            curveTo(20.1f, 3f, 21f, 3.9f, 21f, 5f)
            verticalLineTo(19f)
            curveTo(21f, 20.1f, 20.1f, 21f, 19f, 21f)
            horizontalLineTo(5f)
            curveTo(3.9f, 21f, 3f, 20.1f, 3f, 19f)
            verticalLineTo(5f)
            curveTo(3f, 3.9f, 3.9f, 3f, 5f, 3f); close()
            moveTo(5f, 5f); verticalLineTo(19f); horizontalLineTo(13f); verticalLineTo(5f); horizontalLineTo(5f); close()
            moveTo(15f, 5f); verticalLineTo(19f); horizontalLineTo(19f); verticalLineTo(5f); horizontalLineTo(15f); close()
            moveTo(7f, 7f); horizontalLineTo(11f); verticalLineTo(9f); horizontalLineTo(7f); close()
            moveTo(7f, 11f); horizontalLineTo(11f); verticalLineTo(13f); horizontalLineTo(7f); close()
            moveTo(7f, 15f); horizontalLineTo(11f); verticalLineTo(17f); horizontalLineTo(7f); close()
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(6f, 2f); horizontalLineTo(14f); lineTo(20f, 8f); verticalLineTo(20f)
            curveTo(20f, 21.1f, 19.1f, 22f, 18f, 22f)
            horizontalLineTo(6f)
            curveTo(4.9f, 22f, 4f, 21.1f, 4f, 20f)
            verticalLineTo(4f)
            curveTo(4f, 2.9f, 4.9f, 2f, 6f, 2f); close()
            moveTo(13f, 3.5f); verticalLineTo(9f); horizontalLineTo(18.5f); lineTo(13f, 3.5f); close()
            moveTo(8f, 12f); horizontalLineTo(16f); verticalLineTo(14f); horizontalLineTo(8f); close()
            moveTo(8f, 16f); horizontalLineTo(14f); verticalLineTo(18f); horizontalLineTo(8f); close()
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(5f, 3f); horizontalLineTo(19f)
            curveTo(20.1f, 3f, 21f, 3.9f, 21f, 5f)
            verticalLineTo(19f)
            curveTo(21f, 20.1f, 20.1f, 21f, 19f, 21f)
            horizontalLineTo(5f)
            curveTo(3.9f, 21f, 3f, 20.1f, 3f, 19f)
            verticalLineTo(5f)
            curveTo(3f, 3.9f, 3.9f, 3f, 5f, 3f); close()
            moveTo(10f, 17f); lineTo(5f, 12f); lineTo(6.41f, 10.59f)
            lineTo(10f, 14.17f); lineTo(17.59f, 6.58f); lineTo(19f, 8f); close()
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(12f, 2f); lineTo(20.66f, 7f); verticalLineTo(17f)
            lineTo(12f, 22f); lineTo(3.34f, 17f); verticalLineTo(7f); close()
            moveTo(12f, 4.31f); lineTo(5.34f, 8.15f); verticalLineTo(15.85f)
            lineTo(12f, 19.69f); lineTo(18.66f, 15.85f); verticalLineTo(8.15f); close()
            moveTo(12f, 8.5f)
            curveTo(13.93f, 8.5f, 15.5f, 10.07f, 15.5f, 12f)
            curveTo(15.5f, 13.93f, 13.93f, 15.5f, 12f, 15.5f)
            curveTo(10.07f, 15.5f, 8.5f, 13.93f, 8.5f, 12f)
            curveTo(8.5f, 10.07f, 10.07f, 8.5f, 12f, 8.5f); close()
        }
    }.build()
}

private val IconMoreVert: ImageVector by lazy {
    ImageVector.Builder("MoreVert", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(12f, 8f); curveTo(13.1f, 8f, 14f, 7.1f, 14f, 6f)
            curveTo(14f, 4.9f, 13.1f, 4f, 12f, 4f)
            curveTo(10.9f, 4f, 10f, 4.9f, 10f, 6f)
            curveTo(10f, 7.1f, 10.9f, 8f, 12f, 8f); close()
            moveTo(12f, 10f); curveTo(10.9f, 10f, 10f, 10.9f, 10f, 12f)
            curveTo(10f, 13.1f, 10.9f, 14f, 12f, 14f)
            curveTo(13.1f, 14f, 14f, 13.1f, 14f, 12f)
            curveTo(14f, 10.9f, 13.1f, 10f, 12f, 10f); close()
            moveTo(12f, 16f); curveTo(10.9f, 16f, 10f, 16.9f, 10f, 18f)
            curveTo(10f, 19.1f, 10.9f, 20f, 12f, 20f)
            curveTo(13.1f, 20f, 14f, 19.1f, 14f, 18f)
            curveTo(14f, 16.9f, 13.1f, 16f, 12f, 16f); close()
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(17.65f, 6.35f)
            curveTo(16.2f, 4.9f, 14.21f, 4f, 12f, 4f)
            curveTo(7.58f, 4f, 4.01f, 7.58f, 4.01f, 12f)
            curveTo(4.01f, 16.42f, 7.58f, 20f, 12f, 20f)
            curveTo(15.73f, 20f, 18.84f, 17.45f, 19.73f, 14f)
            horizontalLineTo(17.65f)
            curveTo(16.83f, 16.33f, 14.61f, 18f, 12f, 18f)
            curveTo(8.69f, 18f, 6f, 15.31f, 6f, 12f)
            curveTo(6f, 8.69f, 8.69f, 6f, 12f, 6f)
            curveTo(13.66f, 6f, 15.14f, 6.69f, 16.22f, 7.78f)
            lineTo(13f, 11f); horizontalLineTo(20f); verticalLineTo(4f); close()
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(15.41f, 7.41f); lineTo(14.0f, 6.0f); lineTo(8.0f, 12.0f)
            lineTo(14.0f, 18.0f); lineTo(15.41f, 16.59f); lineTo(10.83f, 12.0f); close()
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showLogPage by remember { mutableStateOf(false) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()

    val config by viewModel.config.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val scrollBehavior = MiuixScrollBehavior()
    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")

    BackHandler(enabled = selectedAppForConfig != null || showLogPage) {
        if (selectedAppForConfig != null) {
            selectedAppForConfig = null
        } else if (showLogPage) {
            showLogTopMenu = false
            showLogPage = false
        }
    }

    Scaffold(
        topBar = {
            val activeApp = selectedAppForConfig
            when {
                activeApp != null -> {
                    SmallTopAppBar(
                        title = activeApp.second,
                        navigationIcon = {
                            IconButton(onClick = { selectedAppForConfig = null }) {
                                Icon(
                                    imageVector = IconBack,
                                    contentDescription = "返回",
                                    tint = MiuixTheme.colorScheme.onSurface
                                )
                            }
                        }
                    )
                }
                showLogPage -> {
                    SmallTopAppBar(
                        title = "当前日志",
                        navigationIcon = {
                            IconButton(onClick = {
                                showLogTopMenu = false
                                showLogPage = false
                            }) {
                                Icon(
                                    imageVector = IconBack,
                                    contentDescription = "返回",
                                    tint = MiuixTheme.colorScheme.onSurface
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { showLogTopMenu = !showLogTopMenu }) {
                                Icon(
                                    imageVector = IconMoreVert,
                                    contentDescription = "日志选项",
                                    tint = MiuixTheme.colorScheme.onSurface
                                )
                            }
                        }
                    )
                }
                else -> {
                    TopAppBar(
                        title = tabTitles[selectedTab],
                        scrollBehavior = scrollBehavior,
                        actions = {
                            when (selectedTab) {
                                1 -> {
                                    IconButton(onClick = { showAppFilterSheet = true }) {
                                        Icon(
                                            imageVector = IconMoreVert,
                                            contentDescription = "筛选",
                                            tint = MiuixTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                2 -> {
                                    IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                        Icon(
                                            imageVector = IconRefresh,
                                            contentDescription = "刷新",
                                            tint = MiuixTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
            }
        },
        bottomBar = {
            if (selectedAppForConfig == null && !showLogPage) {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = IconHome,
                        label = "主页"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = IconAppList,
                        label = "应用列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = {
                            selectedTab = 2
                            viewModel.refreshRunningApps(includeSystemApps)
                        },
                        icon = IconRunningCheck,
                        label = "运行列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = IconHexSettings,
                        label = "设置"
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val activeApp = selectedAppForConfig
            when {
                activeApp != null -> {
                    AppConfigDialog(
                        packageName = activeApp.first,
                        appName = activeApp.second,
                        config = config,
                        viewModel = viewModel,
                        onDismiss = { selectedAppForConfig = null }
                    )
                }
                showLogPage -> {
                    LogPage(
                        viewModel = viewModel,
                        listState = logListState,
                        filterLevel = logFilterLevel,
                        onFilterLevelChange = { logFilterLevel = it },
                        showTopMenu = showLogTopMenu,
                        onDismissTopMenu = { showLogTopMenu = false }
                    )
                }
                else -> {
                    Crossfade(targetState = selectedTab, label = "MainTabs") { tab ->
                        when (tab) {
                            0 -> HomePage(
                                viewModel = viewModel,
                                config = config,
                                isSystemActive = isSystemActive,
                                isPowerKeeperActive = isPkActive,
                                scrollBehavior = scrollBehavior,
                                onNavigateToWhitelist = {
                                    appFilterIndex = 2
                                    selectedTab = 1
                                },
                                onNavigateToBlacklist = {
                                    appFilterIndex = 3
                                    selectedTab = 1
                                },
                                onNavigateToRunning = { selectedTab = 2 },
                                onNavigateToLogs = {
                                    showLogTopMenu = false
                                    showLogPage = true
                                }
                            )
                            1 -> AppListPage(
                                viewModel = viewModel,
                                config = config,
                                scrollBehavior = scrollBehavior,
                                showFilterSheet = showAppFilterSheet,
                                onDismissFilterSheet = { showAppFilterSheet = false },
                                includeSystemApps = includeSystemApps,
                                onIncludeSystemAppsChange = { includeSystemApps = it },
                                filterIndex = appFilterIndex,
                                onFilterIndexChange = { appFilterIndex = it },
                                onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name }
                            )
                            2 -> RunningListPage(
                                viewModel = viewModel,
                                scrollBehavior = scrollBehavior,
                                onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                                onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                            )
                            3 -> SettingsPage(
                                viewModel = viewModel,
                                config = config,
                                scrollBehavior = scrollBehavior
                            )
                        }
                    }
                }
            }

            diagnosticPair?.let { (pkg, reason) ->
                OverlayDialog(
                    show = true,
                    title = "诊断冻结状态",
                    summary = pkg,
                    onDismissRequest = { viewModel.dismissDiagnosticDialog() }
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(text = reason)
                        Spacer(modifier = Modifier.height(16.dp))
                        TextButton(
                            text = "我知道了",
                            onClick = { viewModel.dismissDiagnosticDialog() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }
    }
}
