package com.sidesand.millet.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import kotlinx.coroutines.CancellationException
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme

/**
 * 1:1 还原 Miuix / Cirno 风格底部导航栏与顶栏矢量图标：
 * - IconHome：圆角方框 + 中轴分栏线 + 左侧 2×3 六点矩阵
 * - IconAppList：圆角文档 + 右下角折角 + 上半部双横线
 * - IconRunningCheck：圆角方框 + 内部勾选镂空 (EvenOdd)
 * - IconHexSettings：圆润六边形 + 中心圆环
 */
private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        // 外框与中轴线
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(6.8f, 3.2f)
            horizontalLineTo(17.2f)
            curveTo(19.2f, 3.2f, 20.8f, 4.8f, 20.8f, 6.8f)
            verticalLineTo(17.2f)
            curveTo(20.8f, 19.2f, 19.2f, 20.8f, 17.2f, 20.8f)
            horizontalLineTo(6.8f)
            curveTo(4.8f, 20.8f, 3.2f, 19.2f, 3.2f, 17.2f)
            verticalLineTo(6.8f)
            curveTo(3.2f, 4.8f, 4.8f, 3.2f, 6.8f, 3.2f)
            close()
            moveTo(13.6f, 3.4f)
            verticalLineTo(20.6f)
        }
        // 左侧 2x3 圆点矩阵
        path(fill = SolidColor(Color.Black)) {
            val cols = floatArrayOf(6.8f, 10.1f)
            val rows = floatArrayOf(7.8f, 12.0f, 16.2f)
            val r = 1.05f
            for (cx in cols) {
                for (cy in rows) {
                    moveTo(cx + r, cy)
                    curveTo(cx + r, cy + r * 0.55f, cx + r * 0.55f, cy + r, cx, cy + r)
                    curveTo(cx - r * 0.55f, cy + r, cx - r, cy + r * 0.55f, cx - r, cy)
                    curveTo(cx - r, cy - r * 0.55f, cx - r * 0.55f, cy - r, cx, cy - r)
                    curveTo(cx + r * 0.55f, cy - r, cx + r, cy - r * 0.55f, cx + r, cy)
                    close()
                }
            }
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            // 文档外轮廓（右下角折角）
            moveTo(7.0f, 2.8f)
            horizontalLineTo(17.0f)
            curveTo(18.8f, 2.8f, 20.2f, 4.2f, 20.2f, 6.0f)
            verticalLineTo(15.2f)
            lineTo(14.4f, 21.2f)
            horizontalLineTo(7.0f)
            curveTo(5.2f, 21.2f, 3.8f, 19.8f, 3.8f, 18.0f)
            verticalLineTo(6.0f)
            curveTo(3.8f, 4.2f, 5.2f, 2.8f, 7.0f, 2.8f)
            close()
            // 右下角内折线
            moveTo(14.2f, 21.0f)
            verticalLineTo(16.6f)
            curveTo(14.2f, 15.6f, 15.0f, 14.8f, 16.0f, 14.8f)
            horizontalLineTo(20.0f)
            // 上半部分两条水平文本线
            moveTo(8.0f, 8.2f)
            horizontalLineTo(16.0f)
            moveTo(8.0f, 12.0f)
            horizontalLineTo(13.4f)
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            fill = SolidColor(Color.Black),
            pathFillType = PathFillType.EvenOdd
        ) {
            // 实心圆角方框
            moveTo(7.0f, 3.0f)
            horizontalLineTo(17.0f)
            curveTo(19.2f, 3.0f, 21.0f, 4.8f, 21.0f, 7.0f)
            verticalLineTo(17.0f)
            curveTo(21.0f, 19.2f, 19.2f, 21.0f, 17.0f, 21.0f)
            horizontalLineTo(7.0f)
            curveTo(4.8f, 21.0f, 3.0f, 19.2f, 3.0f, 17.0f)
            verticalLineTo(7.0f)
            curveTo(3.0f, 4.8f, 4.8f, 3.0f, 7.0f, 3.0f)
            close()
            // 内部居中对勾镂空
            moveTo(10.4f, 16.4f)
            lineTo(6.7f, 12.7f)
            lineTo(8.2f, 11.2f)
            lineTo(10.4f, 13.4f)
            lineTo(15.8f, 8.0f)
            lineTo(17.3f, 9.5f)
            close()
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            // 圆润六边形外框
            moveTo(12.0f, 2.7f)
            lineTo(19.8f, 7.2f)
            verticalLineTo(16.8f)
            lineTo(12.0f, 21.3f)
            lineTo(4.2f, 16.8f)
            verticalLineTo(7.2f)
            close()
            // 中心圆环
            val r = 3.1f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.55f, 12f + r * 0.55f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.55f, 12f + r, 12f - r, 12f + r * 0.55f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.55f, 12f - r * 0.55f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.55f, 12f - r, 12f + r, 12f - r * 0.55f, 12f + r, 12f)
            close()
        }
    }.build()
}

private val IconMoreVert: ImageVector by lazy {
    ImageVector.Builder("MoreVert", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.Black)) {
            val centers = floatArrayOf(5.8f, 12.0f, 18.2f)
            val r = 1.65f
            for (cy in centers) {
                moveTo(12f + r, cy)
                curveTo(12f + r, cy + r * 0.55f, 12f + r * 0.55f, cy + r, 12f, cy + r)
                curveTo(12f - r * 0.55f, cy + r, 12f - r, cy + r * 0.55f, 12f - r, cy)
                curveTo(12f - r, cy - r * 0.55f, 12f - r * 0.55f, cy - r, 12f, cy - r)
                curveTo(12f + r * 0.55f, cy - r, 12f + r, cy - r * 0.55f, 12f + r, cy)
                close()
            }
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(18.2f, 7.6f)
            curveTo(16.8f, 5.6f, 14.5f, 4.4f, 12.0f, 4.4f)
            curveTo(7.8f, 4.4f, 4.4f, 7.8f, 4.4f, 12.0f)
            curveTo(4.4f, 16.2f, 7.8f, 19.6f, 12.0f, 19.6f)
            curveTo(15.6f, 19.6f, 18.6f, 17.1f, 19.4f, 13.7f)
            moveTo(18.6f, 4.4f)
            verticalLineTo(8.2f)
            horizontalLineTo(14.8f)
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.1f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(14.8f, 5.8f)
            lineTo(8.6f, 12.0f)
            lineTo(14.8f, 18.2f)
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showLogPage by remember { mutableStateOf(false) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()

    val config by viewModel.config.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val scrollBehavior = MiuixScrollBehavior()
    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")

    // 预测性返回手势实时状态
    var backProgress by remember { mutableFloatStateOf(0f) }
    var backSwipeEdge by remember { mutableIntStateOf(0) }

    val hasPopupOrSubPage = showAppFilterSheet || showLogTopMenu || selectedAppForConfig != null || showLogPage
    val canInterceptBack = hasPopupOrSubPage || selectedTab != 0

    val handleBackCommit = {
        when {
            showAppFilterSheet -> showAppFilterSheet = false
            showLogTopMenu -> showLogTopMenu = false
            selectedAppForConfig != null -> selectedAppForConfig = null
            showLogPage -> showLogPage = false
            selectedTab != 0 -> selectedTab = 0
        }
    }

    // 启用预测性返回手势时：实时收集滑动进度并驱动界面缩放/位移预览动画
    PredictiveBackHandler(enabled = config.predictiveBack && canInterceptBack) { progress ->
        try {
            progress.collect { backEvent ->
                backProgress = backEvent.progress.coerceIn(0f, 1f)
                backSwipeEdge = backEvent.swipeEdge
            }
            backProgress = 0f
            handleBackCommit()
        } catch (_: CancellationException) {
            backProgress = 0f
        }
    }

    // 关闭预测性返回手势时：使用传统立即返回
    BackHandler(enabled = !config.predictiveBack && canInterceptBack) {
        backProgress = 0f
        handleBackCommit()
    }

    val isPopupBackTarget = showAppFilterSheet || showLogTopMenu
    val isSubPageBackTarget = !isPopupBackTarget && (selectedAppForConfig != null || showLogPage)
    val isTabBackTarget = !hasPopupOrSubPage && selectedTab != 0

    val subPageProgress = if (config.predictiveBack && isSubPageBackTarget) backProgress else 0f
    val tabBackProgress = if (config.predictiveBack && isTabBackTarget) backProgress else 0f
    val popupBackProgress = if (config.predictiveBack && isPopupBackTarget) backProgress else 0f

    Scaffold(
        topBar = {
            val activeApp = selectedAppForConfig
            when {
                activeApp != null -> {
                    SmallTopAppBar(
                        title = activeApp.second,
                        navigationIcon = {
                            IconButton(onClick = { selectedAppForConfig = null }) {
                                Icon(
                                    imageVector = IconBack,
                                    contentDescription = "返回",
                                    tint = MiuixTheme.colorScheme.onSurface
                                )
                            }
                        }
                    )
                }
                showLogPage -> {
                    SmallTopAppBar(
                        title = "日志",
                        navigationIcon = {
                            IconButton(onClick = {
                                showLogTopMenu = false
                                showLogPage = false
                            }) {
                                Icon(
                                    imageVector = IconBack,
                                    contentDescription = "返回",
                                    tint = MiuixTheme.colorScheme.onSurface
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { showLogTopMenu = !showLogTopMenu }) {
                                Icon(
                                    imageVector = IconMoreVert,
                                    contentDescription = "日志选项",
                                    tint = MiuixTheme.colorScheme.onSurface
                                )
                            }
                        }
                    )
                }
                else -> {
                    TopAppBar(
                        title = tabTitles[selectedTab],
                        scrollBehavior = scrollBehavior,
                        actions = {
                            when (selectedTab) {
                                1 -> {
                                    IconButton(onClick = { showAppFilterSheet = !showAppFilterSheet }) {
                                        Icon(
                                            imageVector = IconMoreVert,
                                            contentDescription = "筛选",
                                            tint = MiuixTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                2 -> {
                                    IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                        Icon(
                                            imageVector = IconRefresh,
                                            contentDescription = "刷新",
                                            tint = MiuixTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
            }
        },
        bottomBar = {
            if (selectedAppForConfig == null && !showLogPage) {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = {
                            showAppFilterSheet = false
                            selectedTab = 0
                        },
                        icon = IconHome,
                        label = "主页"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = IconAppList,
                        label = "应用列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = {
                            showAppFilterSheet = false
                            selectedTab = 2
                            viewModel.refreshRunningApps(includeSystemApps)
                        },
                        icon = IconRunningCheck,
                        label = "运行列表"
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = {
                            showAppFilterSheet = false
                            selectedTab = 3
                        },
                        icon = IconHexSettings,
                        label = "设置"
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val activeApp = selectedAppForConfig

            // 当处于二级页面（应用详情或日志页）且正在进行预测性返回滑动时，底层预先渲染主页面以便露出底层预览
            val shouldRenderMainTabs = (activeApp == null && !showLogPage) || subPageProgress > 0f

            if (shouldRenderMainTabs) {
                // 当从非主页 Tab 边缘滑动返回主页时，底层也可预览主页
                if (tabBackProgress > 0f && selectedTab != 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                val peekScale = 0.95f + tabBackProgress * 0.05f
                                scaleX = peekScale
                                scaleY = peekScale
                                alpha = 0.5f + tabBackProgress * 0.5f
                            }
                    ) {
                        HomePage(
                            viewModel = viewModel,
                            config = config,
                            isSystemActive = isSystemActive,
                            isPowerKeeperActive = isPkActive,
                            scrollBehavior = scrollBehavior,
                            onNavigateToWhitelist = {
                                appFilterIndex = 2
                                selectedTab = 1
                            },
                            onNavigateToBlacklist = {
                                appFilterIndex = 3
                                selectedTab = 1
                            },
                            onNavigateToRunning = { selectedTab = 2 },
                            onNavigateToLogs = {
                                showLogTopMenu = false
                                showLogPage = true
                            }
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            if (subPageProgress > 0f) {
                                val bgScale = 0.95f + subPageProgress * 0.05f
                                scaleX = bgScale
                                scaleY = bgScale
                                alpha = 0.55f + subPageProgress * 0.45f
                            } else if (tabBackProgress > 0f) {
                                val fgScale = 1f - tabBackProgress * 0.08f
                                val edgeSign = if (backSwipeEdge == 0) 1f else -1f
                                scaleX = fgScale
                                scaleY = fgScale
                                translationX = edgeSign * tabBackProgress * 26.dp.toPx()
                                alpha = 1f - tabBackProgress * 0.25f
                                shape = RoundedCornerShape((tabBackProgress * 24f).dp)
                                clip = true
                            }
                        }
                ) {
                    Crossfade(targetState = selectedTab, label = "MainTabs") { tab ->
                        when (tab) {
                            0 -> HomePage(
                                viewModel = viewModel,
                                config = config,
                                isSystemActive = isSystemActive,
                                isPowerKeeperActive = isPkActive,
                                scrollBehavior = scrollBehavior,
                                onNavigateToWhitelist = {
                                    appFilterIndex = 2
                                    selectedTab = 1
                                },
                                onNavigateToBlacklist = {
                                    appFilterIndex = 3
                                    selectedTab = 1
                                },
                                onNavigateToRunning = { selectedTab = 2 },
                                onNavigateToLogs = {
                                    showLogTopMenu = false
                                    showLogPage = true
                                }
                            )
                            1 -> AppListPage(
                                viewModel = viewModel,
                                config = config,
                                scrollBehavior = scrollBehavior,
                                showFilterSheet = showAppFilterSheet,
                                onDismissFilterSheet = { showAppFilterSheet = false },
                                includeSystemApps = includeSystemApps,
                                onIncludeSystemAppsChange = { includeSystemApps = it },
                                filterIndex = appFilterIndex,
                                onFilterIndexChange = { appFilterIndex = it },
                                onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                                menuBackProgress = popupBackProgress
                            )
                            2 -> RunningListPage(
                                viewModel = viewModel,
                                scrollBehavior = scrollBehavior,
                                onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                                onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                            )
                            3 -> SettingsPage(
                                viewModel = viewModel,
                                config = config,
                                scrollBehavior = scrollBehavior
                            )
                        }
                    }
                }
            }

            if (activeApp != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            if (subPageProgress > 0f) {
                                val fgScale = 1f - subPageProgress * 0.09f
                                val edgeSign = if (backSwipeEdge == 0) 1f else -1f
                                scaleX = fgScale
                                scaleY = fgScale
                                translationX = edgeSign * subPageProgress * 28.dp.toPx()
                                alpha = 1f - subPageProgress * 0.20f
                                shape = RoundedCornerShape((subPageProgress * 26f).dp)
                                clip = true
                            }
                        }
                        .background(MiuixTheme.colorScheme.background)
                ) {
                    AppConfigDialog(
                        packageName = activeApp.first,
                        appName = activeApp.second,
                        config = config,
                        viewModel = viewModel,
                        onDismiss = { selectedAppForConfig = null }
                    )
                }
            } else if (showLogPage) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            if (subPageProgress > 0f) {
                                val fgScale = 1f - subPageProgress * 0.09f
                                val edgeSign = if (backSwipeEdge == 0) 1f else -1f
                                scaleX = fgScale
                                scaleY = fgScale
                                translationX = edgeSign * subPageProgress * 28.dp.toPx()
                                alpha = 1f - subPageProgress * 0.20f
                                shape = RoundedCornerShape((subPageProgress * 26f).dp)
                                clip = true
                            }
                        }
                        .background(MiuixTheme.colorScheme.background)
                ) {
                    LogPage(
                        viewModel = viewModel,
                        listState = logListState,
                        filterLevel = logFilterLevel,
                        onFilterLevelChange = { logFilterLevel = it },
                        showTopMenu = showLogTopMenu,
                        onDismissTopMenu = { showLogTopMenu = false },
                        menuBackProgress = popupBackProgress
                    )
                }
            }

            diagnosticPair?.let { (pkg, reason) ->
                OverlayDialog(
                    show = true,
                    title = "诊断冻结状态",
                    summary = pkg,
                    onDismissRequest = { viewModel.dismissDiagnosticDialog() }
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(text = reason)
                        Spacer(modifier = Modifier.height(16.dp))
                        TextButton(
                            text = "我知道了",
                            onClick = { viewModel.dismissDiagnosticDialog() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.textButtonColorsPrimary()
                        )
                    }
                }
            }
        }
    }
}
