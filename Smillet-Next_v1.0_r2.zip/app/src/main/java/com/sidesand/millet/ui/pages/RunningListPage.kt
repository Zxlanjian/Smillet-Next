package com.sidesand.millet.ui.pages

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.FreezeType
import com.sidesand.millet.data.RunningAppItem
import com.sidesand.millet.ui.MainViewModel
import com.sidesand.millet.ui.components.AppIcon
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.util.Locale

@Composable
fun RunningListPage(
    viewModel: MainViewModel,
    scrollBehavior: ScrollBehavior,
    onOpenAppConfig: (packageName: String, appName: String) -> Unit,
    onDiagnoseApp: (packageName: String) -> Unit
) {
    val runningApps by viewModel.runningApps.collectAsState()
    val isScanning by viewModel.isScanningRunning.collectAsState()

    if (runningApps.isEmpty() && !isScanning) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "暂无监视器数据",
                fontSize = 17.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
            )
        }
        return
    }

    val frozenCount = runningApps.count { it.frozenCount > 0 }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        item {
            Text(
                text = "进程监视 (${runningApps.size} 应用 · $frozenCount 已冻结)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, top = 4.dp, bottom = 6.dp)
            )
        }

        itemsIndexed(runningApps, key = { _, it -> it.packageName }) { index, item ->
            val isFirst = index == 0
            val isLast = index == runningApps.lastIndex
            val shape = when {
                isFirst && isLast -> RoundedCornerShape(18.dp)
                isFirst -> RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
                isLast -> RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp)
                else -> RoundedCornerShape(0.dp)
            }

            RunningAppRow(
                item = item,
                shape = shape,
                isFirst = isFirst,
                isLast = isLast,
                onClick = { onOpenAppConfig(item.packageName, item.appName) },
                onLongClick = { onDiagnoseApp(item.packageName) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RunningAppRow(
    item: RunningAppItem,
    shape: RoundedCornerShape,
    isFirst: Boolean,
    isLast: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val (badgeText, badgeColor) = when (item.primaryFreezeType) {
        FreezeType.V2 -> "V2 冻结" to Color(0xFF2874F0)
        FreezeType.V1 -> "V1 冻结" to Color(0xFF169976)
        FreezeType.KILL -> "SIGSTOP" to Color(0xFFD94A4A)
        FreezeType.RUNNING -> "运行中" to Color(0xFF1A1A1A)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MiuixTheme.colorScheme.surfaceVariant)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(
                start = 16.dp,
                end = 16.dp,
                top = if (isFirst) 16.dp else 12.dp,
                bottom = if (isLast) 16.dp else 12.dp
            )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIcon(
                drawable = item.icon,
                appName = item.appName,
                size = 46.dp
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${item.appName} (${item.frozenCount}/${item.totalCount})",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Normal
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${item.packageName} · ${String.format(Locale.US, "%.1f MB", item.totalRssMb)}",
                    fontSize = 13.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(badgeColor)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badgeText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }

        if (item.processes.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            item.processes.forEach { proc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 60.dp, top = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "[${proc.pid}] ${proc.processName}",
                        fontSize = 12.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = proc.wchan,
                        fontSize = 12.sp,
                        color = if (proc.isFrozen) {
                            MiuixTheme.colorScheme.primary
                        } else {
                            MiuixTheme.colorScheme.onSurfaceVariantSummary
                        }
                    )
                }
            }
        }
    }
}
