package com.sidesand.millet.hook

import android.util.Log
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SMilletLogger {
    private const val TAG = "Smillet-Next"
    private const val MAX_BUFFER_LINES = 1500
    private const val MAX_FILE_BYTES = 1024 * 1024L // 1 MB
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    private val memoryBuffer = ArrayDeque<String>(MAX_BUFFER_LINES)

    @Volatile
    var config: MilletConfigSnapshot = MilletConfigSnapshot()

    fun debug(msg: String) {
        if (!config.isLog && !config.simplifyLog && !config.dozeLog) return
        write(Log.DEBUG, "DEBUG", msg, null)
    }

    fun info(msg: String) {
        write(Log.INFO, "INFO", msg, null)
    }

    fun warn(msg: String) {
        write(Log.WARN, "WARN", msg, null)
    }

    fun error(msg: String, t: Throwable? = null) {
        val full = if (t != null) "$msg: ${t.message}" else msg
        write(Log.ERROR, "ERROR", full, t)
    }

    fun recordExternalLog(formattedLine: String) {
        synchronized(memoryBuffer) {
            if (memoryBuffer.size >= MAX_BUFFER_LINES) {
                memoryBuffer.removeFirst()
            }
            memoryBuffer.addLast(formattedLine)
        }
        appendToLocalFile(formattedLine)
    }

    fun getBufferedLogs(): String {
        val fileLines = runCatching {
            val file = File(ConfigKeys.LOCAL_LOG_PATH)
            if (file.exists() && file.canRead()) {
                file.readLines().takeLast(MAX_BUFFER_LINES)
            } else {
                emptyList()
            }
        }.getOrDefault(emptyList())

        val memLines = synchronized(memoryBuffer) {
            memoryBuffer.toList()
        }

        if (fileLines.isEmpty()) {
            return memLines.joinToString("\n")
        }
        val merged = LinkedHashSet<String>(fileLines.size + memLines.size)
        merged.addAll(fileLines)
        merged.addAll(memLines)
        val sorted = merged.toList().sortedBy { line ->
            if (line.length >= 23 && line.startsWith("20")) line.substring(0, 23) else line
        }
        return sorted.takeLast(MAX_BUFFER_LINES).joinToString("\n")
    }

    fun clearBufferedLogs() {
        synchronized(memoryBuffer) {
            memoryBuffer.clear()
        }
        runCatching {
            val file = File(ConfigKeys.LOCAL_LOG_PATH)
            if (file.exists()) {
                file.writeText("")
            }
        }
    }

    private fun appendToLocalFile(formatted: String) {
        runCatching {
            val file = File(ConfigKeys.LOCAL_LOG_PATH)
            file.parentFile?.mkdirs()
            if (file.exists() && file.length() > MAX_FILE_BYTES) {
                val tail = runCatching { file.readLines().takeLast(800) }.getOrDefault(emptyList())
                file.writeText(tail.joinToString("\n") + "\n")
            }
            FileWriter(file, true).use { it.appendLine(formatted) }
        }
    }

    private fun write(priority: Int, level: String, msg: String, t: Throwable?) {
        val formatted = "${dateFormat.format(Date())} [$level] [$TAG] $msg"
        synchronized(memoryBuffer) {
            if (memoryBuffer.size >= MAX_BUFFER_LINES) {
                memoryBuffer.removeFirst()
            }
            memoryBuffer.addLast(formatted)
        }
        XposedCompat.log(priority, TAG, formatted, t)
        appendToLocalFile(formatted)
    }
}
