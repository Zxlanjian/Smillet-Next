package com.sidesand.millet.data

data class MilletConfigSnapshot(
    var disableKill: Boolean = true,
    var disableVolume: Boolean = true,
    var disableCharge: Boolean = true,
    var blockAddPowerSaveWhitelistApps: Boolean = true,
    var batteryChangeObserve: Boolean = false,
    var enableDoze: Boolean = true,
    var skipStateCheck: Boolean = true,
    var disableMotionListener: Boolean = true,
    var batteryOptWhiteSet: Set<String> = emptySet(),
    var batteryOptBlackSet: Set<String> = emptySet(),
    var whiteAppSet: Set<String> = emptySet(),
    var messageAppSet: Set<String> = emptySet(),
    var forceFreezeSet: Set<String> = emptySet(),
    var blockThawSet: Set<String> = emptySet(),
    var forbidSyncBinderSet: Set<String> = emptySet(),
    var notFreezeWhenHasFgsSet: Set<String> = emptySet(),
    var logLevel: String = "info"
)
