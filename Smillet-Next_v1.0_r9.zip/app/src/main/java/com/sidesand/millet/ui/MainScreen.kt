package com.sidesand.millet.ui

import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.components.MiuixPopupActionRow
import com.sidesand.millet.ui.components.MiuixPopupOptionRow
import com.sidesand.millet.ui.components.MiuixTopPopupMenu
import com.sidesand.millet.ui.pages.APP_FILTER_OPTIONS
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.MAX_DISPLAY_LOG_COUNT
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import com.sidesand.millet.ui.pages.filterLogLines
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 1:1 还原参考图片 (1000110482_63e8b6.jpg) 的顶栏背景毛玻璃模糊着色器（已移除顶栏下方边缘模糊，绝不遮挡正文文字）：
 * - 严格限制模糊作用区域在顶栏内部 (fragCoord.y < topBarBottom)，顶栏下方 (fragCoord.y >= topBarBottom) 100% 原样清晰输出；
 * - 通过 6-Pass 可分离级联高斯卷积 (H1 -> V1 -> H2 -> V2 -> H3 -> V3) 将进入顶栏背后的卡片与色彩柔和扩散为大半径云雾状光晕，并叠加毛玻璃表面色。
 */
private const val TOP_BAR_BLUR_H_AGSL = """
    uniform shader content;
    uniform float topBarBottom;
    uniform float stepSize;

    half4 main(float2 fragCoord) {
        if (fragCoord.y >= topBarBottom) {
            return content.eval(fragCoord);
        }
        half4 accum = half4(0.0);
        float weightSum = 0.0;
        for (int i = -12; i <= 12; i++) {
            float fi = float(i);
            float w = exp(-(fi * fi) / 36.0);
            float2 samplePos = float2(max(1.0, fragCoord.x + fi * stepSize), fragCoord.y);
            accum += content.eval(samplePos) * w;
            weightSum += w;
        }
        return accum / weightSum;
    }
"""

private const val TOP_BAR_BLUR_V_TINT_AGSL = """
    uniform shader content;
    uniform float topBarBottom;
    uniform float stepSize;
    uniform float4 surfaceTint;

    half4 main(float2 fragCoord) {
        if (fragCoord.y >= topBarBottom) {
            return content.eval(fragCoord);
        }
        float maxSampleY = max(1.0, topBarBottom - 1.0);
        half4 accum = half4(0.0);
        float weightSum = 0.0;
        for (int i = -12; i <= 12; i++) {
            float fi = float(i);
            float w = exp(-(fi * fi) / 36.0);
            float sy = clamp(fragCoord.y + fi * stepSize, 1.0, maxSampleY);
            accum += content.eval(float2(fragCoord.x, sy)) * w;
            weightSum += w;
        }
        half4 blurred = accum / weightSum;
        if (surfaceTint.a > 0.0) {
            return mix(blurred, half4(surfaceTint.rgb, 1.0), surfaceTint.a);
        }
        return blurred;
    }
"""

private sealed interface ScreenRoute {
    data class MainTab(val tabIndex: Int) : ScreenRoute
    data class AppDetail(val packageName: String, val appName: String) : ScreenRoute
    data object Logs : ScreenRoute
}

private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(5.6f, 3.4f)
            horizontalLineTo(9.4f)
            curveTo(10.6f, 3.4f, 11.4f, 4.2f, 11.4f, 5.4f)
            verticalLineTo(18.6f)
            curveTo(11.4f, 19.8f, 10.6f, 20.6f, 9.4f, 20.6f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 20.6f, 3.6f, 19.8f, 3.6f, 18.6f)
            verticalLineTo(5.4f)
            curveTo(3.6f, 4.2f, 4.4f, 3.4f, 5.6f, 3.4f)
            close()

            moveTo(16.2f, 3.4f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 3.4f, 20.4f, 4.2f, 20.4f, 5.4f)
            verticalLineTo(8.5f)
            curveTo(20.4f, 9.7f, 19.6f, 10.5f, 18.4f, 10.5f)
            horizontalLineTo(16.2f)
            curveTo(15.0f, 10.5f, 14.2f, 9.7f, 14.2f, 8.5f)
            verticalLineTo(5.4f)
            curveTo(14.2f, 4.2f, 15.0f, 3.4f, 16.2f, 3.4f)
            close()

            moveTo(16.2f, 13.5f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 13.5f, 20.4f, 14.3f, 20.4f, 15.5f)
            verticalLineTo(18.6f)
            curveTo(20.4f, 19.8f, 19.6f, 20.6f, 18.4f, 20.6f)
            horizontalLineTo(16.2f)
            curveTo(15.0f, 20.6f, 14.2f, 19.8f, 14.2f, 18.6f)
            verticalLineTo(15.5f)
            curveTo(14.2f, 14.3f, 15.0f, 13.5f, 16.2f, 13.5f)
            close()
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(5.6f, 3.6f)
            horizontalLineTo(8.6f)
            curveTo(9.8f, 3.6f, 10.6f, 4.4f, 10.6f, 5.6f)
            verticalLineTo(8.6f)
            curveTo(10.6f, 9.8f, 9.8f, 10.6f, 8.6f, 10.6f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 10.6f, 3.6f, 9.8f, 3.6f, 8.6f)
            verticalLineTo(5.6f)
            curveTo(3.6f, 4.4f, 4.4f, 3.6f, 5.6f, 3.6f)
            close()

            val cx = 17.0f
            val cy = 7.1f
            val r = 3.5f
            moveTo(cx + r, cy)
            curveTo(cx + r, cy + r * 0.552f, cx + r * 0.552f, cy + r, cx, cy + r)
            curveTo(cx - r * 0.552f, cy + r, cx - r, cy + r * 0.552f, cx - r, cy)
            curveTo(cx - r, cy - r * 0.552f, cx - r * 0.552f, cy - r, cx, cy - r)
            curveTo(cx + r * 0.552f, cy - r, cx + r, cy - r * 0.552f, cx + r, cy)
            close()

            moveTo(5.6f, 13.4f)
            horizontalLineTo(8.6f)
            curveTo(9.8f, 13.4f, 10.6f, 14.2f, 10.6f, 15.4f)
            verticalLineTo(18.4f)
            curveTo(10.6f, 19.6f, 9.8f, 20.4f, 8.6f, 20.4f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 20.4f, 3.6f, 19.6f, 3.6f, 18.4f)
            verticalLineTo(15.4f)
            curveTo(3.6f, 14.2f, 4.4f, 13.4f, 5.6f, 13.4f)
            close()

            moveTo(15.4f, 13.4f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 13.4f, 20.4f, 14.2f, 20.4f, 15.4f)
            verticalLineTo(18.4f)
            curveTo(20.4f, 19.6f, 19.6f, 20.4f, 18.4f, 20.4f)
            horizontalLineTo(15.4f)
            curveTo(14.2f, 20.4f, 13.4f, 19.6f, 13.4f, 18.4f)
            verticalLineTo(15.4f)
            curveTo(13.4f, 14.2f, 14.2f, 13.4f, 15.4f, 13.4f)
            close()
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(7.2f, 3.4f)
            horizontalLineTo(16.8f)
            curveTo(19.0f, 3.4f, 20.6f, 5.0f, 20.6f, 7.2f)
            verticalLineTo(16.8f)
            curveTo(20.6f, 19.0f, 19.0f, 20.6f, 16.8f, 20.6f)
            horizontalLineTo(7.2f)
            curveTo(5.0f, 20.6f, 3.4f, 19.0f, 3.4f, 16.8f)
            verticalLineTo(7.2f)
            curveTo(3.4f, 5.0f, 5.0f, 3.4f, 7.2f, 3.4f)
            close()

            moveTo(6.6f, 12.2f)
            horizontalLineTo(9.0f)
            lineTo(10.6f, 8.6f)
            lineTo(13.2f, 15.4f)
            lineTo(14.9f, 12.2f)
            horizontalLineTo(17.4f)
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(12.0f, 2.8f)
            lineTo(19.8f, 7.3f)
            verticalLineTo(16.7f)
            lineTo(12.0f, 21.2f)
            lineTo(4.2f, 16.7f)
            verticalLineTo(7.3f)
            close()
            val r = 3.15f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
    }.build()
}

private val IconMoreCircle: ImageVector by lazy {
    ImageVector.Builder("MoreCircle", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.85f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            val r = 9.0f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
        path(fill = SolidColor(Color.Black)) {
            val xs = floatArrayOf(8.2f, 12.0f, 15.8f)
            val dotR = 1.15f
            for (cx in xs) {
                moveTo(cx + dotR, 12f)
                curveTo(cx + dotR, 12f + dotR * 0.55f, cx + dotR * 0.55f, 12f + dotR, cx, 12f + dotR)
                curveTo(cx - dotR * 0.55f, 12f + dotR, cx - dotR, 12f + dotR * 0.55f, cx - dotR, 12f)
                curveTo(cx - dotR, 12f - dotR * 0.55f, cx - dotR * 0.55f, 12f - dotR, cx, 12f - dotR)
                curveTo(cx + dotR * 0.55f, 12f - dotR, cx + dotR, 12f - dotR * 0.55f, cx + dotR, 12f)
                close()
            }
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(18.2f, 7.6f)
            curveTo(16.8f, 5.6f, 14.5f, 4.4f, 12.0f, 4.4f)
            curveTo(7.8f, 4.4f, 4.4f, 7.8f, 4.4f, 12.0f)
            curveTo(4.4f, 16.2f, 7.8f, 19.6f, 12.0f, 19.6f)
            curveTo(15.6f, 19.6f, 18.6f, 17.1f, 19.4f, 13.7f)
            moveTo(18.6f, 4.4f)
            verticalLineTo(8.2f)
            horizontalLineTo(14.8f)
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.1f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(14.8f, 5.8f)
            lineTo(8.6f, 12.0f)
            lineTo(14.8f, 18.2f)
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showLogPage by remember { mutableStateOf(false) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val config by viewModel.config.collectAsState()
    val logs by viewModel.logsList.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")
    val isDark = isSystemInDarkTheme()
    val surfaceBg = MiuixTheme.colorScheme.background

    var appListTopBarHeight by remember { mutableStateOf(96.dp) }
    var logPageTopBarHeight by remember { mutableStateOf(88.dp) }
    var transitionZCounter by remember { mutableFloatStateOf(1f) }

    val exportLogFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val currentFiltered = filterLogLines(logs, config.logLevel, logFilterLevel)
                val content = if (currentFiltered.isEmpty()) {
                    "暂无日志记录\n"
                } else {
                    currentFiltered.joinToString("\n") + "\n"
                }
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "日志文件已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "导出日志失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler(enabled = showAppFilterSheet || showLogTopMenu || selectedAppForConfig != null || showLogPage) {
        when {
            showAppFilterSheet -> showAppFilterSheet = false
            showLogTopMenu -> showLogTopMenu = false
            selectedAppForConfig != null -> selectedAppForConfig = null
            showLogPage -> showLogPage = false
        }
    }

    val currentRoute: ScreenRoute = remember(selectedTab, selectedAppForConfig, showLogPage) {
        val activeApp = selectedAppForConfig
        when {
            activeApp != null -> ScreenRoute.AppDetail(activeApp.first, activeApp.second)
            showLogPage -> ScreenRoute.Logs
            else -> ScreenRoute.MainTab(selectedTab)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(surfaceBg)
    ) {
        // 全部页面（包含各自顶栏）统一采用从右往左水平覆盖过渡动画，每个页面拥有独立 Scaffold 与固定垂直内边距，彻底杜绝右下到左上的斜向位移
        AnimatedContent(
            targetState = currentRoute,
            transitionSpec = {
                transitionZCounter += 1f
                (slideInHorizontally(
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                    initialOffsetX = { fullWidth -> fullWidth }
                ) togetherWith slideOutHorizontally(
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                    targetOffsetX = { fullWidth -> -fullWidth / 4 }
                )).apply {
                    targetContentZIndex = transitionZCounter
                } using SizeTransform(clip = false)
            },
            label = "FullScreenRightToLeftCover"
        ) { route ->
            val pageScrollBehavior = remember { MiuixScrollBehavior() }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(surfaceBg)
            ) {
                when (route) {
                    is ScreenRoute.AppDetail -> {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = route.appName,
                                    scrollBehavior = pageScrollBehavior,
                                    color = Color.Transparent,
                                    navigationIcon = {
                                        IconButton(onClick = { selectedAppForConfig = null }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { innerPadding ->
                            val topBarHeight = innerPadding.calculateTopPadding()
                            val bottomBarHeight = innerPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                AppConfigDialog(
                                    packageName = route.packageName,
                                    appName = route.appName,
                                    config = config,
                                    viewModel = viewModel,
                                    scrollBehavior = pageScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    onDismiss = { selectedAppForConfig = null }
                                )
                            }
                        }
                    }

                    is ScreenRoute.Logs -> {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = "日志",
                                    scrollBehavior = pageScrollBehavior,
                                    color = Color.Transparent,
                                    navigationIcon = {
                                        IconButton(onClick = {
                                            showLogTopMenu = false
                                            showLogPage = false
                                        }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    },
                                    actions = {
                                        TopMenuActionButton(
                                            active = showLogTopMenu,
                                            isDark = isDark,
                                            contentDescription = "日志选项",
                                            onClick = { showLogTopMenu = !showLogTopMenu }
                                        )
                                    }
                                )
                            }
                        ) { innerPadding ->
                            val topBarHeight = innerPadding.calculateTopPadding()
                            if (topBarHeight > 0.dp) {
                                logPageTopBarHeight = topBarHeight
                            }
                            val bottomBarHeight = innerPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                LogPage(
                                    viewModel = viewModel,
                                    config = config,
                                    listState = logListState,
                                    scrollBehavior = pageScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    filterLevel = logFilterLevel,
                                    onFilterLevelChange = { logFilterLevel = it }
                                )
                            }
                        }
                    }

                    is ScreenRoute.MainTab -> {
                        val tab = route.tabIndex
                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = tabTitles[tab],
                                    scrollBehavior = pageScrollBehavior,
                                    color = Color.Transparent,
                                    actions = {
                                        when (tab) {
                                            1 -> {
                                                TopMenuActionButton(
                                                    active = showAppFilterSheet,
                                                    isDark = isDark,
                                                    contentDescription = "筛选",
                                                    onClick = { showAppFilterSheet = !showAppFilterSheet }
                                                )
                                            }
                                            2 -> {
                                                IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                                    Icon(
                                                        imageVector = IconRefresh,
                                                        contentDescription = "刷新",
                                                        tint = MiuixTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }
                                    }
                                )
                            },
                            bottomBar = {
                                NavigationBar {
                                    NavigationBarItem(
                                        selected = selectedTab == 0,
                                        onClick = {
                                            showAppFilterSheet = false
                                            selectedTab = 0
                                        },
                                        icon = IconHome,
                                        label = "主页"
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 1,
                                        onClick = { selectedTab = 1 },
                                        icon = IconAppList,
                                        label = "应用列表"
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 2,
                                        onClick = {
                                            showAppFilterSheet = false
                                            selectedTab = 2
                                            viewModel.refreshRunningApps(includeSystemApps)
                                        },
                                        icon = IconRunningCheck,
                                        label = "运行列表"
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 3,
                                        onClick = {
                                            showAppFilterSheet = false
                                            selectedTab = 3
                                        },
                                        icon = IconHexSettings,
                                        label = "设置"
                                    )
                                }
                            }
                        ) { innerPadding ->
                            val topBarHeight = innerPadding.calculateTopPadding()
                            if (tab == 1 && topBarHeight > 0.dp) {
                                appListTopBarHeight = topBarHeight
                            }
                            val bottomBarHeight = innerPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarFrostedBlur(
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark
                                    )
                            ) {
                                when (tab) {
                                    0 -> HomePage(
                                        viewModel = viewModel,
                                        config = config,
                                        isSystemActive = isSystemActive,
                                        isPowerKeeperActive = isPkActive,
                                        scrollBehavior = pageScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onNavigateToWhitelist = {
                                            appFilterIndex = 2
                                            selectedTab = 1
                                        },
                                        onNavigateToBlacklist = {
                                            appFilterIndex = 3
                                            selectedTab = 1
                                        },
                                        onNavigateToRunning = { selectedTab = 2 },
                                        onNavigateToLogs = {
                                            showLogTopMenu = false
                                            showLogPage = true
                                        }
                                    )
                                    1 -> AppListPage(
                                        viewModel = viewModel,
                                        config = config,
                                        scrollBehavior = pageScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        includeSystemApps = includeSystemApps,
                                        filterIndex = appFilterIndex,
                                        onFilterIndexChange = { appFilterIndex = it },
                                        onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name }
                                    )
                                    2 -> RunningListPage(
                                        viewModel = viewModel,
                                        scrollBehavior = pageScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                                        onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                                    )
                                    3 -> SettingsPage(
                                        viewModel = viewModel,
                                        config = config,
                                        scrollBehavior = pageScrollBehavior,
                                        contentPadding = pageContentPadding
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        diagnosticPair?.let { (pkg, reason) ->
            OverlayDialog(
                show = true,
                title = "诊断冻结状态",
                summary = pkg,
                onDismissRequest = { viewModel.dismissDiagnosticDialog() }
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = reason)
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(
                        text = "我知道了",
                        onClick = { viewModel.dismissDiagnosticDialog() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }

        // 应用列表右上角弹出菜单（置于根 Box 最顶层，压暗遮罩对顶栏标题同样生效）
        val safeFilterIndex = appFilterIndex.coerceIn(0, APP_FILTER_OPTIONS.lastIndex)
        MiuixTopPopupMenu(
            visible = showAppFilterSheet && currentRoute == ScreenRoute.MainTab(1),
            onDismiss = { showAppFilterSheet = false },
            topOffset = appListTopBarHeight + 6.dp,
            width = 240.dp
        ) {
            APP_FILTER_OPTIONS.forEachIndexed { idx, label ->
                MiuixPopupOptionRow(
                    text = label,
                    selected = idx == safeFilterIndex,
                    onClick = {
                        appFilterIndex = idx
                        showAppFilterSheet = false
                    }
                )
            }

            MiuixPopupOptionRow(
                text = "显示系统应用",
                selected = includeSystemApps,
                onClick = {
                    includeSystemApps = !includeSystemApps
                    showAppFilterSheet = false
                }
            )
        }

        // 日志页右上角弹出菜单（已移除清空日志功能）
        MiuixTopPopupMenu(
            visible = showLogTopMenu && currentRoute is ScreenRoute.Logs,
            onDismiss = { showLogTopMenu = false },
            topOffset = logPageTopBarHeight + 6.dp,
            width = 228.dp
        ) {
            LogFilterLevel.entries.forEach { level ->
                MiuixPopupOptionRow(
                    text = level.label,
                    selected = level == logFilterLevel,
                    onClick = {
                        logFilterLevel = level
                        showLogTopMenu = false
                    }
                )
            }

            val currentFilteredLogs = filterLogLines(logs, config.logLevel, logFilterLevel)
            val displayedLogCount = currentFilteredLogs.size.coerceAtMost(MAX_DISPLAY_LOG_COUNT)

            MiuixPopupActionRow(
                text = "滚动到顶部",
                onClick = {
                    showLogTopMenu = false
                    if (displayedLogCount > 0) {
                        scope.launch { logListState.animateScrollToItem(0) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "滚动到底部",
                onClick = {
                    showLogTopMenu = false
                    if (displayedLogCount > 0) {
                        scope.launch { logListState.animateScrollToItem(displayedLogCount) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "导出日志文件",
                onClick = {
                    showLogTopMenu = false
                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    exportLogFileLauncher.launch("Smillet-Next_log_$ts.txt")
                }
            )
        }
    }
}

/**
 * 1:1 还原参考图片 (1000110482_63e8b6.jpg) 的顶栏背景毛玻璃模糊（无下方边缘模糊溢出，绝不遮挡正文文字）：
 * - 严格在 0 <= y < topBarHeight 内执行 6-Pass (H1->V1->H2->V2->H3->V3) 连续高斯模糊，
 * - y >= topBarHeight 的正文区域 100% 保持原样锐利显示。
 */
@Composable
private fun Modifier.topBarFrostedBlur(
    topBarHeight: Dp,
    surfaceColor: Color,
    isDark: Boolean
): Modifier {
    val shaders = remember {
        runCatching {
            arrayOf(
                RuntimeShader(TOP_BAR_BLUR_H_AGSL),
                RuntimeShader(TOP_BAR_BLUR_V_TINT_AGSL),
                RuntimeShader(TOP_BAR_BLUR_H_AGSL),
                RuntimeShader(TOP_BAR_BLUR_V_TINT_AGSL),
                RuntimeShader(TOP_BAR_BLUR_H_AGSL),
                RuntimeShader(TOP_BAR_BLUR_V_TINT_AGSL)
            )
        }.getOrNull()
    }
    if (shaders == null) return this

    return this.graphicsLayer {
        val topPx = topBarHeight.toPx()
        if (topPx > 0f) {
            compositingStrategy = CompositingStrategy.Offscreen

            val sH1 = shaders[0]
            val sV1 = shaders[1]
            val sH2 = shaders[2]
            val sV2 = shaders[3]
            val sH3 = shaders[4]
            val sV3 = shaders[5]

            // 第 1、2 趟 (细粒度 1.8px 步长)：消除一切高频文字笔画与网格伪影
            val step1 = 1.8f
            sH1.setFloatUniform("topBarBottom", topPx)
            sH1.setFloatUniform("stepSize", step1)
            sV1.setFloatUniform("topBarBottom", topPx)
            sV1.setFloatUniform("stepSize", step1)
            sV1.setFloatUniform("surfaceTint", 0f, 0f, 0f, 0f)

            // 第 3、4 趟 (中粒度 7.5px 步长)：平滑融化图标与卡片边缘
            val step2 = 7.5f
            sH2.setFloatUniform("topBarBottom", topPx)
            sH2.setFloatUniform("stepSize", step2)
            sV2.setFloatUniform("topBarBottom", topPx)
            sV2.setFloatUniform("stepSize", step2)
            sV2.setFloatUniform("surfaceTint", 0f, 0f, 0f, 0f)

            // 第 5、6 趟 (大半径 20.0px 步长)：形成参考图 (1000110482_63e8b6.jpg) 中超大范围柔光色晕与毛玻璃质感
            val step3 = 20.0f
            sH3.setFloatUniform("topBarBottom", topPx)
            sH3.setFloatUniform("stepSize", step3)

            val tintAlpha = if (isDark) 0.75f else 0.72f
            sV3.setFloatUniform("topBarBottom", topPx)
            sV3.setFloatUniform("stepSize", step3)
            sV3.setFloatUniform(
                "surfaceTint",
                surfaceColor.red,
                surfaceColor.green,
                surfaceColor.blue,
                tintAlpha
            )

            val p1 = AndroidRenderEffect.createRuntimeShaderEffect(sH1, "content")
            val p2 = AndroidRenderEffect.createRuntimeShaderEffect(sV1, "content")
            val p3 = AndroidRenderEffect.createRuntimeShaderEffect(sH2, "content")
            val p4 = AndroidRenderEffect.createRuntimeShaderEffect(sV2, "content")
            val p5 = AndroidRenderEffect.createRuntimeShaderEffect(sH3, "content")
            val p6 = AndroidRenderEffect.createRuntimeShaderEffect(sV3, "content")

            val c12 = AndroidRenderEffect.createChainEffect(p2, p1)
            val c123 = AndroidRenderEffect.createChainEffect(p3, c12)
            val c1234 = AndroidRenderEffect.createChainEffect(p4, c123)
            val c12345 = AndroidRenderEffect.createChainEffect(p5, c1234)
            val c123456 = AndroidRenderEffect.createChainEffect(p6, c12345)

            renderEffect = c123456.asComposeRenderEffect()
        }
    }
}

@Composable
private fun TopMenuActionButton(
    active: Boolean,
    isDark: Boolean,
    contentDescription: String,
    onClick: () -> Unit
) {
    val activeCircleColor = if (isDark) {
        Color.White.copy(alpha = 0.14f)
    } else {
        Color.Black.copy(alpha = 0.08f)
    }

    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) activeCircleColor else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = IconMoreCircle,
                contentDescription = contentDescription,
                tint = MiuixTheme.colorScheme.onSurface
            )
        }
    }
}
