package com.sidesand.millet.hook.system

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Binder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.sidesand.millet.hook.SMilletLogger
import com.sidesand.millet.hook.XposedCompat
import java.io.PrintWriter
import java.io.StringWriter

object DozeControllerHelper {

    @Volatile
    var deviceIdleController: Any? = null

    @Volatile
    var deviceIdleBinder: Any? = null

    @Volatile
    private var lastAppliedWhiteSet: Set<String>? = null

    @Volatile
    private var lastAppliedBlackSet: Set<String>? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isForcedIdle = false
    private var screenOffTimestamp = 0L
    private var screenOffBatteryPct = 0
    private var screenOffBatteryCounter = 0

    private val deepDozeAlarmListener = AlarmManager.OnAlarmListener {
        if (SMilletLogger.config.enableDoze) {
            forceDeepDoze()
        }
    }

    fun onDeviceIdleStart(controller: Any) {
        deviceIdleController = controller
        applyBatteryOptimizationSets(force = true)
    }

    fun resolveDeviceIdleController(): Any? {
        deviceIdleController?.let { return it }
        return runCatching {
            val smClass = Class.forName("android.os.ServiceManager")
            val binder = XposedCompat.callStaticMethod(smClass, "getService", "deviceidle")
            if (binder != null) {
                deviceIdleBinder = binder
                val outer = runCatching { XposedCompat.getObjectField(binder, "this$0") }.getOrNull()
                if (outer != null) {
                    deviceIdleController = outer
                    SystemServerHook.hookDeviceIdleControllerClass(outer.javaClass)
                    outer
                } else {
                    null
                }
            } else {
                null
            }
        }.getOrNull()
    }

    private fun resolveDeviceIdleBinder(): Any? {
        deviceIdleBinder?.let { return it }
        return runCatching {
            val smClass = Class.forName("android.os.ServiceManager")
            XposedCompat.callStaticMethod(smClass, "getService", "deviceidle")?.also {
                deviceIdleBinder = it
            }
        }.getOrNull()
    }

    private fun executeDeviceIdleShell(controller: Any, args: Array<String>): String? {
        return runCatching {
            val cl = controller.javaClass.classLoader
            val shellClass = XposedCompat.findClassIfExists(
                "com.android.server.DeviceIdleController\$Shell",
                cl
            ) ?: return null
            val shellObj = XposedCompat.newInstance(shellClass)
            val sw = StringWriter()
            val pw = PrintWriter(sw)
            XposedCompat.setObjectField(shellObj, "mOutPrintWriter", pw)
            XposedCompat.setObjectField(shellObj, "mArgs", args)
            XposedCompat.setObjectField(shellObj, "mArgPos", 1)
            XposedCompat.callMethod(controller, "onShellCommand", shellObj, args[0])
            pw.flush()
            sw.toString().trim()
        }.getOrNull()
    }

    fun registerScreenReceiver(context: Context) {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val alarmManager = ctx.getSystemService(AlarmManager::class.java)
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        if (SMilletLogger.config.enableDoze && alarmManager != null) {
                            val triggerAt = SystemClock.elapsedRealtime() + 180_000L
                            alarmManager.setExact(
                                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                                triggerAt,
                                "SMillet.Screen",
                                deepDozeAlarmListener,
                                handler
                            )
                            SMilletLogger.debug("[Doze] 屏幕关闭，已设定 3 分钟后触发深度 Doze")
                        }
                        if (SMilletLogger.config.batteryChangeObserve) {
                            recordBatteryOnScreenOff(ctx)
                        }
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        alarmManager?.cancel(deepDozeAlarmListener)
                        if (isForcedIdle) {
                            unforceDeepDoze()
                        }
                        if (SMilletLogger.config.batteryChangeObserve) {
                            logBatteryDrainOnScreenOn(ctx)
                        }
                    }
                }
            }
        }
        context.registerReceiver(receiver, filter)
        SMilletLogger.info("已注册屏幕状态广播监听 (Screen ON/OFF)")
    }

    private fun forceDeepDoze() {
        val controller = resolveDeviceIdleController() ?: return
        runCatching {
            executeDeviceIdleShell(controller, arrayOf("enable", "deep"))
            executeDeviceIdleShell(controller, arrayOf("force-idle", "deep"))
            runCatching { XposedCompat.callMethod(controller, "becomeInactiveIfAppropriateLocked") }
            runCatching { XposedCompat.callMethod(controller, "stepIdleStateLocked", "s:shell") }
            isForcedIdle = true
            SMilletLogger.info("[Doze] 已在息屏后强制进入深度 Doze (IDLE)")
        }.onFailure {
            SMilletLogger.error("[Doze] 触发深度 Doze 失败", it)
        }
    }

    private fun unforceDeepDoze() {
        val controller = resolveDeviceIdleController() ?: return
        runCatching {
            executeDeviceIdleShell(controller, arrayOf("unforce"))
            runCatching { XposedCompat.callMethod(controller, "exitForceIdleLocked") }
            isForcedIdle = false
            SMilletLogger.info("[Doze] 屏幕点亮，已退出强制深度 Doze")
        }
    }

    fun applyBatteryOptimizationSets(force: Boolean = false) {
        val cfg = SMilletLogger.config
        if (cfg.batteryOptWhiteSet.isEmpty() && cfg.batteryOptBlackSet.isEmpty()) {
            return
        }
        val whiteChanged = force || cfg.batteryOptWhiteSet != lastAppliedWhiteSet
        val blackChanged = force || cfg.batteryOptBlackSet != lastAppliedBlackSet
        if (!whiteChanged && !blackChanged) {
            return
        }

        val token = Binder.clearCallingIdentity()
        try {
            val controller = resolveDeviceIdleController()
            val binder = resolveDeviceIdleBinder()
            if (controller == null && binder == null) {
                return
            }

            if (whiteChanged && cfg.batteryOptWhiteSet.isNotEmpty()) {
                if (controller != null) {
                    runCatching {
                        XposedCompat.callMethod(
                            controller,
                            "addPowerSaveWhitelistAppsInternal",
                            ArrayList(cfg.batteryOptWhiteSet)
                        )
                    }
                }
                for (pkg in cfg.batteryOptWhiteSet) {
                    if (controller != null) {
                        runCatching { XposedCompat.callMethod(controller, "addPowerSaveWhitelistAppInternal", pkg) }
                        runCatching { executeDeviceIdleShell(controller, arrayOf("whitelist", "+$pkg")) }
                    }
                    if (binder != null) {
                        runCatching { XposedCompat.callMethod(binder, "addPowerSaveWhitelistApp", pkg) }
                    }
                }
                lastAppliedWhiteSet = HashSet(cfg.batteryOptWhiteSet)
                SMilletLogger.info("已同步电池未优化白名单：${cfg.batteryOptWhiteSet.joinToString(", ")}")
            } else if (whiteChanged) {
                lastAppliedWhiteSet = emptySet()
            }

            if (blackChanged && cfg.batteryOptBlackSet.isNotEmpty()) {
                for (pkg in cfg.batteryOptBlackSet) {
                    if (controller != null) {
                        runCatching { XposedCompat.callMethod(controller, "removePowerSaveWhitelistAppInternal", pkg) }
                        runCatching { XposedCompat.callMethod(controller, "removeSystemPowerWhitelistAppInternal", pkg) }
                        runCatching { executeDeviceIdleShell(controller, arrayOf("whitelist", "-$pkg")) }
                        runCatching { executeDeviceIdleShell(controller, arrayOf("sys-whitelist", "-$pkg")) }
                        runCatching { executeDeviceIdleShell(controller, arrayOf("except-idle-whitelist", "-$pkg")) }
                        runCatching {
                            synchronized(controller) {
                                var removed = false
                                listOf(
                                    "mPowerSaveWhitelistUserApps",
                                    "mPowerSaveWhitelistApps",
                                    "mPowerSaveWhitelistAppsExceptIdle"
                                ).forEach { fieldName ->
                                    val map = runCatching {
                                        XposedCompat.getObjectField(controller, fieldName) as? MutableMap<*, *>
                                    }.getOrNull()
                                    if (map != null && map.remove(pkg) != null) {
                                        removed = true
                                    }
                                }
                                if (removed) {
                                    runCatching { XposedCompat.callMethod(controller, "updateWhitelistAppIdsLocked") }
                                    runCatching { XposedCompat.callMethod(controller, "writeConfigFileLocked") }
                                }
                            }
                        }
                    }
                    if (binder != null) {
                        runCatching { XposedCompat.callMethod(binder, "removePowerSaveWhitelistApp", pkg) }
                        runCatching { XposedCompat.callMethod(binder, "removeSystemPowerWhitelistApp", pkg) }
                    }
                }
                lastAppliedBlackSet = HashSet(cfg.batteryOptBlackSet)
                SMilletLogger.info("已恢复电池省电优化管控：${cfg.batteryOptBlackSet.joinToString(", ")}")
            } else if (blackChanged) {
                lastAppliedBlackSet = emptySet()
            }
        } catch (t: Throwable) {
            SMilletLogger.error("同步电池优化白名单失败", t)
        } finally {
            Binder.restoreCallingIdentity(token)
        }
    }

    private fun formatDurationSec(totalSec: Long): String {
        return when {
            totalSec < 60L -> "${totalSec}秒"
            totalSec < 3600L -> "${totalSec / 60L}分${totalSec % 60L}秒"
            else -> "${totalSec / 3600L}小时${(totalSec % 3600L) / 60L}分钟"
        }
    }

    private fun recordBatteryOnScreenOff(context: Context) {
        val bm = context.getSystemService(BatteryManager::class.java) ?: return
        screenOffTimestamp = System.currentTimeMillis()
        screenOffBatteryPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        screenOffBatteryCounter = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000
        SMilletLogger.info(
            "息屏电量记录：当前电量 ${screenOffBatteryPct}% (${screenOffBatteryCounter} mAh)"
        )
    }

    private fun logBatteryDrainOnScreenOn(context: Context) {
        if (screenOffTimestamp <= 0L) return
        val bm = context.getSystemService(BatteryManager::class.java) ?: return
        val durationSec = ((System.currentTimeMillis() - screenOffTimestamp) / 1000L).coerceAtLeast(0L)
        val currentPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val currentMah = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000
        val diffPct = screenOffBatteryPct - currentPct
        val diffMah = screenOffBatteryCounter - currentMah
        val durationStr = formatDurationSec(durationSec)
        val actionSummary = if (diffPct >= 0) {
            "消耗 ${screenOffBatteryPct}% -> ${currentPct}% (-${diffPct}% / -${diffMah} mAh)"
        } else {
            "充电 ${screenOffBatteryPct}% -> ${currentPct}% (+${-diffPct}% / +${-diffMah} mAh)"
        }
        SMilletLogger.info(
            "亮屏待机统计：当前电量 ${currentPct}% · $actionSummary · 待机时长 $durationStr"
        )
    }
}
