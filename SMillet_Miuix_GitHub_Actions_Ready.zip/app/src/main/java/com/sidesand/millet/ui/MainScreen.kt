package com.sidesand.millet.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.icons.useful.Info
import top.yukonga.miuix.kmp.icon.icons.useful.Refresh
import top.yukonga.miuix.kmp.icon.icons.useful.Settings
import top.yukonga.miuix.kmp.overlay.OverlayDialog

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }

    val config by viewModel.config.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val tabTitles = listOf("运行列表", "应用配置", "模块设置")

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = "SMillet Miuix · ${tabTitles[selectedTab]}"
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = MiuixIcons.Useful.Refresh,
                    label = "运行列表"
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = MiuixIcons.Useful.Info,
                    label = "应用配置"
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = MiuixIcons.Useful.Settings,
                    label = "模块设置"
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> RunningListPage(
                    viewModel = viewModel,
                    isSystemActive = isSystemActive,
                    isPowerKeeperActive = isPkActive,
                    onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                    onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                )
                1 -> AppListPage(
                    viewModel = viewModel,
                    config = config,
                    onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name }
                )
                2 -> SettingsPage(
                    viewModel = viewModel,
                    config = config,
                    isSystemActive = isSystemActive,
                    isPowerKeeperActive = isPkActive
                )
            }
        }
    }

    // 单应用墓碑策略配置弹窗 (Miuix OverlayDialog)
    selectedAppForConfig?.let { (pkg, appName) ->
        AppConfigDialog(
            packageName = pkg,
            appName = appName,
            config = config,
            viewModel = viewModel,
            onDismiss = { selectedAppForConfig = null }
        )
    }

    // PowerKeeper 未冻结原因诊断结果弹窗
    diagnosticPair?.let { (pkg, reason) ->
        OverlayDialog(
            show = true,
            title = "未冻结原因诊断",
            summary = pkg,
            onDismissRequest = { viewModel.dismissDiagnosticDialog() }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(text = reason)
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(
                    text = "我知道了",
                    onClick = { viewModel.dismissDiagnosticDialog() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary()
                )
            }
        }
    }
}
