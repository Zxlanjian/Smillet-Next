package com.sidesand.millet.hook.system

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.util.ArraySet
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

/**
 * 完整还原原模块针对 `android` (system_server) 作用域的全部 21 个 Hook 点：
 * 1. ActivityManagerService#registerReceiverWithFeature -> 注入 SMillet-Binder IPC 服务
 * 2. GreezeManagerService 构造与实例捕获 + 屏幕状态广播注册
 * 3. AurogonImmobulusMode 构造与 mMessageApp 消息应用同步
 * 4. GreezeManagerService#freezeAction -> 墓碑白名单 & 前台服务(FGS)不冻结拦截
 * 5. AurogonImmobulusMode#checkAppStatusForFreeze -> 墓碑白名单拦截
 * 6. GreezeManagerService#thawUid -> 禁止同步 Binder 解冻 & 强力压制拦截
 * 7. GreezeManagerService#freezeUids / freezeProcess / thawProcess -> 冻结与解冻日志记录
 * 8. AnrHelper & ProcessErrorStateRecord#appNotResponding -> 冻结状态下静默抑制 ANR 弹窗
 * 9. BroadcastQueue / BroadcastSkipPolicy -> 跳过向已冻结非白名单进程分发动态广播
 * 10. DeviceIdleController#onStart / motionLocked / moveToStateLocked -> 深度 Doze 增强
 */
object SystemServerHook {

    @Volatile
    var greezeManagerService: Any? = null
        private set

    @Volatile
    var aurogonImmobulusMode: Any? = null
        private set

    @Volatile
    var amsInstance: Any? = null
        private set

    @Volatile
    private var lastToFrontPkg: String? = null

    fun init(classLoader: ClassLoader) {
        reloadConfig("ALL")

        hookAmsBinderBridge(classLoader)
        hookGreezeManagerService(classLoader)
        hookAurogonImmobulusMode(classLoader)
        hookAnrSuppression(classLoader)
        hookBroadcastSkipForFrozenApp(classLoader)
        hookDeviceIdleController(classLoader)

        SMilletLogger.info("system_server 全部 Hook 初始化完成 (SDK=${Build.VERSION.SDK_INT})")
    }

    fun reloadConfig(changedKey: String) {
        val snapshot = PrefsManager.loadFromXposed()
        SMilletLogger.config = snapshot
        if (changedKey == "ALL" || changedKey == ConfigKeys.MESSAGE_APP_SET) {
            syncMessageAppsToAurogon()
        }
        if (changedKey == "ALL" ||
            changedKey == ConfigKeys.BATTERY_OPT_WHITE_SET ||
            changedKey == ConfigKeys.BATTERY_OPT_BLACK_SET
        ) {
            DozeControllerHelper.applyBatteryOptimizationSets()
        }
    }

    /**
     * Hook 1: ActivityManagerService#registerReceiverWithFeature & setSystemProcess
     * 拦截 Action == "SMillet-Binder" 的广播注册，直接返回包含 SystemServerService IBinder 的 Intent。
     */
    private fun hookAmsBinderBridge(classLoader: ClassLoader) {
        val amsClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.ActivityManagerService",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(amsClass, "setSystemProcess", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                amsInstance = param.thisObject
            }
        })

        XposedBridge.hookAllMethods(amsClass, "registerReceiverWithFeature", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val filter = param.args.firstOrNull { it is IntentFilter } as? IntentFilter ?: return
                if (filter.hasAction(ConfigKeys.BINDER_ACTION)) {
                    val replyIntent = Intent()
                    val bundle = Bundle()
                    bundle.putBinder(ConfigKeys.BINDER_KEY_SYSTEM, SystemServerService)
                    replyIntent.putExtras(bundle)
                    param.result = replyIntent
                }
            }
        })
    }

    /**
     * Hook 2: GreezeManagerService 核心冻结与解冻控制
     */
    private fun hookGreezeManagerService(classLoader: ClassLoader) {
        val gmsClass = XposedHelpers.findClassIfExists(
            "com.miui.server.greeze.GreezeManagerService",
            classLoader
        ) ?: return

        // 捕获 GreezeManagerService 实例并注册亮屏/息屏监听
        XposedBridge.hookAllConstructors(gmsClass, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (greezeManagerService == null) {
                    greezeManagerService = param.thisObject
                }
                val ctx = param.args.firstOrNull { it is Context } as? Context
                if (ctx != null) {
                    runCatching { DozeControllerHelper.registerScreenReceiver(ctx) }
                }
            }
        })

        // Hook freezeAction(int uid, int fromWho, String reason, boolean isCheck) -> 墓碑白名单 & 前台服务不冻结
        XposedBridge.hookAllMethods(gmsClass, "freezeAction", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: ""
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                // 1) 白名单永不冻结
                if (cfg.whiteAppSet.contains(pkg)) {
                    SMilletLogger.debug("freezeAction 拦截: 白名单应用 [$pkg] 不冻结")
                    param.result = false
                    return
                }

                // 2) 具有前台服务 (FGS) 时不冻结 (排除 LAUNCH_MODE 瞬时状态)
                if (reason != "LAUNCH_MODE" && cfg.notFreezeWhenHasFgsSet.contains(pkg)) {
                    val hasFgs = checkAppHasForegroundService(uid)
                    if (hasFgs) {
                        SMilletLogger.debug("freezeAction 拦截: [$pkg] 具有前台服务，跳过冻结")
                        param.result = false
                    }
                }
            }
        })

        // Hook thawUid(int uid, int fromWho, String reason) -> 禁止同步 Binder 解冻 & 强力压制
        XposedBridge.hookAllMethods(gmsClass, "thawUid", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val uid = param.args.getOrNull(0) as? Int ?: return
                val reason = param.args.getOrNull(2) as? String ?: return
                val pkg = getPackageNameForUid(uid) ?: return
                val cfg = SMilletLogger.config

                if (reason == "tofront") {
                    lastToFrontPkg = pkg
                    return
                }
                if (reason == "screen on" && pkg == lastToFrontPkg) {
                    return
                }

                // 1) 拦截已冻结应用的广播解冻
                if (isUidFrozen(uid) && (reason == "broadcast" || reason == "Broadcast") && !cfg.whiteAppSet.contains(pkg)) {
                    param.result = false
                    return
                }

                // 2) 禁止同步 Binder / Check Binder 解冻
                if ((reason == "Sync Binder" || reason == "Check Binder") && cfg.forbidSyncBinderSet.contains(pkg)) {
                    SMilletLogger.info("--系统[解冻uid]: 禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                    return
                }

                // 3) 强力压制 (blockThawSet): 拦截不在白名单内的解冻原因
                if (cfg.blockThawSet.contains(pkg) && !ConfigKeys.ALLOWED_THAW_REASONS.contains(reason)) {
                    SMilletLogger.info("--系统[解冻uid]: 强力压制，禁止 [$reason] 解冻 [$pkg] (uid:$uid)")
                    param.result = false
                }
            }
        })

        // Hook freezeUids 日志输出
        XposedBridge.hookAllMethods(gmsClass, "freezeUids", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                if (!SMilletLogger.config.isLog && !SMilletLogger.config.simplifyLog) return
                val uids = param.args.getOrNull(0) as? IntArray ?: return
                val reason = param.args.getOrNull(3) as? String ?: ""
                if (uids.isEmpty()) return
                val names = uids.joinToString(",") { uid -> "${getPackageNameForUid(uid) ?: uid}@$uid" }
                SMilletLogger.info("++系统[冻结Uids]: 原因=[$reason], 列表=[$names]")
            }
        })
    }

    /**
     * Hook 3: AurogonImmobulusMode (捕获实例、同步消息应用、拦截白名单冻结检查)
     */
    private fun hookAurogonImmobulusMode(classLoader: ClassLoader) {
        val aurogonClass = XposedHelpers.findClassIfExists(
            "com.miui.server.greeze.AurogonImmobulusMode",
            classLoader
        ) ?: return

        XposedBridge.hookAllConstructors(aurogonClass, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (aurogonImmobulusMode == null) {
                    aurogonImmobulusMode = param.thisObject
                }
                syncMessageAppsToAurogon()
            }
        })

        XposedBridge.hookAllMethods(aurogonClass, "checkAppStatusForFreeze", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val appInfo = param.args.getOrNull(0) ?: return
                val pkg = runCatching {
                    XposedHelpers.getObjectField(appInfo, "mPackageName") as? String
                }.getOrNull() ?: return
                if (SMilletLogger.config.whiteAppSet.contains(pkg)) {
                    param.result = false
                }
            }
        })
    }

    /**
     * 还原原模块 ʐ.ތ(): 将 messageAppSet 同步到 AurogonImmobulusMode.mMessageApp
     */
    @Suppress("UNCHECKED_CAST")
    private fun syncMessageAppsToAurogon() {
        val instance = aurogonImmobulusMode ?: return
        val msgApps = SMilletLogger.config.messageAppSet
        runCatching {
            val fieldObj = XposedHelpers.getObjectField(instance, "mMessageApp")
            when (fieldObj) {
                is MutableList<*> -> {
                    val list = fieldObj as MutableList<String>
                    list.clear()
                    list.addAll(msgApps)
                }
                is ArraySet<*> -> {
                    val set = fieldObj as ArraySet<String>
                    set.clear()
                    set.addAll(msgApps)
                }
                else -> {
                    XposedHelpers.setObjectField(instance, "mMessageApp", ArrayList(msgApps))
                }
            }
            SMilletLogger.debug("已同步消息应用列表至 AurogonImmobulusMode: $msgApps")
        }.onFailure {
            SMilletLogger.error("同步消息应用列表失败", it)
        }
    }

    /**
     * Hook 4: 抑制已冻结应用的 ANR 报错 (对应原模块 ࢿ 与 ߊ(7))
     */
    private fun hookAnrSuppression(classLoader: ClassLoader) {
        val anrHelperClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.AnrHelper",
            classLoader
        )
        if (anrHelperClass != null) {
            val anrHook = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val processRecord = param.args.getOrNull(0) ?: return
                    val uid = runCatching { XposedHelpers.getIntField(processRecord, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        SMilletLogger.debug("已拦截冻结进程的 ANR: uid=$uid")
                        param.result = null
                    }
                }
            }
            XposedBridge.hookAllMethods(anrHelperClass, "appNotResponding", anrHook)
            XposedBridge.hookAllMethods(anrHelperClass, "deferAppNotResponding", anrHook)
        }

        val errStateClass = XposedHelpers.findClassIfExists(
            "com.android.server.am.ProcessErrorStateRecord",
            classLoader
        )
        if (errStateClass != null) {
            XposedBridge.hookAllMethods(errStateClass, "appNotResponding", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val app = runCatching { XposedHelpers.getObjectField(param.thisObject, "mApp") }.getOrNull() ?: return
                    val uid = runCatching { XposedHelpers.getIntField(app, "uid") }.getOrNull() ?: return
                    if (isUidFrozen(uid)) {
                        SMilletLogger.debug("已拦截 ProcessErrorStateRecord 冻结进程 ANR: uid=$uid")
                        param.result = null
                    }
                }
            })
        }
    }

    /**
     * Hook 5: 跳过向已冻结非白名单进程分发广播 (兼容 Android 13 BroadcastQueue 与 Android 14+ BroadcastSkipPolicy)
     */
    private fun hookBroadcastSkipForFrozenApp(classLoader: ClassLoader) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU) {
            val bqClass = XposedHelpers.findClassIfExists(
                "com.android.server.am.BroadcastQueue",
                classLoader
            ) ?: return
            XposedBridge.hookAllMethods(bqClass, "deliverToRegisteredReceiverLocked", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedHelpers.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedHelpers.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = null
                    }
                }
            })
        } else {
            val skipPolicyClass = XposedHelpers.findClassIfExists(
                "com.android.server.am.BroadcastSkipPolicy",
                classLoader
            ) ?: return
            XposedBridge.hookAllMethods(skipPolicyClass, "shouldSkipMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val filter = param.args.getOrNull(1) ?: return
                    val receiverList = runCatching { XposedHelpers.getObjectField(filter, "receiverList") }.getOrNull() ?: return
                    val app = runCatching { XposedHelpers.getObjectField(receiverList, "app") }.getOrNull() ?: return
                    if (shouldSkipFrozenProcess(app)) {
                        param.result = "Skip frozen process by SMillet"
                    }
                }
            })
        }
    }

    private fun shouldSkipFrozenProcess(processRecord: Any): Boolean {
        val uid = runCatching { XposedHelpers.getIntField(processRecord, "uid") }.getOrNull() ?: return false
        if (uid < 10000) return false
        if (!isUidFrozen(uid)) return false
        val pkg = getPackageNameForUid(uid) ?: return false
        return !SMilletLogger.config.whiteAppSet.contains(pkg)
    }

    /**
     * Hook 6: DeviceIdleController (深度 Doze 控制、跳过状态检查、禁用运动唤醒)
     */
    private fun hookDeviceIdleController(classLoader: ClassLoader) {
        val dicClass = XposedHelpers.findClassIfExists(
            "com.android.server.DeviceIdleController",
            classLoader
        ) ?: return

        XposedBridge.hookAllMethods(dicClass, "onStart", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                DozeControllerHelper.onDeviceIdleStart(param.thisObject)
            }
        })

        // 禁用运动传感器唤醒 Doze
        XposedBridge.hookAllMethods(dicClass, "motionLocked", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                if (cfg.disableMotionListener) {
                    if (cfg.dozeLog) {
                        SMilletLogger.info("[Doze]: 监测到设备运动，已阻止唤醒 Doze")
                    }
                    param.result = null
                    runCatching { XposedHelpers.setBooleanField(param.thisObject, "mNotMoving", true) }
                }
            }
        })

        // 跳过 IDLE_PENDING / SENSING / LOCATING 直接进入 IDLE (state = 6 / 5)
        XposedBridge.hookAllMethods(dicClass, "moveToStateLocked", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cfg = SMilletLogger.config
                val targetState = param.args.getOrNull(0) as? Int ?: return
                if (cfg.enableDoze && cfg.skipStateCheck && targetState in 2..4) {
                    param.args[0] = 5 // STATE_IDLE
                    param.args[1] = "SMilletSkip"
                    runCatching { XposedHelpers.callMethod(param.thisObject, "resetIdleManagementLocked") }
                    if (cfg.dozeLog) {
                        SMilletLogger.info("[Doze]: 跳过中间检测状态 ($targetState)，直接进入深度 IDLE")
                    }
                }
            }
        })
    }

    fun isUidFrozen(uid: Int): Boolean {
        val gms = greezeManagerService ?: return false
        return runCatching {
            XposedHelpers.callMethod(gms, "isUidFrozen", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    private fun checkAppHasForegroundService(uid: Int): Boolean {
        val aurogon = aurogonImmobulusMode ?: return false
        return runCatching {
            XposedHelpers.callMethod(aurogon, "checkAppFgService", uid) as? Boolean ?: false
        }.getOrDefault(false)
    }

    private fun getSystemContext(): Context? {
        val ams = amsInstance ?: return null
        return runCatching {
            XposedHelpers.getObjectField(ams, "mContext") as? Context
        }.getOrNull()
    }

    private fun getPackageNameForUid(uid: Int): String? {
        val ctx = getSystemContext() ?: return null
        return runCatching {
            ctx.packageManager.getPackagesForUid(uid)?.firstOrNull()
        }.getOrNull()
    }
}
