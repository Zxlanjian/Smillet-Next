package com.sidesand.millet.ui.pages

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.SwitchPreference

/**
 * 还原原模块 AppConfigPage (Landroid/support/v4/ԃ;) 的单应用墓碑策略配置与互斥逻辑，
 * 移除原版 Beta/捐赠验证锁，全部 6 项核心策略 + 电池优化开关直接可用。
 */
@Composable
fun AppConfigDialog(
    packageName: String,
    appName: String,
    config: MilletConfigSnapshot,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val isWhite = config.whiteAppSet.contains(packageName)
    val isMessage = config.messageAppSet.contains(packageName)
    val isForceFreeze = config.forceFreezeSet.contains(packageName)
    val isBlockThaw = config.blockThawSet.contains(packageName)
    val isForbidSyncBinder = config.forbidSyncBinderSet.contains(packageName)
    val isNotFreezeFgs = config.notFreezeWhenHasFgsSet.contains(packageName)
    val isBatteryOptWhite = config.batteryOptWhiteSet.contains(packageName)

    OverlayDialog(
        show = true,
        title = appName,
        summary = packageName,
        onDismissRequest = onDismiss
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            SwitchPreference(
                title = "墓碑白名单 (永不冻结)",
                summary = "跳过 Millet 冻结并保持广播接收，开启后将自动关闭下方冻结增强项",
                checked = isWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.WHITE_APP_SET, packageName, enabled)
                    if (enabled) {
                        viewModel.updateAppSet(ConfigKeys.MESSAGE_APP_SET, packageName, false)
                        viewModel.updateAppSet(ConfigKeys.FORCE_FREEZE_SET, packageName, false)
                        viewModel.updateAppSet(ConfigKeys.BLOCK_THAW_SET, packageName, false)
                        viewModel.updateAppSet(ConfigKeys.FORBID_SYNC_BINDER_SET, packageName, false)
                        viewModel.updateAppSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, packageName, false)
                    }
                }
            )

            SwitchPreference(
                title = "设为消息应用 (AurogonImmobulus)",
                summary = "收到网络数据包时短暂解冻处理推送，完成后迅速重新冻结 (适合微信/QQ)",
                checked = isMessage,
                enabled = !isWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.MESSAGE_APP_SET, packageName, enabled)
                }
            )

            SwitchPreference(
                title = "强制冻结 (移出系统白名单)",
                summary = "从 MilletPolicy 内置白名单与预加载白名单移出，并加入 mUseSystemBlackList",
                checked = isForceFreeze,
                enabled = !isWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.FORCE_FREEZE_SET, packageName, enabled)
                }
            )

            SwitchPreference(
                title = "强力压制 (拦截非核心解冻)",
                summary = "在 GreezeManagerService#thawUid 中仅放行前台启动/通知等必要解冻原因",
                checked = isBlockThaw,
                enabled = !isWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.BLOCK_THAW_SET, packageName, enabled)
                }
            )

            SwitchPreference(
                title = "禁止同步 Binder 解冻",
                summary = "拦截 Sync Binder 与 Check Binder 引起的连带唤醒解冻",
                checked = isForbidSyncBinder,
                enabled = !isWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.FORBID_SYNC_BINDER_SET, packageName, enabled)
                }
            )

            SwitchPreference(
                title = "具有前台服务 (FGS) 时不冻结",
                summary = "检测到应用存在活跃 ForegroundService 时暂缓冻结 (适合音乐播放/导航)",
                checked = isNotFreezeFgs,
                enabled = !isWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.NOT_FREEZE_WHEN_HAS_FGS_SET, packageName, enabled)
                }
            )

            SwitchPreference(
                title = "加入系统省电白名单 (电池不优化)",
                summary = "同步至 DeviceIdleController PowerSaveWhitelist",
                checked = isBatteryOptWhite,
                onCheckedChange = { enabled ->
                    viewModel.updateAppSet(ConfigKeys.BATTERY_OPT_WHITE_SET, packageName, enabled)
                    viewModel.updateAppSet(ConfigKeys.BATTERY_OPT_BLACK_SET, packageName, !enabled)
                }
            )

            Spacer(modifier = Modifier.height(12.dp))
            TextButton(
                text = "完成",
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.textButtonColorsPrimary()
            )
        }
    }
}
