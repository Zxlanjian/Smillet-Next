package com.sidesand.millet.hook.system

import com.sidesand.millet.data.PrefsManager
import com.sidesand.millet.hook.SMilletLogger
import com.sidesand.millet.ipc.ISystemCallback
import com.sidesand.millet.ipc.SystemInterface
import java.util.concurrent.ConcurrentHashMap

/**
 * 驻留在 system_server 中的 SystemInterface Binder 服务端 (对应原模块 Landroid/support/v4/ਕ;)。
 */
object SystemServerService : SystemInterface.Stub() {

    private val callbacks = ConcurrentHashMap<String, ISystemCallback>()

    @Volatile
    var noRestrictAppsRaw: String? = null
        private set

    override fun isSystemHookActive(): Boolean = true

    override fun isPowerKeeperActive(): Boolean = callbacks.containsKey("PowerKeeper")

    override fun registerCallback(callback: ISystemCallback?, clientName: String) {
        if (callback != null && clientName.isNotEmpty()) {
            callbacks[clientName] = callback
            SMilletLogger.info("客户端已绑定 SystemServerService: $clientName")
        }
    }

    override fun unregisterCallback(callback: ISystemCallback?, clientName: String) {
        if (clientName.isNotEmpty()) {
            callbacks.remove(clientName)
        }
    }

    override fun notifyConfigChanged(key: String) {
        // 1. 先刷新 system_server 侧配置并立即应用
        SystemServerHook.reloadConfig(key)
        // 2. 转发给 PowerKeeper 侧同步更新 MilletPolicy 白名单/黑名单
        callbacks["PowerKeeper"]?.let { pk ->
            runCatching { pk.onConfigChanged(key) }
                .onFailure { callbacks.remove("PowerKeeper") }
        }
    }

    override fun checkUnfreezeReason(packageName: String) {
        val pk = callbacks["PowerKeeper"]
        if (pk == null) {
            reportUnfreezeReason(packageName, "电量与性能 (PowerKeeper) 尚未连接系统服务，请尝试重启电量与性能")
            return
        }
        runCatching {
            pk.requestCheckFreezeReason(packageName)
        }.onFailure {
            reportUnfreezeReason(packageName, "请求诊断异常: ${it.message}")
        }
    }

    override fun reportUnfreezeReason(packageName: String, reason: String) {
        callbacks["HomePage"]?.let { ui ->
            runCatching { ui.onFreezeReasonResult(packageName, reason) }
                .onFailure { callbacks.remove("HomePage") }
        }
    }

    override fun syncNoRestrictApps(rawList: String?) {
        noRestrictAppsRaw = rawList
        SMilletLogger.debug("同步无限制应用列表: $rawList")
    }
}
