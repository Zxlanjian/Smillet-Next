package com.sidesand.millet.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sidesand.millet.ui.theme.SMilletMiuixTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SMilletMiuixTheme {
                val vm: MainViewModel = viewModel()
                MainScreen(viewModel = vm)
            }
        }
    }
}
