package com.sidesand.millet.ui.pages

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.FreezeType
import com.sidesand.millet.data.RunningAppItem
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RunningListPage(
    viewModel: MainViewModel,
    isSystemActive: Boolean,
    isPowerKeeperActive: Boolean,
    onOpenAppConfig: (packageName: String, appName: String) -> Unit,
    onDiagnoseApp: (packageName: String) -> Unit
) {
    val runningApps by viewModel.runningApps.collectAsState()
    val isScanning by viewModel.isScanningRunning.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showSystemApps by remember { mutableStateOf(false) }

    val filtered = remember(runningApps, searchQuery) {
        if (searchQuery.isBlank()) runningApps
        else runningApps.filter {
            it.appName.contains(searchQuery, ignoreCase = true) ||
                it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 模块激活状态概览卡片
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isSystemActive && isPowerKeeperActive) {
                                    "SMillet 墓碑服务运行正常"
                                } else {
                                    "SMillet 服务未完全就绪"
                                },
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SystemServer: ${if (isSystemActive) "已连接" else "未连接"} · " +
                                    "PowerKeeper: ${if (isPowerKeeperActive) "已连接" else "未连接"}",
                                fontSize = 13.sp,
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                            )
                        }
                        TextButton(
                            text = if (isScanning) "扫描中..." else "刷新进程",
                            onClick = {
                                viewModel.connectBinderBridge()
                                viewModel.refreshRunningApps(showSystemApps)
                            }
                        )
                    }
                }
            }
        }

        // 搜索栏与系统应用过滤开关
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    TextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = "搜索运行中应用名称或包名...",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    SwitchPreference(
                        title = "显示系统应用进程",
                        summary = "开启后包含系统级后台进程 (单击卡片配置策略，长按诊断未冻结原因)",
                        checked = showSystemApps,
                        onCheckedChange = {
                            showSystemApps = it
                            viewModel.refreshRunningApps(it)
                        }
                    )
                }
            }
        }

        item {
            SmallTitle(text = "运行中应用 (${filtered.size})")
        }

        items(filtered, key = { it.packageName }) { item ->
            RunningAppCard(
                item = item,
                onClick = { onOpenAppConfig(item.packageName, item.appName) },
                onLongClick = { onDiagnoseApp(item.packageName) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RunningAppCard(
    item: RunningAppItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${item.appName} (${item.frozenCount}/${item.totalCount})",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${item.packageName} · UID:${item.uid}",
                        fontSize = 12.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    val statusBadge = when (item.primaryFreezeType) {
                        FreezeType.V2 -> "已冻结 · Freezer V2"
                        FreezeType.V1 -> "已冻结 · Freezer V1"
                        FreezeType.KILL -> "已暂停 · SIGSTOP"
                        FreezeType.RUNNING -> "运行中"
                    }
                    Text(
                        text = statusBadge,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = if (item.frozenCount > 0) {
                            MiuixTheme.colorScheme.primary
                        } else {
                            MiuixTheme.colorScheme.onSurfaceVariantSummary
                        }
                    )
                    Text(
                        text = String.format(Locale.US, "%.1f MB", item.totalRssMb),
                        fontSize = 12.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            item.processes.forEach { proc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "[${proc.pid}] ${proc.processName}",
                        fontSize = 12.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${proc.freezeType.label} (${proc.wchan})",
                        fontSize = 12.sp,
                        color = if (proc.isFrozen) {
                            MiuixTheme.colorScheme.primary
                        } else {
                            MiuixTheme.colorScheme.onSurfaceVariantSummary
                        }
                    )
                }
            }
        }
    }
}
