package com.sidesand.millet.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.sidesand.millet.data.FreezeType
import com.sidesand.millet.data.ProcessDetail
import com.sidesand.millet.data.RunningAppItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 还原原模块 Landroid/support/v4/ࡢ; 的 Root 进程扫描器：
 * 执行 `su -c ps -A -o PID,UID,RSS,WCHAN,S,NAME` 并结合 `/proc/<pid>/wchan` 识别：
 * - Freezer V2: `do_freezer_trap` / `get_signal`
 * - Freezer V1: `__refrigerator`
 * - Signal Stop (Kill): 状态 `T` (`do_signal_stop`)
 */
object ProcessScanner {

    suspend fun scanRunningApps(
        context: Context,
        includeSystemApps: Boolean
    ): Result<List<RunningAppItem>> = withContext(Dispatchers.IO) {
        try {
            val pm = context.packageManager
            val installedApps = pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            val uidToAppMap = HashMap<Int, ApplicationInfo>()
            val pkgToAppMap = HashMap<String, ApplicationInfo>()

            for (info in installedApps) {
                pkgToAppMap[info.packageName] = info
                uidToAppMap.putIfAbsent(info.uid, info)
            }

            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "ps -A -o PID,UID,RSS,WCHAN,S,NAME"))
            val reader = BufferedReader(InputStreamReader(proc.inputStream))
            val grouped = HashMap<String, MutableList<ProcessDetail>>()
            val pkgUidMap = HashMap<String, Int>()

            var isFirstLine = true
            reader.useLines { lines ->
                lines.forEach { rawLine ->
                    val line = rawLine.trim()
                    if (line.isEmpty()) return@forEach
                    if (isFirstLine && line.startsWith("PID")) {
                        isFirstLine = false
                        return@forEach
                    }
                    isFirstLine = false

                    val parts = line.split(Regex("\\s+"), limit = 6)
                    if (parts.size < 6) return@forEach

                    val pid = parts[0].toIntOrNull() ?: return@forEach
                    val uidStr = parts[1]
                    val rssKb = parts[2].toLongOrNull() ?: 0L
                    val wchan = parts[3]
                    val state = parts[4]
                    val processName = parts[5]

                    // 过滤内核线程与非应用进程
                    if (!processName.contains(".")) return@forEach

                    val basePkg = processName.substringBefore(":")
                    val appInfo = pkgToAppMap[basePkg] ?: return@forEach
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    if (!includeSystemApps && isSystem) return@forEach

                    val freezeType = classifyFreezeState(wchan, state)
                    val isFrozen = freezeType != FreezeType.RUNNING

                    val detail = ProcessDetail(
                        pid = pid,
                        processName = processName,
                        rssKb = rssKb,
                        wchan = wchan,
                        state = state,
                        isFrozen = isFrozen,
                        freezeType = freezeType
                    )

                    pkgUidMap[basePkg] = appInfo.uid
                    grouped.getOrPut(basePkg) { mutableListOf() }.add(detail)
                }
            }
            proc.waitFor()

            val resultList = grouped.mapNotNull { (pkg, processes) ->
                val appInfo = pkgToAppMap[pkg] ?: return@mapNotNull null
                val appName = pm.getApplicationLabel(appInfo).toString()
                val icon = runCatching { pm.getApplicationIcon(appInfo) }.getOrNull()
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val totalRssMb = processes.sumOf { it.rssKb } / 1024f

                RunningAppItem(
                    uid = pkgUidMap[pkg] ?: appInfo.uid,
                    packageName = pkg,
                    appName = appName,
                    icon = icon,
                    isSystemApp = isSystem,
                    totalRssMb = totalRssMb,
                    processes = processes.sortedBy { it.processName }
                )
            }.sortedWith(
                compareByDescending<RunningAppItem> { it.frozenCount > 0 }
                    .thenByDescending { it.totalRssMb }
            )

            Result.success(resultList)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun classifyFreezeState(wchan: String, state: String): FreezeType {
        val lower = wchan.lowercase()
        return when {
            lower.contains("freezer") || lower.contains("get_signal") -> FreezeType.V2
            lower.contains("refrigerator") -> FreezeType.V1
            state.contains("T", ignoreCase = true) || lower.contains("signal_stop") -> FreezeType.KILL
            else -> FreezeType.RUNNING
        }
    }
}
