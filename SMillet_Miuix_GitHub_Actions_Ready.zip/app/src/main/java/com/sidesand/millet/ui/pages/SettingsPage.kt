package com.sidesand.millet.ui.pages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference

/**
 * 整合原模块 MilletConfigPage、DozeConfigPage 与 BackupConfigPage 的完整设置页。
 */
@Composable
fun SettingsPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    isSystemActive: Boolean,
    isPowerKeeperActive: Boolean
) {
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    var importFeedback by remember { mutableStateOf<String?>(null) }

    val logLevels = listOf("debug", "info", "warn", "error")
    val logTypes = listOf("xposed", "file")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Millet 墓碑核心增强设置
        item {
            SmallTitle(text = "Millet 墓碑机制增强")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "阻止电量与性能杀后台 (disableKill)",
                        summary = "拦截 PowerCheckerController 与 PowerStateMachine 锁屏清理后台进程",
                        checked = config.disableKill,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_KILL, it) }
                    )
                    SwitchPreference(
                        title = "阻止充电解冻应用 (disableCharge)",
                        summary = "拦截 MilletHandler (what=13, arg1=16) 防止插拔充电器唤醒全部冻结进程",
                        checked = config.disableCharge,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_CHARGE, it) }
                    )
                    SwitchPreference(
                        title = "阻止音量键解冻应用 (disableVolume)",
                        summary = "拦截 MilletBrightHandler (eventcode 24/25) 防止按音量键连带解冻后台应用",
                        checked = config.disableVolume,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_VOLUME, it) }
                    )
                    SwitchPreference(
                        title = "阻止系统动态篡改省电白名单",
                        summary = "拦截 CommonAdapter 与 MilletPolicy#dealSleepModeWhiteList 自动覆盖白名单",
                        checked = config.blockAddPowerSaveWhitelistApps,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, it)
                        }
                    )
                    SwitchPreference(
                        title = "息屏耗电观察统计 (batteryChangeObserve)",
                        summary = "在每次息屏与亮屏时自动记录时长、电量百分比与 mAh 变化",
                        checked = config.batteryChangeObserve,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, it)
                        }
                    )
                }
            }
        }

        // 2. 深度 Doze 增强设置
        item {
            SmallTitle(text = "深度 Doze (DeviceIdle) 优化")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "息屏自动进入深度 Doze (enableDoze)",
                        summary = "屏幕关闭满 3 分钟后自动触发 DeviceIdle 深度睡眠，亮屏即刻恢复",
                        checked = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.ENABLE_DOZE, it) }
                    )
                    SwitchPreference(
                        title = "跳过状态检查直接进入 IDLE (skipStateCheck)",
                        summary = "在 moveToStateLocked 中跳过 IDLE_PENDING / SENSING / LOCATING 阶段",
                        checked = config.skipStateCheck,
                        enabled = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SKIP_STATE_CHECK, it) }
                    )
                    SwitchPreference(
                        title = "禁用 Doze 运动传感器唤醒 (disableMotionListener)",
                        summary = "拦截 DeviceIdleController#motionLocked 并保持 mNotMoving = true",
                        checked = config.disableMotionListener,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, it)
                        }
                    )
                    SwitchPreference(
                        title = "输出 Doze 状态切换日志 (dozeLog)",
                        summary = "记录每次 Doze 状态机切换原因与目标状态",
                        checked = config.dozeLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DOZE_LOG, it) }
                    )
                }
            }
        }

        // 3. 日志与调试配置
        item {
            SmallTitle(text = "日志与调试")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "启用详细冻结/解冻日志 (isLog)",
                        summary = "记录 GreezeManagerService 与 MilletPolicy 的完整调用日志",
                        checked = config.isLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.IS_LOG, it) }
                    )
                    SwitchPreference(
                        title = "启用精简日志与进程状态追踪 (simplifyLog)",
                        summary = "仅输出关键冻结/解冻事件并追踪 ProcessList 进程增删",
                        checked = config.simplifyLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SIMPLIFY_LOG, it) }
                    )
                    OverlayDropdownPreference(
                        title = "日志级别 (logLevel)",
                        items = logLevels,
                        selectedIndex = logLevels.indexOf(config.logLevel).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_LEVEL, logLevels[idx])
                        }
                    )
                    OverlayDropdownPreference(
                        title = "日志输出位置 (logType)",
                        items = listOf("LSPosed 框架日志 (xposed)", "本地文件 (/data/system/SMillet/log)"),
                        selectedIndex = logTypes.indexOf(config.logType).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_TYPE, logTypes[idx])
                        }
                    )
                }
            }
        }

        // 4. 配置备份与恢复
        item {
            SmallTitle(text = "备份与恢复")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    ArrowPreference(
                        title = "导出 / 导入 JSON 配置备份",
                        summary = "完全兼容原版 SMillet Pro 备份格式 (MilletSettings / DozeSettings / AppSettings)",
                        onClick = {
                            backupJsonText = viewModel.prefsManager.exportBackupJson()
                            importFeedback = null
                            showBackupDialog = true
                        }
                    )
                }
            }
        }
    }

    if (showBackupDialog) {
        OverlayDialog(
            show = true,
            title = "JSON 配置备份与恢复",
            summary = "可复制下方 JSON 保存，或粘贴已有备份后点击「导入并应用」",
            onDismissRequest = { showBackupDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                TextField(
                    value = backupJsonText,
                    onValueChange = { backupJsonText = it },
                    label = "备份 JSON 内容",
                    modifier = Modifier.fillMaxWidth()
                )
                importFeedback?.let { msg ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = msg)
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        text = "关闭",
                        onClick = { showBackupDialog = false },
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        text = "导入并应用",
                        onClick = {
                            val ok = viewModel.prefsManager.importBackupJson(backupJsonText)
                            if (ok) {
                                viewModel.reloadSnapshot()
                                importFeedback = "导入成功，已实时同步至 SystemServer 与 PowerKeeper"
                            } else {
                                importFeedback = "JSON 格式解析失败，请检查内容是否完整"
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    }
}
