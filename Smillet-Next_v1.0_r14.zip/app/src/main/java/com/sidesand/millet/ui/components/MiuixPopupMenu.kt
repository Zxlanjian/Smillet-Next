package com.sidesand.millet.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import top.yukonga.miuix.kmp.basic.Switch
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.theme.MiuixTheme

/**
 * Miuix v0.9.4 原生风格右上角弹出菜单 (对齐 Miuix OverlayListPopup / DropdownImpl 视觉设计)：
 * - 移除会导致超出圆角边界的 Modifier.shadow(...)，改用 Miuix 原生半透明背景遮罩 (Dim Layer) + 严格裁剪的圆角卡片与细腻描边
 * - 选中项高亮背景直通首尾圆角，无顶部/底部留白断层
 * - 支持预测性返回手势实时缩放预览 (backProgress)
 */
@Composable
fun MiuixTopPopupMenu(
    visible: Boolean,
    onDismiss: () -> Unit,
    width: Dp = 228.dp,
    backProgress: Float = 0f,
    content: @Composable ColumnScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val dimColor = if (isDark) Color.Black.copy(alpha = 0.38f) else Color.Black.copy(alpha = 0.16f)
    val menuBg = if (isDark) Color(0xFF242426) else Color(0xFFFFFFFF)
    val borderColor = if (isDark) Color.White.copy(alpha = 0.10f) else Color.Black.copy(alpha = 0.06f)
    val popupShape = RoundedCornerShape(16.dp)

    // Miuix 风格柔和遮罩层
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(animationSpec = tween(durationMillis = 160)),
        exit = fadeOut(animationSpec = tween(durationMillis = 140))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(dimColor.copy(alpha = dimColor.alpha * (1f - backProgress * 0.6f)))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
        )
    }

    // 右上角弹出菜单主体（严格裁剪在 RoundedCornerShape(16.dp) 内，无任何阴影溢出）
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopEnd
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = scaleIn(
                animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                initialScale = 0.86f,
                transformOrigin = TransformOrigin(1f, 0f)
            ) + fadeIn(animationSpec = tween(durationMillis = 150)),
            exit = scaleOut(
                animationSpec = tween(durationMillis = 150, easing = FastOutSlowInEasing),
                targetScale = 0.86f,
                transformOrigin = TransformOrigin(1f, 0f)
            ) + fadeOut(animationSpec = tween(durationMillis = 120)),
            modifier = Modifier.padding(top = 6.dp, end = 16.dp)
        ) {
            val scale = 1f - (backProgress * 0.10f).coerceIn(0f, 0.15f)
            val alpha = 1f - (backProgress * 0.30f).coerceIn(0f, 0.50f)

            Column(
                modifier = Modifier
                    .width(width)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                        transformOrigin = TransformOrigin(1f, 0f)
                    }
                    .clip(popupShape)
                    .background(menuBg)
                    .border(width = 0.6.dp, color = borderColor, shape = popupShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    ),
                content = content
            )
        }
    }
}

@Composable
fun MiuixPopupOptionRow(
    text: String,
    selected: Boolean,
    isFirst: Boolean = false,
    isLast: Boolean = false,
    onClick: () -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val selectedBg = if (isDark) {
        MiuixTheme.colorScheme.primary.copy(alpha = 0.22f)
    } else {
        MiuixTheme.colorScheme.primary.copy(alpha = 0.12f)
    }
    val textColor = if (selected) {
        MiuixTheme.colorScheme.primary
    } else {
        MiuixTheme.colorScheme.onSurface
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) selectedBg else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = if (isFirst) 15.dp else 13.dp,
                bottom = if (isLast) 15.dp else 13.dp
            ),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = textColor
        )
        if (selected) {
            MiuixPopupCheckIcon(color = MiuixTheme.colorScheme.primary)
        }
    }
}

@Composable
fun MiuixPopupActionRow(
    text: String,
    textColor: Color = MiuixTheme.colorScheme.onSurface,
    isFirst: Boolean = false,
    isLast: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = if (isFirst) 15.dp else 13.dp,
                bottom = if (isLast) 15.dp else 13.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = textColor
        )
    }
}

@Composable
fun MiuixPopupSwitchRow(
    text: String,
    checked: Boolean,
    isLast: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = if (isLast) 15.dp else 12.dp
            ),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = MiuixTheme.colorScheme.onSurface
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
fun MiuixPopupDivider() {
    val isDark = isSystemInDarkTheme()
    val dividerColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.06f)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(0.6.dp)
            .background(dividerColor)
    )
}

@Composable
fun MiuixPopupCheckIcon(color: Color) {
    Canvas(modifier = Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.18f, h * 0.52f)
            lineTo(w * 0.42f, h * 0.76f)
            lineTo(w * 0.84f, h * 0.26f)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 2.1.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}
