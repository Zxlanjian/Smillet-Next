package com.sidesand.millet.ui

import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.widget.Toast
import androidx.activity.BackEventCompat
import androidx.activity.compose.BackHandler
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.ui.components.MiuixPopupActionRow
import com.sidesand.millet.ui.components.MiuixPopupOptionRow
import com.sidesand.millet.ui.components.MiuixTopPopupMenu
import com.sidesand.millet.ui.pages.APP_FILTER_OPTIONS
import com.sidesand.millet.ui.pages.AboutPage
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.AppearancePage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.MAX_DISPLAY_LOG_COUNT
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import com.sidesand.millet.ui.pages.filterLogLines
import com.sidesand.millet.ui.theme.LocalAppBlurEnabled
import com.sidesand.millet.ui.theme.LocalAppDarkMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 1:1 复刻 YuKongA/Mishka 的顶栏与悬浮底栏背景着色器：
 * 1. 顶栏模糊支持两个视觉差异极显著的档位：
 *    - 高斯 (progressive == 0.0)：在 [0, topBarBottom] 范围内呈现均匀高强度毛玻璃模糊 (78% 表面色混合) + 底部微细分割线；
 *    - 渐进 (progressive == 1.0)：对齐 Mishka 的 ProgressiveBlur.Top.copy(curve = 2.2f)，作用范围延伸至 topBarBottom * 1.28，
 *      模糊半径与表面着色透明度均按 pow(1.0 - y / effBottom, 2.2) 指数曲线从顶部 100% 平滑衰减至底部 0%，滚入顶栏的卡片呈现由实入雾的无界渐隐效果；
 * 2. 底部悬浮胶囊区域 (bottomRect) 支持：
 *    - Miuix 悬浮毛玻璃胶囊 (bottomStyle == 1.0)：圆角胶囊内实时高斯毛玻璃模糊；
 *    - iOS 液态玻璃胶囊 (bottomStyle == 2.0)：对胶囊边缘施加光学透镜折射扭曲 (Lens Refraction) + 1.38x 鲜亮饱和度提升 (Vibrancy) + 液态玻璃高光。
 */
private const val BAR_BLUR_H_AGSL = """
    uniform shader content;
    uniform float topBarBottom;
    uniform float stepSize;
    uniform float progressive;
    uniform float4 bottomRect;
    uniform float bottomRadius;
    uniform float bottomStyle;

    float sdRoundBox(float2 p, float2 b, float r) {
        float2 q = abs(p) - b + r;
        return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
    }

    half4 main(float2 fragCoord) {
        float effTopBottom = progressive > 0.5 ? (topBarBottom * 1.28) : topBarBottom;
        bool inTop = (topBarBottom > 1.0) && (fragCoord.y < effTopBottom);

        bool inBottom = false;
        float bottomDist = 1000.0;
        float2 bottomCenter = float2(0.0);
        float2 bottomHalf = float2(0.0);
        if (bottomStyle > 0.5 && bottomRect.z > bottomRect.x && bottomRect.w > bottomRect.y) {
            bottomCenter = float2((bottomRect.x + bottomRect.z) * 0.5, (bottomRect.y + bottomRect.w) * 0.5);
            bottomHalf = float2((bottomRect.z - bottomRect.x) * 0.5, (bottomRect.w - bottomRect.y) * 0.5);
            bottomDist = sdRoundBox(fragCoord - bottomCenter, bottomHalf, bottomRadius);
            inBottom = (bottomDist <= 0.0);
        }

        if (!inTop && !inBottom) {
            return content.eval(fragCoord);
        }

        float factor = 1.0;
        if (inTop && !inBottom && progressive > 0.5) {
            float t = clamp(1.0 - (fragCoord.y / max(1.0, effTopBottom)), 0.0, 1.0);
            factor = pow(t, 2.2);
        }

        float2 baseCoord = fragCoord;
        // iOS 液态玻璃边缘透镜折射 (Lens Refraction)
        if (inBottom && bottomStyle > 1.5) {
            float edgeZone = clamp(1.0 + bottomDist / max(1.0, bottomRadius * 0.85), 0.0, 1.0);
            float lensStrength = edgeZone * edgeZone * 14.0;
            float2 dir = normalize(fragCoord - bottomCenter + float2(0.001, 0.001));
            baseCoord = fragCoord - dir * lensStrength;
            factor = 0.88;
        }

        float effStep = stepSize * factor;
        if (effStep < 0.15) {
            return content.eval(baseCoord);
        }

        half4 accum = half4(0.0);
        float weightSum = 0.0;
        for (int i = -10; i <= 10; i++) {
            float fi = float(i);
            float w = exp(-(fi * fi) / 28.0);
            float2 samplePos = float2(max(1.0, baseCoord.x + fi * effStep), baseCoord.y);
            accum += content.eval(samplePos) * w;
            weightSum += w;
        }
        return accum / weightSum;
    }
"""

private const val BAR_BLUR_V_TINT_AGSL = """
    uniform shader content;
    uniform float topBarBottom;
    uniform float stepSize;
    uniform float progressive;
    uniform float4 surfaceTint;
    uniform float4 bottomRect;
    uniform float bottomRadius;
    uniform float bottomStyle;

    float sdRoundBox(float2 p, float2 b, float r) {
        float2 q = abs(p) - b + r;
        return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
    }

    half4 main(float2 fragCoord) {
        float effTopBottom = progressive > 0.5 ? (topBarBottom * 1.28) : topBarBottom;
        bool inTop = (topBarBottom > 1.0) && (fragCoord.y < effTopBottom);

        bool inBottom = false;
        float bottomDist = 1000.0;
        if (bottomStyle > 0.5 && bottomRect.z > bottomRect.x && bottomRect.w > bottomRect.y) {
            float2 bottomCenter = float2((bottomRect.x + bottomRect.z) * 0.5, (bottomRect.y + bottomRect.w) * 0.5);
            float2 bottomHalf = float2((bottomRect.z - bottomRect.x) * 0.5, (bottomRect.w - bottomRect.y) * 0.5);
            bottomDist = sdRoundBox(fragCoord - bottomCenter, bottomHalf, bottomRadius);
            inBottom = (bottomDist <= 0.0);
        }

        if (!inTop && !inBottom) {
            return content.eval(fragCoord);
        }

        float factor = 1.0;
        if (inTop && !inBottom && progressive > 0.5) {
            float t = clamp(1.0 - (fragCoord.y / max(1.0, effTopBottom)), 0.0, 1.0);
            factor = pow(t, 2.2);
        } else if (inBottom && bottomStyle > 1.5) {
            factor = 0.88;
        }

        float effStep = stepSize * factor;
        half4 blurred;
        if (effStep < 0.15) {
            blurred = content.eval(fragCoord);
        } else {
            float minY = inTop ? 1.0 : max(1.0, bottomRect.y);
            float maxY = inTop ? max(1.0, effTopBottom - 1.0) : max(1.0, bottomRect.w - 1.0);
            half4 accum = half4(0.0);
            float weightSum = 0.0;
            for (int i = -10; i <= 10; i++) {
                float fi = float(i);
                float w = exp(-(fi * fi) / 28.0);
                float sy = clamp(fragCoord.y + fi * effStep, minY, maxY);
                accum += content.eval(float2(fragCoord.x, sy)) * w;
                weightSum += w;
            }
            blurred = accum / weightSum;
        }

        if (surfaceTint.a > 0.0) {
            if (inBottom && bottomStyle > 1.5) {
                // iOS 液态玻璃 Vibrancy (1.42x 饱和度提升 + 通透高光折射层)
                float luma = dot(blurred.rgb, half3(0.299, 0.587, 0.114));
                half3 vibrant = clamp(mix(half3(luma), blurred.rgb, 1.42), 0.0, 1.0);
                float glassAlpha = surfaceTint.a * 0.58;
                half3 mixed = mix(vibrant, half3(surfaceTint.rgb), glassAlpha);
                // 边缘高光折射光晕
                float rim = smoothstep(-3.5, 0.0, bottomDist);
                mixed = mix(mixed, half3(1.0, 1.0, 1.0), rim * 0.28);
                return half4(mixed, 1.0);
            }
            float alpha = inTop
                ? (progressive > 0.5 ? (surfaceTint.a * 0.72 * factor) : surfaceTint.a)
                : (surfaceTint.a * 0.84);
            return mix(blurred, half4(surfaceTint.rgb, 1.0), alpha);
        }
        return blurred;
    }
"""

private sealed interface SecondaryRoute {
    data object None : SecondaryRoute
    data class AppDetail(val packageName: String, val appName: String) : SecondaryRoute
    data object Logs : SecondaryRoute
    data object Appearance : SecondaryRoute
    data object About : SecondaryRoute
}

private val MiuixNavEasing = CubicBezierEasing(0.22f, 1.0f, 0.36f, 1.0f)

private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(5.6f, 3.4f)
            horizontalLineTo(9.4f)
            curveTo(10.6f, 3.4f, 11.4f, 4.2f, 11.4f, 5.4f)
            verticalLineTo(18.6f)
            curveTo(11.4f, 19.8f, 10.6f, 20.6f, 9.4f, 20.6f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 20.6f, 3.6f, 19.8f, 3.6f, 18.6f)
            verticalLineTo(5.4f)
            curveTo(3.6f, 4.2f, 4.4f, 3.4f, 5.6f, 3.4f)
            close()

            moveTo(16.2f, 3.4f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 3.4f, 20.4f, 4.2f, 20.4f, 5.4f)
            verticalLineTo(8.5f)
            curveTo(20.4f, 9.7f, 19.6f, 10.5f, 18.4f, 10.5f)
            horizontalLineTo(16.2f)
            curveTo(15.0f, 10.5f, 14.2f, 9.7f, 14.2f, 8.5f)
            verticalLineTo(5.4f)
            curveTo(14.2f, 4.2f, 15.0f, 3.4f, 16.2f, 3.4f)
            close()

            moveTo(16.2f, 13.5f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 13.5f, 20.4f, 14.3f, 20.4f, 15.5f)
            verticalLineTo(18.6f)
            curveTo(20.4f, 19.8f, 19.6f, 20.6f, 18.4f, 20.6f)
            horizontalLineTo(16.2f)
            curveTo(15.0f, 20.6f, 14.2f, 19.8f, 14.2f, 18.6f)
            verticalLineTo(15.5f)
            curveTo(14.2f, 14.3f, 15.0f, 13.5f, 16.2f, 13.5f)
            close()
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(5.6f, 3.6f)
            horizontalLineTo(8.6f)
            curveTo(9.8f, 3.6f, 10.6f, 4.4f, 10.6f, 5.6f)
            verticalLineTo(8.6f)
            curveTo(10.6f, 9.8f, 9.8f, 10.6f, 8.6f, 10.6f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 10.6f, 3.6f, 9.8f, 3.6f, 8.6f)
            verticalLineTo(5.6f)
            curveTo(3.6f, 4.4f, 4.4f, 3.6f, 5.6f, 3.6f)
            close()

            val cx = 17.0f
            val cy = 7.1f
            val r = 3.5f
            moveTo(cx + r, cy)
            curveTo(cx + r, cy + r * 0.552f, cx + r * 0.552f, cy + r, cx, cy + r)
            curveTo(cx - r * 0.552f, cy + r, cx - r, cy + r * 0.552f, cx - r, cy)
            curveTo(cx - r, cy - r * 0.552f, cx - r * 0.552f, cy - r, cx, cy - r)
            curveTo(cx + r * 0.552f, cy - r, cx + r, cy - r * 0.552f, cx + r, cy)
            close()

            moveTo(5.6f, 13.4f)
            horizontalLineTo(8.6f)
            curveTo(9.8f, 13.4f, 10.6f, 14.2f, 10.6f, 15.4f)
            verticalLineTo(18.4f)
            curveTo(10.6f, 19.6f, 9.8f, 20.4f, 8.6f, 20.4f)
            horizontalLineTo(5.6f)
            curveTo(4.4f, 20.4f, 3.6f, 19.6f, 3.6f, 18.4f)
            verticalLineTo(15.4f)
            curveTo(3.6f, 14.2f, 4.4f, 13.4f, 5.6f, 13.4f)
            close()

            moveTo(15.4f, 13.4f)
            horizontalLineTo(18.4f)
            curveTo(19.6f, 13.4f, 20.4f, 14.2f, 20.4f, 15.4f)
            verticalLineTo(18.4f)
            curveTo(20.4f, 19.6f, 19.6f, 20.4f, 18.4f, 20.4f)
            horizontalLineTo(15.4f)
            curveTo(14.2f, 20.4f, 13.4f, 19.6f, 13.4f, 18.4f)
            verticalLineTo(15.4f)
            curveTo(13.4f, 14.2f, 14.2f, 13.4f, 15.4f, 13.4f)
            close()
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(7.2f, 3.4f)
            horizontalLineTo(16.8f)
            curveTo(19.0f, 3.4f, 20.6f, 5.0f, 20.6f, 7.2f)
            verticalLineTo(16.8f)
            curveTo(20.6f, 19.0f, 19.0f, 20.6f, 16.8f, 20.6f)
            horizontalLineTo(7.2f)
            curveTo(5.0f, 20.6f, 3.4f, 19.0f, 3.4f, 16.8f)
            verticalLineTo(7.2f)
            curveTo(3.4f, 5.0f, 5.0f, 3.4f, 7.2f, 3.4f)
            close()

            moveTo(6.6f, 12.2f)
            horizontalLineTo(9.0f)
            lineTo(10.6f, 8.6f)
            lineTo(13.2f, 15.4f)
            lineTo(14.9f, 12.2f)
            horizontalLineTo(17.4f)
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(12.0f, 2.8f)
            lineTo(19.8f, 7.3f)
            verticalLineTo(16.7f)
            lineTo(12.0f, 21.2f)
            lineTo(4.2f, 16.7f)
            verticalLineTo(7.3f)
            close()
            val r = 3.15f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
    }.build()
}

private val IconMoreCircle: ImageVector by lazy {
    ImageVector.Builder("MoreCircle", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.85f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            val r = 9.0f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
        path(fill = SolidColor(Color.Black)) {
            val xs = floatArrayOf(8.2f, 12.0f, 15.8f)
            val dotR = 1.15f
            for (cx in xs) {
                moveTo(cx + dotR, 12f)
                curveTo(cx + dotR, 12f + dotR * 0.55f, cx + dotR * 0.55f, 12f + dotR, cx, 12f + dotR)
                curveTo(cx - dotR * 0.55f, 12f + dotR, cx - dotR, 12f + dotR * 0.55f, cx - dotR, 12f)
                curveTo(cx - dotR, 12f - dotR * 0.55f, cx - dotR * 0.55f, 12f - dotR, cx, 12f - dotR)
                curveTo(cx + dotR * 0.55f, 12f - dotR, cx + dotR, 12f - dotR * 0.55f, cx + dotR, 12f)
                close()
            }
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(18.2f, 7.6f)
            curveTo(16.8f, 5.6f, 14.5f, 4.4f, 12.0f, 4.4f)
            curveTo(7.8f, 4.4f, 4.4f, 7.8f, 4.4f, 12.0f)
            curveTo(4.4f, 16.2f, 7.8f, 19.6f, 12.0f, 19.6f)
            curveTo(15.6f, 19.6f, 18.6f, 17.1f, 19.4f, 13.7f)
            moveTo(18.6f, 4.4f)
            verticalLineTo(8.2f)
            horizontalLineTo(14.8f)
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("BackArrow", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(19.5f, 12.0f)
            lineTo(4.8f, 12.0f)
            moveTo(11.0f, 5.8f)
            lineTo(4.8f, 12.0f)
            lineTo(11.0f, 18.2f)
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 4 })
    var secondaryRoute by remember { mutableStateOf<SecondaryRoute>(SecondaryRoute.None) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val config by viewModel.config.collectAsState()
    val logs by viewModel.logsList.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")
    val navLabels = listOf("主页", "应用列表", "运行列表", "设置")
    val navIcons = listOf(IconHome, IconAppList, IconRunningCheck, IconHexSettings)

    val isDark = LocalAppDarkMode.current
    val blurEnabled = LocalAppBlurEnabled.current
    val surfaceBg = MiuixTheme.colorScheme.surface
    val topBarColor = if (blurEnabled) Color.Transparent else surfaceBg

    var appListTopBarHeight by remember { mutableStateOf(96.dp) }
    var logPageTopBarHeight by remember { mutableStateOf(96.dp) }
    var floatingBarBounds by remember { mutableStateOf(Rect.Zero) }

    // 预测性返回手势实时进度 (0f..1f) 与边缘方向 (0=Left, 1=Right)
    var predictiveBackProgress by remember { mutableFloatStateOf(0f) }
    var predictiveBackEdge by remember { mutableIntStateOf(0) }

    LaunchedEffect(pagerState.currentPage) {
        if (pagerState.currentPage != 1) {
            showAppFilterSheet = false
        }
        if (pagerState.currentPage == 2) {
            viewModel.refreshRunningApps(includeSystemApps)
        }
    }

    val exportLogFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val currentFiltered = filterLogLines(logs, config.logLevel, logFilterLevel)
                val content = if (currentFiltered.isEmpty()) {
                    "暂无日志记录\n"
                } else {
                    currentFiltered.joinToString("\n") + "\n"
                }
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "日志文件已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "导出日志失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 1. 弹出菜单优先拦截返回
    BackHandler(enabled = showAppFilterSheet || showLogTopMenu) {
        when {
            showAppFilterSheet -> showAppFilterSheet = false
            showLogTopMenu -> showLogTopMenu = false
        }
    }

    // 2. 二级页返回处理：当开启「预测性返回手势」时使用 PredictiveBackHandler 驱动实时缩放/视差返回动画
    PredictiveBackHandler(
        enabled = !showAppFilterSheet && !showLogTopMenu && secondaryRoute !is SecondaryRoute.None && config.predictiveBackEnabled
    ) { progressFlow: Flow<BackEventCompat> ->
        try {
            progressFlow.collect { backEvent ->
                predictiveBackEdge = backEvent.swipeEdge
                predictiveBackProgress = backEvent.progress
            }
            predictiveBackProgress = 0f
            secondaryRoute = SecondaryRoute.None
        } catch (_: CancellationException) {
            predictiveBackProgress = 0f
        }
    }

    // 当关闭「预测性返回手势」时使用常规 BackHandler
    BackHandler(
        enabled = !showAppFilterSheet && !showLogTopMenu && secondaryRoute !is SecondaryRoute.None && !config.predictiveBackEnabled
    ) {
        secondaryRoute = SecondaryRoute.None
    }

    fun navigateToTab(targetPage: Int) {
        showAppFilterSheet = false
        scope.launch {
            pagerState.animateScrollToPage(
                page = targetPage,
                animationSpec = spring(
                    dampingRatio = 0.92f,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
    }

    val hasSecondaryPage = secondaryRoute !is SecondaryRoute.None
    val baseParallax by animateFloatAsState(
        targetValue = if (hasSecondaryPage) 1f else 0f,
        animationSpec = tween(durationMillis = 320, easing = MiuixNavEasing),
        label = "MainParallaxProgress"
    )
    // 预测性返回手势拖动期间，底层主页随手指进度实时向回推进
    val effectiveMainParallax = (baseParallax * (1f - predictiveBackProgress * 0.85f)).coerceIn(0f, 1f)

    val navInsetsBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(surfaceBg)
    ) {
        // 1. 底层常驻主界面：4 Tab HorizontalPager + 底部导航栏（支持标准底栏 / Miuix 悬浮底栏 / iOS 液态玻璃底栏）
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = -size.width * 0.24f * effectiveMainParallax
                }
        ) {
            Scaffold(
                bottomBar = {
                    if (!config.floatingBottomBar) {
                        if (config.bottomBarMode == 0) {
                            NavigationBar {
                                for (i in 0..3) {
                                    NavigationBarItem(
                                        selected = pagerState.currentPage == i,
                                        onClick = { navigateToTab(i) },
                                        icon = navIcons[i],
                                        label = navLabels[i]
                                    )
                                }
                            }
                        } else {
                            StandardIconOnlyBottomBar(
                                selectedIndex = pagerState.currentPage,
                                isDark = isDark,
                                icons = navIcons,
                                labels = navLabels,
                                onSelect = { navigateToTab(it) }
                            )
                        }
                    }
                }
            ) { outerPadding ->
                val bottomBarHeight = if (config.floatingBottomBar) {
                    navInsetsBottom + if (config.bottomBarMode == 1) 76.dp else 88.dp
                } else {
                    outerPadding.calculateBottomPadding()
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    HorizontalPager(
                        state = pagerState,
                        beyondViewportPageCount = 1,
                        modifier = Modifier
                            .fillMaxSize()
                            .pagerGestureInterceptor(
                                mode = config.pageSwitchGesture,
                                pagerState = pagerState,
                                onHaltScroll = {
                                    scope.launch {
                                        pagerState.scrollToPage(pagerState.currentPage)
                                    }
                                }
                            )
                    ) { page ->
                        val tabScrollBehavior = MiuixScrollBehavior()

                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = tabTitles[page],
                                    scrollBehavior = tabScrollBehavior,
                                    color = topBarColor,
                                    actions = {
                                        when (page) {
                                            1 -> {
                                                TopMenuActionButton(
                                                    active = showAppFilterSheet,
                                                    isDark = isDark,
                                                    contentDescription = "筛选",
                                                    onClick = { showAppFilterSheet = !showAppFilterSheet }
                                                )
                                            }
                                            2 -> {
                                                IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                                    Icon(
                                                        imageVector = IconRefresh,
                                                        contentDescription = "刷新",
                                                        tint = MiuixTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                        ) { tabInnerPadding ->
                            val topBarHeight = tabInnerPadding.calculateTopPadding()
                            if (page == 1 && topBarHeight > 0.dp) {
                                appListTopBarHeight = topBarHeight
                            }
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 16.dp
                            )

                            val bottomStyleFlag = when {
                                !config.floatingBottomBar -> 0
                                config.floatingBottomBarStyle == 1 -> 2 // iOS 液态玻璃
                                else -> 1 // Miuix 悬浮胶囊
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarAndBottomFrostedBlur(
                                        enabled = blurEnabled || (config.floatingBottomBar && config.floatingBottomBarStyle == 1),
                                        topBarHeight = if (blurEnabled) topBarHeight else 0.dp,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark,
                                        progressive = config.topBarBlurMode == 1,
                                        bottomRect = floatingBarBounds,
                                        bottomStyle = bottomStyleFlag
                                    )
                                    .background(surfaceBg)
                            ) {
                                when (page) {
                                    0 -> HomePage(
                                        viewModel = viewModel,
                                        config = config,
                                        isSystemActive = isSystemActive,
                                        isPowerKeeperActive = isPkActive,
                                        scrollBehavior = tabScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onNavigateToWhitelist = {
                                            appFilterIndex = 2
                                            navigateToTab(1)
                                        },
                                        onNavigateToBlacklist = {
                                            appFilterIndex = 3
                                            navigateToTab(1)
                                        },
                                        onNavigateToRunning = { navigateToTab(2) },
                                        onNavigateToLogs = {
                                            showLogTopMenu = false
                                            secondaryRoute = SecondaryRoute.Logs
                                        }
                                    )
                                    1 -> AppListPage(
                                        viewModel = viewModel,
                                        config = config,
                                        scrollBehavior = tabScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        includeSystemApps = includeSystemApps,
                                        filterIndex = appFilterIndex,
                                        onFilterIndexChange = { appFilterIndex = it },
                                        onOpenAppConfig = { pkg, name ->
                                            secondaryRoute = SecondaryRoute.AppDetail(pkg, name)
                                        }
                                    )
                                    2 -> RunningListPage(
                                        viewModel = viewModel,
                                        scrollBehavior = tabScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onOpenAppConfig = { pkg, name ->
                                            secondaryRoute = SecondaryRoute.AppDetail(pkg, name)
                                        },
                                        onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                                    )
                                    3 -> SettingsPage(
                                        viewModel = viewModel,
                                        config = config,
                                        scrollBehavior = tabScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onNavigateToAppearance = {
                                            secondaryRoute = SecondaryRoute.Appearance
                                        },
                                        onNavigateToAbout = {
                                            secondaryRoute = SecondaryRoute.About
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // 悬浮底栏叠放层（位于 HorizontalPager 之上，胶囊区域实时折射/模糊下方滚过的列表内容）
                    if (config.floatingBottomBar) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(bottom = navInsetsBottom + 14.dp, start = 28.dp, end = 28.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (config.floatingBottomBarStyle == 1) {
                                LiquidGlassFloatingNavigationBar(
                                    pagerState = pagerState,
                                    iconOnly = config.bottomBarMode == 1,
                                    isDark = isDark,
                                    icons = navIcons,
                                    labels = navLabels,
                                    onSelect = { navigateToTab(it) },
                                    onBoundsChanged = { floatingBarBounds = it }
                                )
                            } else {
                                MiuixFloatingNavigationBar(
                                    pagerState = pagerState,
                                    iconOnly = config.bottomBarMode == 1,
                                    isDark = isDark,
                                    blurEnabled = blurEnabled,
                                    icons = navIcons,
                                    labels = navLabels,
                                    onSelect = { navigateToTab(it) },
                                    onBoundsChanged = { floatingBarBounds = it }
                                )
                            }
                        }
                    }
                }
            }

            if (effectiveMainParallax > 0.005f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = (if (isDark) 0.28f else 0.12f) * effectiveMainParallax))
                )
            }
        }

        // 2. 顶层二级页面导航容器（支持预测性返回手势缩放/圆角/视差预览 & 横移返回手势）
        AnimatedContent(
            targetState = secondaryRoute,
            transitionSpec = {
                val isPushing = targetState !is SecondaryRoute.None
                if (isPushing) {
                    (slideInHorizontally(
                        animationSpec = tween(durationMillis = 320, easing = MiuixNavEasing),
                        initialOffsetX = { fullWidth -> fullWidth }
                    ) togetherWith (slideOutHorizontally(
                        animationSpec = tween(durationMillis = 320, easing = MiuixNavEasing),
                        targetOffsetX = { fullWidth -> -fullWidth / 4 }
                    ) + fadeOut(animationSpec = tween(durationMillis = 320), targetAlpha = 0.9f))).apply {
                        targetContentZIndex = 1f
                    }
                } else {
                    (fadeIn(animationSpec = tween(durationMillis = 280)) togetherWith slideOutHorizontally(
                        animationSpec = tween(durationMillis = 300, easing = MiuixNavEasing),
                        targetOffsetX = { fullWidth -> fullWidth }
                    )).apply {
                        targetContentZIndex = 0f
                    }
                } using SizeTransform(clip = false)
            },
            label = "SecondaryNavDisplay"
        ) { subRoute ->
            when (subRoute) {
                is SecondaryRoute.None -> {
                    Box(modifier = Modifier.fillMaxSize())
                }

                is SecondaryRoute.AppDetail -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    SwipeAndPredictiveBackContainer(
                        swipeBackEnabled = config.swipeBackEnabled,
                        predictiveProgress = predictiveBackProgress,
                        predictiveEdge = predictiveBackEdge,
                        backgroundColor = surfaceBg,
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    ) {
                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = subRoute.appName,
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = { secondaryRoute = SecondaryRoute.None }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarAndBottomFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark,
                                        progressive = config.topBarBlurMode == 1,
                                        bottomRect = Rect.Zero,
                                        bottomStyle = 0
                                    )
                                    .background(surfaceBg)
                            ) {
                                AppConfigDialog(
                                    packageName = subRoute.packageName,
                                    appName = subRoute.appName,
                                    config = config,
                                    viewModel = viewModel,
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    onDismiss = { secondaryRoute = SecondaryRoute.None }
                                )
                            }
                        }
                    }
                }

                is SecondaryRoute.Logs -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    SwipeAndPredictiveBackContainer(
                        swipeBackEnabled = config.swipeBackEnabled,
                        predictiveProgress = predictiveBackProgress,
                        predictiveEdge = predictiveBackEdge,
                        backgroundColor = surfaceBg,
                        onBack = {
                            showLogTopMenu = false
                            secondaryRoute = SecondaryRoute.None
                        }
                    ) {
                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = "日志",
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = {
                                            showLogTopMenu = false
                                            secondaryRoute = SecondaryRoute.None
                                        }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    },
                                    actions = {
                                        TopMenuActionButton(
                                            active = showLogTopMenu,
                                            isDark = isDark,
                                            contentDescription = "日志选项",
                                            onClick = { showLogTopMenu = !showLogTopMenu }
                                        )
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            if (topBarHeight > 0.dp) {
                                logPageTopBarHeight = topBarHeight
                            }
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarAndBottomFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark,
                                        progressive = config.topBarBlurMode == 1,
                                        bottomRect = Rect.Zero,
                                        bottomStyle = 0
                                    )
                                    .background(surfaceBg)
                            ) {
                                LogPage(
                                    viewModel = viewModel,
                                    config = config,
                                    listState = logListState,
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding,
                                    filterLevel = logFilterLevel,
                                    onFilterLevelChange = { logFilterLevel = it }
                                )
                            }
                        }
                    }
                }

                is SecondaryRoute.Appearance -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    SwipeAndPredictiveBackContainer(
                        swipeBackEnabled = config.swipeBackEnabled,
                        predictiveProgress = predictiveBackProgress,
                        predictiveEdge = predictiveBackEdge,
                        backgroundColor = surfaceBg,
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    ) {
                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = "外观与主题",
                                    scrollBehavior = subScrollBehavior,
                                    color = topBarColor,
                                    navigationIcon = {
                                        IconButton(onClick = { secondaryRoute = SecondaryRoute.None }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight + 10.dp,
                                bottom = bottomBarHeight + 12.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .topBarAndBottomFrostedBlur(
                                        enabled = blurEnabled,
                                        topBarHeight = topBarHeight,
                                        surfaceColor = surfaceBg,
                                        isDark = isDark,
                                        progressive = config.topBarBlurMode == 1,
                                        bottomRect = Rect.Zero,
                                        bottomStyle = 0
                                    )
                                    .background(surfaceBg)
                            ) {
                                AppearancePage(
                                    viewModel = viewModel,
                                    config = config,
                                    scrollBehavior = subScrollBehavior,
                                    contentPadding = pageContentPadding
                                )
                            }
                        }
                    }
                }

                is SecondaryRoute.About -> {
                    val subScrollBehavior = MiuixScrollBehavior()
                    SwipeAndPredictiveBackContainer(
                        swipeBackEnabled = config.swipeBackEnabled,
                        predictiveProgress = predictiveBackProgress,
                        predictiveEdge = predictiveBackEdge,
                        backgroundColor = surfaceBg,
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    ) {
                        Scaffold(
                            topBar = {
                                SmallTopAppBar(
                                    title = "",
                                    scrollBehavior = subScrollBehavior,
                                    color = Color.Transparent,
                                    navigationIcon = {
                                        IconButton(onClick = { secondaryRoute = SecondaryRoute.None }) {
                                            Icon(
                                                imageVector = IconBack,
                                                contentDescription = "返回",
                                                tint = MiuixTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                )
                            }
                        ) { subPadding ->
                            val topBarHeight = subPadding.calculateTopPadding()
                            val bottomBarHeight = subPadding.calculateBottomPadding()
                            val pageContentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = topBarHeight,
                                bottom = bottomBarHeight + 20.dp
                            )
                            AboutPage(
                                scrollBehavior = subScrollBehavior,
                                contentPadding = pageContentPadding
                            )
                        }
                    }
                }
            }
        }

        diagnosticPair?.let { (pkg, reason) ->
            OverlayDialog(
                show = true,
                title = "诊断冻结状态",
                summary = pkg,
                onDismissRequest = { viewModel.dismissDiagnosticDialog() }
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = reason)
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(
                        text = "我知道了",
                        onClick = { viewModel.dismissDiagnosticDialog() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }

        // 应用列表右上角弹出菜单
        val safeFilterIndex = appFilterIndex.coerceIn(0, APP_FILTER_OPTIONS.lastIndex)
        MiuixTopPopupMenu(
            visible = showAppFilterSheet && secondaryRoute is SecondaryRoute.None && pagerState.currentPage == 1,
            onDismiss = { showAppFilterSheet = false },
            topOffset = appListTopBarHeight + 6.dp,
            width = 240.dp
        ) {
            APP_FILTER_OPTIONS.forEachIndexed { idx, label ->
                MiuixPopupOptionRow(
                    text = label,
                    selected = idx == safeFilterIndex,
                    onClick = {
                        appFilterIndex = idx
                        showAppFilterSheet = false
                    }
                )
            }

            MiuixPopupOptionRow(
                text = "显示系统应用",
                selected = includeSystemApps,
                onClick = {
                    includeSystemApps = !includeSystemApps
                    showAppFilterSheet = false
                }
            )
        }

        // 日志页右上角弹出菜单
        MiuixTopPopupMenu(
            visible = showLogTopMenu && secondaryRoute is SecondaryRoute.Logs,
            onDismiss = { showLogTopMenu = false },
            topOffset = logPageTopBarHeight + 6.dp,
            width = 228.dp
        ) {
            LogFilterLevel.entries.forEach { level ->
                MiuixPopupOptionRow(
                    text = level.label,
                    selected = level == logFilterLevel,
                    onClick = {
                        logFilterLevel = level
                        showLogTopMenu = false
                    }
                )
            }

            val currentFilteredLogs = filterLogLines(logs, config.logLevel, logFilterLevel)
            val displayedLogCount = currentFilteredLogs.size.coerceAtMost(MAX_DISPLAY_LOG_COUNT)

            MiuixPopupActionRow(
                text = "滚动到顶部",
                onClick = {
                    showLogTopMenu = false
                    if (displayedLogCount > 0) {
                        scope.launch { logListState.animateScrollToItem(0) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "滚动到底部",
                onClick = {
                    showLogTopMenu = false
                    if (displayedLogCount > 0) {
                        scope.launch { logListState.animateScrollToItem(displayedLogCount) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "导出日志文件",
                onClick = {
                    showLogTopMenu = false
                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    exportLogFileLauncher.launch("Smillet-Next_log_$ts.txt")
                }
            )
        }
    }
}

/**
 * 1:1 复刻 YuKongA/Mishka 的页面切换手势拦截器 (PagerInterceptionMode)：
 * - mode == 0 (跨轴拦截 CrossAxisInterceptor)：垂直滑动占优时锁定横向分量，杜绝上下快速翻看应用列表时误触切页；
 * - mode == 1 (类 iOS 点击急停 TapToHalt)：在跨轴拦截基础上，当页面正处于翻页滚动动画中时，手指按下即刻急停在当前页；
 * - mode == 2 (系统原生 Native)：保持 Compose 原生 HorizontalPager 滑动行为。
 */
private fun Modifier.pagerGestureInterceptor(
    mode: Int,
    pagerState: PagerState,
    onHaltScroll: () -> Unit
): Modifier {
    if (mode == 2) return this
    return this.pointerInput(mode, pagerState) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            if (mode == 1 && pagerState.isScrollInProgress && abs(pagerState.currentPageOffsetFraction) > 0.02f) {
                onHaltScroll()
            }
            var startPos = down.position
            var axisLocked: Int = 0 // 0 = undecided, 1 = vertical locked, 2 = horizontal allowed
            while (true) {
                val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                val change = event.changes.firstOrNull() ?: break
                if (!change.pressed) break
                val dx = abs(change.position.x - startPos.x)
                val dy = abs(change.position.y - startPos.y)
                if (axisLocked == 0 && (dx > 8f || dy > 8f)) {
                    axisLocked = if (dy > dx * 0.72f) 1 else 2
                }
                if (axisLocked == 1 && dx > 2f) {
                    // 垂直滚动占优时，抹除水平位移增量，阻止 HorizontalPager 抢夺手势
                    startPos = change.position
                }
            }
        }
    }
}

/**
 * 二级页预测性返回动画 + 任意位置横移返回容器
 */
@Composable
private fun SwipeAndPredictiveBackContainer(
    swipeBackEnabled: Boolean,
    predictiveProgress: Float,
    predictiveEdge: Int,
    backgroundColor: Color,
    onBack: () -> Unit,
    content: @Composable () -> Unit
) {
    var dragOffsetX by remember { mutableFloatStateOf(0f) }
    val animatedDragX by animateFloatAsState(
        targetValue = dragOffsetX,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "SwipeBackOffsetX"
    )

    val predScale = 1f - (predictiveProgress * 0.085f).coerceIn(0f, 0.12f)
    val predCorner = (predictiveProgress * 28f).coerceIn(0f, 28f).dp

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                val predShiftX = if (predictiveProgress > 0.001f) {
                    val dir = if (predictiveEdge == 0) 1f else -1f
                    dir * size.width * 0.18f * predictiveProgress + size.width * 0.16f * predictiveProgress
                } else {
                    0f
                }
                translationX = animatedDragX + predShiftX
                scaleX = predScale
                scaleY = predScale
                shape = RoundedCornerShape(predCorner)
                clip = predictiveProgress > 0.005f || animatedDragX > 1f
            }
            .background(backgroundColor)
            .then(
                if (swipeBackEnabled) {
                    Modifier.pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                if (dragOffsetX > size.width * 0.20f) {
                                    dragOffsetX = 0f
                                    onBack()
                                } else {
                                    dragOffsetX = 0f
                                }
                            },
                            onDragCancel = {
                                dragOffsetX = 0f
                            },
                            onHorizontalDrag = { change, dragAmount ->
                                val next = (dragOffsetX + dragAmount).coerceAtLeast(0f)
                                if (next > 0f) {
                                    change.consume()
                                }
                                dragOffsetX = next
                            }
                        )
                    }
                } else {
                    Modifier
                }
            )
    ) {
        content()
    }
}

/**
 * 1:1 复刻 YuKongA/Mishka 的 iOS 液态玻璃悬浮底栏 (LiquidGlassNavigationBar)：
 * - 胶囊底部由 BAR_BLUR_H/V_AGSL 实时对滚过下方的列表内容执行边缘透镜折射 (Lens Refraction) 与 1.42x 鲜亮饱和度增强 (Vibrancy)；
 * - 内部配备跟随 Pager 进度 (currentPage + currentPageOffsetFraction) 阻尼弹簧滑动的液态高光胶囊指示器与按压回弹动效。
 */
@Composable
private fun LiquidGlassFloatingNavigationBar(
    pagerState: PagerState,
    iconOnly: Boolean,
    isDark: Boolean,
    icons: List<ImageVector>,
    labels: List<String>,
    onSelect: (Int) -> Unit,
    onBoundsChanged: (Rect) -> Unit
) {
    val barHeight = if (iconOnly) 58.dp else 66.dp
    val primaryColor = MiuixTheme.colorScheme.primary
    val unselectedColor = if (isDark) Color.White.copy(alpha = 0.72f) else Color(0xFF3A3A44)

    val rawPagePosition by remember {
        derivedStateOf {
            (pagerState.currentPage + pagerState.currentPageOffsetFraction).coerceIn(0f, (icons.size - 1).toFloat())
        }
    }
    val smoothIndicatorPos by animateFloatAsState(
        targetValue = rawPagePosition,
        animationSpec = spring(
            dampingRatio = 0.78f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "LiquidPillPos"
    )
    // 滑动途中液态胶囊轻微横向拉伸形变
    val stretchFactor = 1f + abs(pagerState.currentPageOffsetFraction) * 0.24f

    val glassOverlayColor = if (isDark) {
        Color(0xFF282834).copy(alpha = 0.36f)
    } else {
        Color.White.copy(alpha = 0.32f)
    }
    val rimBrush = Brush.linearGradient(
        colors = if (isDark) {
            listOf(
                Color.White.copy(alpha = 0.36f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = 0.24f)
            )
        } else {
            listOf(
                Color.White.copy(alpha = 0.92f),
                Color.White.copy(alpha = 0.35f),
                Color.White.copy(alpha = 0.80f)
            )
        }
    )

    BoxWithConstraints(
        modifier = Modifier
            .widthIn(min = 250.dp, max = 356.dp)
            .fillMaxWidth()
            .height(barHeight)
            .onGloballyPositioned { coords ->
                onBoundsChanged(coords.boundsInRoot())
            }
            .shadow(
                elevation = if (isDark) 16.dp else 12.dp,
                shape = RoundedCornerShape(50),
                ambientColor = Color.Black.copy(alpha = 0.22f),
                spotColor = Color.Black.copy(alpha = 0.22f)
            )
            .clip(RoundedCornerShape(50))
            .background(glassOverlayColor)
            .border(width = 1.1.dp, brush = rimBrush, shape = RoundedCornerShape(50))
            .padding(horizontal = 6.dp, vertical = 5.dp)
    ) {
        val slotWidth = maxWidth / icons.size
        val pillWidth = slotWidth * stretchFactor
        val pillOffsetX = slotWidth * smoothIndicatorPos - (pillWidth - slotWidth) * 0.5f

        val pillFillBrush = Brush.verticalGradient(
            colors = if (isDark) {
                listOf(
                    Color.White.copy(alpha = 0.22f),
                    primaryColor.copy(alpha = 0.26f)
                )
            } else {
                listOf(
                    Color.White.copy(alpha = 0.88f),
                    primaryColor.copy(alpha = 0.16f)
                )
            }
        )
        val pillBorderColor = if (isDark) {
            Color.White.copy(alpha = 0.32f)
        } else {
            Color.White.copy(alpha = 0.95f)
        }

        // 1. 液态玻璃跟随胶囊指示器
        Box(
            modifier = Modifier
                .offset { IntOffset(x = pillOffsetX.roundToPx(), y = 0) }
                .width(pillWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(50))
                .background(pillFillBrush)
                .border(width = 0.85.dp, color = pillBorderColor, shape = RoundedCornerShape(50))
        )

        // 2. 导航项前景
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in icons.indices) {
                val selected = pagerState.currentPage == i
                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val itemScale by animateFloatAsState(
                    targetValue = when {
                        isPressed -> 0.88f
                        selected -> 1.04f
                        else -> 1.0f
                    },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium
                    ),
                    label = "LiquidItemScale"
                )
                val tint = if (selected) primaryColor else unselectedColor

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .graphicsLayer {
                            scaleX = itemScale
                            scaleY = itemScale
                        }
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = { onSelect(i) }
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icons[i],
                        contentDescription = labels[i],
                        tint = tint,
                        modifier = Modifier.size(if (iconOnly) 24.dp else 22.dp)
                    )
                    if (!iconOnly) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = labels[i],
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            color = tint
                        )
                    }
                }
            }
        }
    }
}

/**
 * 1:1 复刻 YuKongA/Mishka 的 Miuix 原生样式悬浮底栏 (FloatingBottomBarStyle.Miuix)
 */
@Composable
private fun MiuixFloatingNavigationBar(
    pagerState: PagerState,
    iconOnly: Boolean,
    isDark: Boolean,
    blurEnabled: Boolean,
    icons: List<ImageVector>,
    labels: List<String>,
    onSelect: (Int) -> Unit,
    onBoundsChanged: (Rect) -> Unit
) {
    val barHeight = if (iconOnly) 56.dp else 64.dp
    val primaryColor = MiuixTheme.colorScheme.primary
    val unselectedColor = MiuixTheme.colorScheme.onSurfaceVariantSummary
    val containerColor = if (blurEnabled) {
        if (isDark) Color(0xFF202026).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.60f)
    } else {
        if (isDark) Color(0xFF202026) else Color.White
    }
    val borderColor = if (isDark) Color.White.copy(alpha = 0.10f) else Color.Black.copy(alpha = 0.06f)

    Row(
        modifier = Modifier
            .widthIn(min = 248.dp, max = 348.dp)
            .fillMaxWidth()
            .height(barHeight)
            .onGloballyPositioned { coords ->
                onBoundsChanged(coords.boundsInRoot())
            }
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(32.dp),
                ambientColor = Color.Black.copy(alpha = 0.16f),
                spotColor = Color.Black.copy(alpha = 0.16f)
            )
            .clip(RoundedCornerShape(32.dp))
            .background(containerColor)
            .border(width = 0.6.dp, color = borderColor, shape = RoundedCornerShape(32.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in icons.indices) {
            val selected = pagerState.currentPage == i
            val interactionSource = remember { MutableInteractionSource() }
            val isPressed by interactionSource.collectIsPressedAsState()
            val scale by animateFloatAsState(
                targetValue = if (isPressed) 0.90f else 1.0f,
                animationSpec = spring(stiffness = Spring.StiffnessMedium),
                label = "MiuixFloatItemScale"
            )
            val tint = if (selected) primaryColor else unselectedColor
            val itemBg = if (selected) {
                primaryColor.copy(alpha = if (isDark) 0.18f else 0.12f)
            } else {
                Color.Transparent
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                    .clip(RoundedCornerShape(26.dp))
                    .background(itemBg)
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = { onSelect(i) }
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icons[i],
                    contentDescription = labels[i],
                    tint = tint,
                    modifier = Modifier.size(if (iconOnly) 24.dp else 22.dp)
                )
                if (!iconOnly) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = labels[i],
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        color = tint
                    )
                }
            }
        }
    }
}

/**
 * 标准非悬浮底栏的「仅图标 (BottomBarMode.IconOnly)」模式
 */
@Composable
private fun StandardIconOnlyBottomBar(
    selectedIndex: Int,
    isDark: Boolean,
    icons: List<ImageVector>,
    labels: List<String>,
    onSelect: (Int) -> Unit
) {
    val navInsetsPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val barBg = MiuixTheme.colorScheme.surface
    val primaryColor = MiuixTheme.colorScheme.primary
    val unselectedColor = MiuixTheme.colorScheme.onSurfaceVariantSummary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(barBg)
            .padding(bottom = navInsetsPadding, top = 6.dp)
            .height(50.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in icons.indices) {
            val selected = selectedIndex == i
            val tint = if (selected) primaryColor else unselectedColor
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { onSelect(i) }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icons[i],
                    contentDescription = labels[i],
                    tint = tint,
                    modifier = Modifier.size(25.dp)
                )
            }
        }
    }
}

@Composable
private fun Modifier.topBarAndBottomFrostedBlur(
    enabled: Boolean,
    topBarHeight: Dp,
    surfaceColor: Color,
    isDark: Boolean,
    progressive: Boolean,
    bottomRect: Rect,
    bottomStyle: Int
): Modifier {
    if (!enabled) return this
    val shaders = remember {
        runCatching {
            arrayOf(
                RuntimeShader(BAR_BLUR_H_AGSL),
                RuntimeShader(BAR_BLUR_V_TINT_AGSL),
                RuntimeShader(BAR_BLUR_H_AGSL),
                RuntimeShader(BAR_BLUR_V_TINT_AGSL),
                RuntimeShader(BAR_BLUR_H_AGSL),
                RuntimeShader(BAR_BLUR_V_TINT_AGSL)
            )
        }.getOrNull()
    }
    if (shaders == null) return this

    val progFlag = if (progressive) 1f else 0f
    val bStyleFlag = bottomStyle.toFloat()

    return this.graphicsLayer {
        val topPx = topBarHeight.toPx()
        val hasBottom = bottomStyle > 0 && bottomRect.width > 1f && bottomRect.height > 1f
        if (topPx > 0f || hasBottom) {
            compositingStrategy = CompositingStrategy.Offscreen

            val bLeft = if (hasBottom) bottomRect.left else 0f
            val bTop = if (hasBottom) bottomRect.top else 0f
            val bRight = if (hasBottom) bottomRect.right else 0f
            val bBottom = if (hasBottom) bottomRect.bottom else 0f
            val bRadius = if (hasBottom) (bottomRect.height * 0.5f) else 0f

            val steps = floatArrayOf(1.8f, 7.5f, 20.0f)
            val tintAlpha = if (isDark) 0.78f else 0.76f

            for (pass in 0..2) {
                val sH = shaders[pass * 2]
                val sV = shaders[pass * 2 + 1]
                val step = steps[pass]

                sH.setFloatUniform("topBarBottom", topPx)
                sH.setFloatUniform("stepSize", step)
                sH.setFloatUniform("progressive", progFlag)
                sH.setFloatUniform("bottomRect", bLeft, bTop, bRight, bBottom)
                sH.setFloatUniform("bottomRadius", bRadius)
                sH.setFloatUniform("bottomStyle", bStyleFlag)

                sV.setFloatUniform("topBarBottom", topPx)
                sV.setFloatUniform("stepSize", step)
                sV.setFloatUniform("progressive", progFlag)
                sV.setFloatUniform("bottomRect", bLeft, bTop, bRight, bBottom)
                sV.setFloatUniform("bottomRadius", bRadius)
                sV.setFloatUniform("bottomStyle", bStyleFlag)

                if (pass < 2) {
                    sV.setFloatUniform("surfaceTint", 0f, 0f, 0f, 0f)
                } else {
                    sV.setFloatUniform(
                        "surfaceTint",
                        surfaceColor.red,
                        surfaceColor.green,
                        surfaceColor.blue,
                        tintAlpha
                    )
                }
            }

            val p1 = AndroidRenderEffect.createRuntimeShaderEffect(shaders[0], "content")
            val p2 = AndroidRenderEffect.createRuntimeShaderEffect(shaders[1], "content")
            val p3 = AndroidRenderEffect.createRuntimeShaderEffect(shaders[2], "content")
            val p4 = AndroidRenderEffect.createRuntimeShaderEffect(shaders[3], "content")
            val p5 = AndroidRenderEffect.createRuntimeShaderEffect(shaders[4], "content")
            val p6 = AndroidRenderEffect.createRuntimeShaderEffect(shaders[5], "content")

            val c12 = AndroidRenderEffect.createChainEffect(p2, p1)
            val c123 = AndroidRenderEffect.createChainEffect(p3, c12)
            val c1234 = AndroidRenderEffect.createChainEffect(p4, c123)
            val c12345 = AndroidRenderEffect.createChainEffect(p5, c1234)
            val c123456 = AndroidRenderEffect.createChainEffect(p6, c12345)

            renderEffect = c123456.asComposeRenderEffect()
        }
    }
}

@Composable
private fun TopMenuActionButton(
    active: Boolean,
    isDark: Boolean,
    contentDescription: String,
    onClick: () -> Unit
) {
    val activeCircleColor = if (isDark) {
        Color.White.copy(alpha = 0.14f)
    } else {
        Color.Black.copy(alpha = 0.08f)
    }

    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) activeCircleColor else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = IconMoreCircle,
                contentDescription = contentDescription,
                tint = MiuixTheme.colorScheme.onSurface
            )
        }
    }
}
