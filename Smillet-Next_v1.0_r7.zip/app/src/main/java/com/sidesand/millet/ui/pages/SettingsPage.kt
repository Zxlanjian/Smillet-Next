package com.sidesand.millet.ui.pages

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    scrollBehavior: ScrollBehavior,
    contentPadding: PaddingValues
) {
    var showBackupDialog by remember { mutableStateOf(false) }
    var showPidWhyDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val json = viewModel.prefsManager.exportBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "备份文件已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "导出失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                    it.readText()
                }.orEmpty()
                if (viewModel.restoreFromBackupJson(text)) {
                    Toast.makeText(context, "已从文件恢复全部配置并同步生效", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "文件格式无效或 JSON 解析失败", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { err ->
                Toast.makeText(context, "读取备份文件失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val logLevels = listOf("debug", "info", "warn", "error")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SettingsSectionHeader(text = "冻结设置")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    OverlayDropdownPreference(
                        title = "冻结模式",
                        items = listOf("UID", "PID"),
                        selectedIndex = 0,
                        onSelectedIndexChange = { idx ->
                            if (idx == 1) {
                                showPidWhyDialog = true
                            }
                        }
                    )
                    OverlayDropdownPreference(
                        title = "电池优化模式",
                        items = listOf("按 App 配置", "系统默认"),
                        selectedIndex = if (config.blockAddPowerSaveWhitelistApps) 0 else 1,
                        onSelectedIndexChange = { idx ->
                            viewModel.updateBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, idx == 0)
                        }
                    )
                    SwitchPreference(
                        title = "屏蔽 Millet 杀后台",
                        checked = config.disableKill,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_KILL, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽充电解冻",
                        checked = config.disableCharge,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_CHARGE, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽音量解冻",
                        checked = config.disableVolume,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_VOLUME, it) }
                    )
                    SwitchPreference(
                        title = "记录电量变化",
                        checked = config.batteryChangeObserve,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, it)
                        }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "深度 Doze")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "息屏进入 DeepDoze",
                        checked = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.ENABLE_DOZE, it) }
                    )
                    SwitchPreference(
                        title = "跳过状态检查进入 DeepDoze",
                        checked = config.skipStateCheck,
                        enabled = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SKIP_STATE_CHECK, it) }
                    )
                    SwitchPreference(
                        title = "避免运动退出 DeepDoze",
                        checked = config.disableMotionListener,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, it)
                        }
                    )
                    SwitchPreference(
                        title = "开启 Doze 日志",
                        checked = config.dozeLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DOZE_LOG, it) }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "日志与备份")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "调试日志",
                        checked = config.isLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.IS_LOG, it) }
                    )
                    SwitchPreference(
                        title = "简化冻结日志",
                        checked = config.simplifyLog,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SIMPLIFY_LOG, it) }
                    )
                    OverlayDropdownPreference(
                        title = "日志级别",
                        items = logLevels,
                        selectedIndex = logLevels.indexOf(config.logLevel).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_LEVEL, logLevels[idx])
                        }
                    )
                    ArrowPreference(
                        title = "备份与恢复",
                        summary = "备份配置到 JSON 文件或从文件恢复",
                        onClick = { showBackupDialog = true }
                    )
                }
            }
        }
    }

    if (showPidWhyDialog) {
        OverlayDialog(
            show = true,
            title = "为什么冻结模式的 PID 无法选择？",
            summary = "HyperOS Greezer 与 Cgroup v2 冻结机制说明",
            onDismissRequest = { showPidWhyDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "1. 系统底层架构限制：\n小米 HyperOS 的原生墓碑服务 (GreezeManagerService) 与内核 Cgroup v2 Freezer (/sys/fs/cgroup/uid_<uid>/cgroup.freeze) 是按应用 UID 为最小原子粒度进行冻结与解冻调度的。\n\n" +
                        "2. 避免主子进程死锁与 ANR：\n同一应用的主进程与子进程（如推送服务、WebView 渲染进程）共享相同的 UID，存在高频的进程间 Binder 同步调用与共享文件锁。如果仅按 PID 单独冻结某一个子进程而主进程仍在运行，会导致主进程等待子进程响应超时，引发界面卡死与系统无响应 (ANR)。\n\n" +
                        "3. 结论：\n为保障系统稳定性与冻结彻底性，冻结模式固定为 UID 模式，不可切换为单 PID 模式。",
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(
                    text = "我知道了",
                    onClick = { showPidWhyDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary()
                )
            }
        }
    }

    if (showBackupDialog) {
        OverlayDialog(
            show = true,
            title = "本地备份",
            onDismissRequest = { showBackupDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                BackupActionRow(
                    title = "备份到文件",
                    icon = { IconBackupLayers(color = MiuixTheme.colorScheme.onSurface) },
                    onClick = {
                        showBackupDialog = false
                        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        exportFileLauncher.launch("Smillet-Next_backup_$ts.json")
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                BackupActionRow(
                    title = "从文件恢复",
                    icon = { IconRestoreFromFile(color = MiuixTheme.colorScheme.onSurface) },
                    onClick = {
                        showBackupDialog = false
                        importFileLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(
                    text = "取消",
                    onClick = { showBackupDialog = false },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun BackupActionRow(
    title: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(modifier = Modifier.width(18.dp))
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = MiuixTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        ChevronRightIcon(color = MiuixTheme.colorScheme.onSurfaceVariantSummary)
    }
}

@Composable
private fun IconBackupLayers(color: Color) {
    Canvas(modifier = Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(
            width = 1.9.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        val topLayer = Path().apply {
            moveTo(w * 0.50f, h * 0.14f)
            lineTo(w * 0.12f, h * 0.35f)
            lineTo(w * 0.50f, h * 0.56f)
            lineTo(w * 0.88f, h * 0.35f)
            close()
        }
        val midLayer = Path().apply {
            moveTo(w * 0.12f, h * 0.53f)
            lineTo(w * 0.50f, h * 0.73f)
            lineTo(w * 0.88f, h * 0.53f)
        }
        val botLayer = Path().apply {
            moveTo(w * 0.12f, h * 0.70f)
            lineTo(w * 0.50f, h * 0.90f)
            lineTo(w * 0.88f, h * 0.70f)
        }
        drawPath(topLayer, color = color, style = stroke)
        drawPath(midLayer, color = color, style = stroke)
        drawPath(botLayer, color = color, style = stroke)
    }
}

@Composable
private fun IconRestoreFromFile(color: Color) {
    Canvas(modifier = Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(
            width = 1.9.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        val boxPath = Path().apply {
            moveTo(w * 0.36f, h * 0.28f)
            lineTo(w * 0.36f, h * 0.24f)
            cubicTo(w * 0.36f, h * 0.16f, w * 0.42f, h * 0.12f, w * 0.50f, h * 0.12f)
            lineTo(w * 0.74f, h * 0.12f)
            cubicTo(w * 0.82f, h * 0.12f, w * 0.88f, h * 0.18f, w * 0.88f, h * 0.26f)
            lineTo(w * 0.88f, h * 0.74f)
            cubicTo(w * 0.88f, h * 0.82f, w * 0.82f, h * 0.88f, w * 0.74f, h * 0.88f)
            lineTo(w * 0.50f, h * 0.88f)
            cubicTo(w * 0.42f, h * 0.88f, w * 0.36f, h * 0.84f, w * 0.36f, h * 0.76f)
            lineTo(w * 0.36f, h * 0.72f)
        }
        val arrowPath = Path().apply {
            moveTo(w * 0.12f, h * 0.50f)
            lineTo(w * 0.64f, h * 0.50f)
            moveTo(w * 0.50f, h * 0.35f)
            lineTo(w * 0.65f, h * 0.50f)
            lineTo(w * 0.50f, h * 0.65f)
        }
        drawPath(boxPath, color = color, style = stroke)
        drawPath(arrowPath, color = color, style = stroke)
    }
}

@Composable
private fun ChevronRightIcon(color: Color) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.35f, h * 0.20f)
            lineTo(w * 0.68f, h * 0.50f)
            lineTo(w * 0.35f, h * 0.80f)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 1.8.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
private fun SettingsSectionHeader(text: String) {
    Text(
        text = text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        textAlign = TextAlign.Start,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, top = 6.dp, bottom = 2.dp)
    )
}
