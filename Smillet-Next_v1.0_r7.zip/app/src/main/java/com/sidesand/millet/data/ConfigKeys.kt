package com.sidesand.millet.data

object ConfigKeys {
    const val PREFS_NAME = "Settings"
    const val BINDER_ACTION = "SMillet-Binder"
    const val BINDER_KEY_SYSTEM = "system"
    const val LOCAL_LOG_PATH = "/data/system/SMillet/log"

    // 1. MilletSettings (墓碑核心配置)
    const val IS_LOG = "isLog"
    const val SIMPLIFY_LOG = "simplifyLog"
    const val DISABLE_KILL = "disableKill"
    const val DISABLE_VOLUME = "disableVolume"
    const val DISABLE_CHARGE = "disableCharge"
    const val BLOCK_ADD_POWERSAVE_WHITELIST = "blockAddPowerSaveWhitelistApps"
    const val BATTERY_CHANGE_OBSERVE = "batteryChangeObserve"

    // 2. DozeSettings (深度 Doze 配置)
    const val DOZE_LOG = "dozeLog"
    const val ENABLE_DOZE = "enableDoze"
    const val SKIP_STATE_CHECK = "skipStateCheck"
    const val DISABLE_MOTION_LISTENER = "disableMotionListener"

    // 3. BatteryOptSettings (系统电池优化白名单控制)
    const val BATTERY_OPT_WHITE_SET = "batteryOptWhiteSet"
    const val BATTERY_OPT_BLACK_SET = "batteryOptBlackSet"

    // 4. AppSettings (单应用墓碑策略集合)
    const val WHITE_APP_SET = "whiteAppSet"
    const val MESSAGE_APP_SET = "messageAppSet"
    const val FORCE_FREEZE_SET = "forceFreezeSet"
    const val BLOCK_THAW_SET = "blockThawSet"
    const val FORBID_SYNC_BINDER_SET = "forbidSyncBinderSet"
    const val NOT_FREEZE_WHEN_HAS_FGS_SET = "notFreezeWhenHasFgsSet"

    // 5. LogSettings (日志级别)
    const val LOG_LEVEL = "logLevel"

    // 默认不预置任何消息应用（避免重新安装时默认勾选微信 com.tencent.mm）
    val DEFAULT_MESSAGE_APPS = emptySet<String>()

    val ALLOWED_THAW_REASONS = listOf(
        "activity start",
        "notifi",
        "Activity Front",
        "FG activity",
        "tofront",
        "Sync Binder",
        "Check Binder",
        "Signal other",
        "Signal iso",
        "LAUNCH_MODE",
        "IMMOBULUS",
        "MediaButton",
        "receiver pkg",
        "PACKET",
        "cmd: thuid",
        "Net Change",
        "broadcast"
    )

    fun isAllowedThawReason(reason: String): Boolean {
        val trimmed = reason.trim()
        return ALLOWED_THAW_REASONS.any { it.equals(trimmed, ignoreCase = true) }
    }
}
