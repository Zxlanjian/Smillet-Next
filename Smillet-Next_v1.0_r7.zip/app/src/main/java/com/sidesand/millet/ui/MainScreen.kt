package com.sidesand.millet.ui

import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sidesand.millet.ui.components.MiuixPopupActionRow
import com.sidesand.millet.ui.components.MiuixPopupOptionRow
import com.sidesand.millet.ui.components.MiuixTopPopupMenu
import com.sidesand.millet.ui.pages.APP_FILTER_OPTIONS
import com.sidesand.millet.ui.pages.AppConfigDialog
import com.sidesand.millet.ui.pages.AppListPage
import com.sidesand.millet.ui.pages.HomePage
import com.sidesand.millet.ui.pages.LogFilterLevel
import com.sidesand.millet.ui.pages.LogPage
import com.sidesand.millet.ui.pages.RunningListPage
import com.sidesand.millet.ui.pages.SettingsPage
import com.sidesand.millet.ui.pages.filterLogLines
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 1:1 还原参考图片 (1000110451_53f0d8.png) 的 AGSL 连续渐进式高斯模糊着色器：
 * - 在顶栏及底部边缘过渡带 (0 .. blurEnd) 内按 smoothstep 曲线逐像素连续插值模糊半径与表面色调融合
 * - 模糊半径从 blurEnd 处的 0.0px 平滑过渡到顶栏内的 maxRadius，彻底消除任何矩形硬边界或分界线
 */
private const val PROGRESSIVE_TOP_BLUR_AGSL = """
    uniform shader content;
    uniform float blurStart;
    uniform float blurEnd;
    uniform float maxRadius;
    uniform float4 surfaceTint;

    half4 main(float2 fragCoord) {
        if (fragCoord.y >= blurEnd) {
            return content.eval(fragCoord);
        }
        float t = smoothstep(blurEnd, blurStart, fragCoord.y);
        float radius = t * maxRadius;
        if (radius < 0.35) {
            return content.eval(fragCoord);
        }

        half4 accum = half4(0.0);
        float weightSum = 0.0;
        float stepSize = radius * 0.28;

        for (int x = -3; x <= 3; x++) {
            for (int y = -3; y <= 3; y++) {
                float2 offset = float2(float(x), float(y)) * stepSize;
                float d2 = float(x * x + y * y);
                float w = exp(-d2 / 5.5);
                accum += content.eval(fragCoord + offset) * w;
                weightSum += w;
            }
        }
        half4 blurred = accum / weightSum;
        float tintFactor = t * t * surfaceTint.a;
        return mix(blurred, half4(surfaceTint.rgb, 1.0), tintFactor);
    }
"""

private sealed interface SubRoute {
    data object MainTabs : SubRoute
    data class AppDetail(val packageName: String, val appName: String) : SubRoute
    data object Logs : SubRoute
}

private val IconHome: ImageVector by lazy {
    ImageVector.Builder("Home", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(6.8f, 3.2f)
            horizontalLineTo(17.2f)
            curveTo(19.2f, 3.2f, 20.8f, 4.8f, 20.8f, 6.8f)
            verticalLineTo(17.2f)
            curveTo(20.8f, 19.2f, 19.2f, 20.8f, 17.2f, 20.8f)
            horizontalLineTo(6.8f)
            curveTo(4.8f, 20.8f, 3.2f, 19.2f, 3.2f, 17.2f)
            verticalLineTo(6.8f)
            curveTo(3.2f, 4.8f, 4.8f, 3.2f, 6.8f, 3.2f)
            close()
            moveTo(13.6f, 3.4f)
            verticalLineTo(20.6f)
        }
        path(fill = SolidColor(Color.Black)) {
            val cols = floatArrayOf(6.8f, 10.1f)
            val rows = floatArrayOf(7.8f, 12.0f, 16.2f)
            val r = 1.05f
            for (cx in cols) {
                for (cy in rows) {
                    moveTo(cx + r, cy)
                    curveTo(cx + r, cy + r * 0.55f, cx + r * 0.55f, cy + r, cx, cy + r)
                    curveTo(cx - r * 0.55f, cy + r, cx - r, cy + r * 0.55f, cx - r, cy)
                    curveTo(cx - r, cy - r * 0.55f, cx - r * 0.55f, cy - r, cx, cy - r)
                    curveTo(cx + r * 0.55f, cy - r, cx + r, cy - r * 0.55f, cx + r, cy)
                    close()
                }
            }
        }
    }.build()
}

private val IconAppList: ImageVector by lazy {
    ImageVector.Builder("AppList", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.95f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(7.0f, 2.8f)
            horizontalLineTo(17.0f)
            curveTo(18.8f, 2.8f, 20.2f, 4.2f, 20.2f, 6.0f)
            verticalLineTo(15.2f)
            lineTo(14.4f, 21.2f)
            horizontalLineTo(7.0f)
            curveTo(5.2f, 21.2f, 3.8f, 19.8f, 3.8f, 18.0f)
            verticalLineTo(6.0f)
            curveTo(3.8f, 4.2f, 5.2f, 2.8f, 7.0f, 2.8f)
            close()
            moveTo(14.2f, 21.0f)
            verticalLineTo(16.6f)
            curveTo(14.2f, 15.6f, 15.0f, 14.8f, 16.0f, 14.8f)
            horizontalLineTo(20.0f)
            moveTo(8.0f, 8.2f)
            horizontalLineTo(16.0f)
            moveTo(8.0f, 12.0f)
            horizontalLineTo(13.4f)
        }
    }.build()
}

private val IconRunningCheck: ImageVector by lazy {
    ImageVector.Builder("RunningCheck", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            fill = SolidColor(Color.Black),
            pathFillType = PathFillType.EvenOdd
        ) {
            moveTo(7.0f, 3.0f)
            horizontalLineTo(17.0f)
            curveTo(19.2f, 3.0f, 21.0f, 4.8f, 21.0f, 7.0f)
            verticalLineTo(17.0f)
            curveTo(21.0f, 19.2f, 19.2f, 21.0f, 17.0f, 21.0f)
            horizontalLineTo(7.0f)
            curveTo(4.8f, 21.0f, 3.0f, 19.2f, 3.0f, 17.0f)
            verticalLineTo(7.0f)
            curveTo(3.0f, 4.8f, 4.8f, 3.0f, 7.0f, 3.0f)
            close()
            moveTo(10.4f, 16.4f)
            lineTo(6.7f, 12.7f)
            lineTo(8.2f, 11.2f)
            lineTo(10.4f, 13.4f)
            lineTo(15.8f, 8.0f)
            lineTo(17.3f, 9.5f)
            close()
        }
    }.build()
}

private val IconHexSettings: ImageVector by lazy {
    ImageVector.Builder("HexSettings", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(12.0f, 2.7f)
            lineTo(19.8f, 7.2f)
            verticalLineTo(16.8f)
            lineTo(12.0f, 21.3f)
            lineTo(4.2f, 16.8f)
            verticalLineTo(7.2f)
            close()
            val r = 3.1f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.55f, 12f + r * 0.55f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.55f, 12f + r, 12f - r, 12f + r * 0.55f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.55f, 12f - r * 0.55f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.55f, 12f - r, 12f + r, 12f - r * 0.55f, 12f + r, 12f)
            close()
        }
    }.build()
}

private val IconMoreCircle: ImageVector by lazy {
    ImageVector.Builder("MoreCircle", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.85f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            val r = 9.0f
            moveTo(12f + r, 12f)
            curveTo(12f + r, 12f + r * 0.552f, 12f + r * 0.552f, 12f + r, 12f, 12f + r)
            curveTo(12f - r * 0.552f, 12f + r, 12f - r, 12f + r * 0.552f, 12f - r, 12f)
            curveTo(12f - r, 12f - r * 0.552f, 12f - r * 0.552f, 12f - r, 12f, 12f - r)
            curveTo(12f + r * 0.552f, 12f - r, 12f + r, 12f - r * 0.552f, 12f + r, 12f)
            close()
        }
        path(fill = SolidColor(Color.Black)) {
            val xs = floatArrayOf(8.2f, 12.0f, 15.8f)
            val dotR = 1.15f
            for (cx in xs) {
                moveTo(cx + dotR, 12f)
                curveTo(cx + dotR, 12f + dotR * 0.55f, cx + dotR * 0.55f, 12f + dotR, cx, 12f + dotR)
                curveTo(cx - dotR * 0.55f, 12f + dotR, cx - dotR, 12f + dotR * 0.55f, cx - dotR, 12f)
                curveTo(cx - dotR, 12f - dotR * 0.55f, cx - dotR * 0.55f, 12f - dotR, cx, 12f - dotR)
                curveTo(cx + dotR * 0.55f, 12f - dotR, cx + dotR, 12f - dotR * 0.55f, cx + dotR, 12f)
                close()
            }
        }
    }.build()
}

private val IconRefresh: ImageVector by lazy {
    ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.0f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(18.2f, 7.6f)
            curveTo(16.8f, 5.6f, 14.5f, 4.4f, 12.0f, 4.4f)
            curveTo(7.8f, 4.4f, 4.4f, 7.8f, 4.4f, 12.0f)
            curveTo(4.4f, 16.2f, 7.8f, 19.6f, 12.0f, 19.6f)
            curveTo(15.6f, 19.6f, 18.6f, 17.1f, 19.4f, 13.7f)
            moveTo(18.6f, 4.4f)
            verticalLineTo(8.2f)
            horizontalLineTo(14.8f)
        }
    }.build()
}

private val IconBack: ImageVector by lazy {
    ImageVector.Builder("Back", 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.1f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        ) {
            moveTo(14.8f, 5.8f)
            lineTo(8.6f, 12.0f)
            lineTo(14.8f, 18.2f)
        }
    }.build()
}

@Composable
fun MainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppForConfig by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showLogPage by remember { mutableStateOf(false) }

    var showAppFilterSheet by remember { mutableStateOf(false) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appFilterIndex by remember { mutableIntStateOf(0) }

    var logFilterLevel by remember { mutableStateOf(LogFilterLevel.ALL) }
    var showLogTopMenu by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val config by viewModel.config.collectAsState()
    val logs by viewModel.logsList.collectAsState()
    val isSystemActive by viewModel.isSystemActive.collectAsState()
    val isPkActive by viewModel.isPowerKeeperActive.collectAsState()
    val diagnosticPair by viewModel.diagnosticDialogText.collectAsState()

    val mainScrollBehavior = MiuixScrollBehavior()
    val subPageScrollBehavior = MiuixScrollBehavior()
    val tabTitles = listOf("Smillet-Next", "应用列表", "运行列表", "设置")
    val isDark = isSystemInDarkTheme()
    val surfaceBg = MiuixTheme.colorScheme.background

    var latestTopBarHeight by remember { mutableStateOf(96.dp) }

    // 导出日志文件：同步备份导出逻辑，调用系统文件选择器由用户自行选择保存路径
    val exportLogFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val currentFiltered = filterLogLines(logs, config.logLevel, logFilterLevel)
                val content = if (currentFiltered.isEmpty()) {
                    "暂无日志记录\n"
                } else {
                    currentFiltered.joinToString("\n") + "\n"
                }
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "日志文件已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "导出日志失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler(enabled = showAppFilterSheet || showLogTopMenu || selectedAppForConfig != null || showLogPage) {
        when {
            showAppFilterSheet -> showAppFilterSheet = false
            showLogTopMenu -> showLogTopMenu = false
            selectedAppForConfig != null -> selectedAppForConfig = null
            showLogPage -> showLogPage = false
        }
    }

    val currentRoute: SubRoute = remember(selectedAppForConfig, showLogPage) {
        val activeApp = selectedAppForConfig
        when {
            activeApp != null -> SubRoute.AppDetail(activeApp.first, activeApp.second)
            showLogPage -> SubRoute.Logs
            else -> SubRoute.MainTabs
        }
    }

    // 最外层根 Box：将右上角菜单置于 Scaffold 之上，使菜单展开时的压暗遮罩同时对顶栏标题与正文生效
    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                AnimatedContent(
                    targetState = currentRoute,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                    },
                    label = "TopBarTransition"
                ) { route ->
                    when (route) {
                        is SubRoute.AppDetail -> {
                            SmallTopAppBar(
                                title = route.appName,
                                scrollBehavior = subPageScrollBehavior,
                                color = Color.Transparent,
                                navigationIcon = {
                                    IconButton(onClick = { selectedAppForConfig = null }) {
                                        Icon(
                                            imageVector = IconBack,
                                            contentDescription = "返回",
                                            tint = MiuixTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            )
                        }
                        is SubRoute.Logs -> {
                            SmallTopAppBar(
                                title = "日志",
                                scrollBehavior = subPageScrollBehavior,
                                color = Color.Transparent,
                                navigationIcon = {
                                    IconButton(onClick = {
                                        showLogTopMenu = false
                                        showLogPage = false
                                    }) {
                                        Icon(
                                            imageVector = IconBack,
                                            contentDescription = "返回",
                                            tint = MiuixTheme.colorScheme.onSurface
                                        )
                                    }
                                },
                                actions = {
                                    TopMenuActionButton(
                                        active = showLogTopMenu,
                                        isDark = isDark,
                                        contentDescription = "日志选项",
                                        onClick = { showLogTopMenu = !showLogTopMenu }
                                    )
                                }
                            )
                        }
                        is SubRoute.MainTabs -> {
                            TopAppBar(
                                title = tabTitles[selectedTab],
                                scrollBehavior = mainScrollBehavior,
                                color = Color.Transparent,
                                actions = {
                                    when (selectedTab) {
                                        1 -> {
                                            TopMenuActionButton(
                                                active = showAppFilterSheet,
                                                isDark = isDark,
                                                contentDescription = "筛选",
                                                onClick = { showAppFilterSheet = !showAppFilterSheet }
                                            )
                                        }
                                        2 -> {
                                            IconButton(onClick = { viewModel.connectAndRefresh(includeSystemApps) }) {
                                                Icon(
                                                    imageVector = IconRefresh,
                                                    contentDescription = "刷新",
                                                    tint = MiuixTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            },
            bottomBar = {
                if (currentRoute is SubRoute.MainTabs) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = {
                                showAppFilterSheet = false
                                selectedTab = 0
                            },
                            icon = IconHome,
                            label = "主页"
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = IconAppList,
                            label = "应用列表"
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = {
                                showAppFilterSheet = false
                                selectedTab = 2
                                viewModel.refreshRunningApps(includeSystemApps)
                            },
                            icon = IconRunningCheck,
                            label = "运行列表"
                        )
                        NavigationBarItem(
                            selected = selectedTab == 3,
                            onClick = {
                                showAppFilterSheet = false
                                selectedTab = 3
                            },
                            icon = IconHexSettings,
                            label = "设置"
                        )
                    }
                }
            }
        ) { innerPadding ->
            val topBarHeight = innerPadding.calculateTopPadding()
            if (topBarHeight > 0.dp) {
                latestTopBarHeight = topBarHeight
            }
            val bottomBarHeight = innerPadding.calculateBottomPadding()
            val pageContentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = topBarHeight + 10.dp,
                bottom = bottomBarHeight + 12.dp
            )

            // 使用 AGSL RuntimeShader 对进入顶栏及边缘区域的滚动内容施加连续渐进式高斯模糊，无任何分界线
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .progressiveTopBarBlur(
                        topBarHeight = topBarHeight,
                        surfaceColor = surfaceBg,
                        isDark = isDark
                    )
            ) {
                AnimatedContent(
                    targetState = currentRoute,
                    transitionSpec = {
                        val isEnteringSubPage = targetState !is SubRoute.MainTabs
                        if (isEnteringSubPage) {
                            (slideInHorizontally(
                                animationSpec = tween(260, easing = FastOutSlowInEasing),
                                initialOffsetX = { fullWidth -> fullWidth / 4 }
                            ) + fadeIn(animationSpec = tween(220))) togetherWith
                                (slideOutHorizontally(
                                    animationSpec = tween(240, easing = FastOutSlowInEasing),
                                    targetOffsetX = { fullWidth -> -fullWidth / 10 }
                                ) + fadeOut(animationSpec = tween(180)))
                        } else {
                            (slideInHorizontally(
                                animationSpec = tween(250, easing = FastOutSlowInEasing),
                                initialOffsetX = { fullWidth -> -fullWidth / 10 }
                            ) + fadeIn(animationSpec = tween(220))) togetherWith
                                (slideOutHorizontally(
                                    animationSpec = tween(230, easing = FastOutSlowInEasing),
                                    targetOffsetX = { fullWidth -> fullWidth / 4 }
                                ) + fadeOut(animationSpec = tween(180)))
                        }
                    },
                    label = "PageRouteTransition"
                ) { route ->
                    when (route) {
                        is SubRoute.AppDetail -> {
                            AppConfigDialog(
                                packageName = route.packageName,
                                appName = route.appName,
                                config = config,
                                viewModel = viewModel,
                                scrollBehavior = subPageScrollBehavior,
                                contentPadding = pageContentPadding,
                                onDismiss = { selectedAppForConfig = null }
                            )
                        }
                        is SubRoute.Logs -> {
                            LogPage(
                                viewModel = viewModel,
                                config = config,
                                listState = logListState,
                                scrollBehavior = subPageScrollBehavior,
                                contentPadding = pageContentPadding,
                                filterLevel = logFilterLevel,
                                onFilterLevelChange = { logFilterLevel = it }
                            )
                        }
                        is SubRoute.MainTabs -> {
                            Crossfade(targetState = selectedTab, label = "MainTabs") { tab ->
                                when (tab) {
                                    0 -> HomePage(
                                        viewModel = viewModel,
                                        config = config,
                                        isSystemActive = isSystemActive,
                                        isPowerKeeperActive = isPkActive,
                                        scrollBehavior = mainScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onNavigateToWhitelist = {
                                            appFilterIndex = 2
                                            selectedTab = 1
                                        },
                                        onNavigateToBlacklist = {
                                            appFilterIndex = 3
                                            selectedTab = 1
                                        },
                                        onNavigateToRunning = { selectedTab = 2 },
                                        onNavigateToLogs = {
                                            showLogTopMenu = false
                                            showLogPage = true
                                        }
                                    )
                                    1 -> AppListPage(
                                        viewModel = viewModel,
                                        config = config,
                                        scrollBehavior = mainScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        includeSystemApps = includeSystemApps,
                                        filterIndex = appFilterIndex,
                                        onFilterIndexChange = { appFilterIndex = it },
                                        onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name }
                                    )
                                    2 -> RunningListPage(
                                        viewModel = viewModel,
                                        scrollBehavior = mainScrollBehavior,
                                        contentPadding = pageContentPadding,
                                        onOpenAppConfig = { pkg, name -> selectedAppForConfig = pkg to name },
                                        onDiagnoseApp = { pkg -> viewModel.requestDiagnoseApp(pkg) }
                                    )
                                    3 -> SettingsPage(
                                        viewModel = viewModel,
                                        config = config,
                                        scrollBehavior = mainScrollBehavior,
                                        contentPadding = pageContentPadding
                                    )
                                }
                            }
                        }
                    }
                }

                diagnosticPair?.let { (pkg, reason) ->
                    OverlayDialog(
                        show = true,
                        title = "诊断冻结状态",
                        summary = pkg,
                        onDismissRequest = { viewModel.dismissDiagnosticDialog() }
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(text = reason)
                            Spacer(modifier = Modifier.height(16.dp))
                            TextButton(
                                text = "我知道了",
                                onClick = { viewModel.dismissDiagnosticDialog() },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.textButtonColorsPrimary()
                            )
                        }
                    }
                }
            }
        }

        // 应用列表右上角弹出菜单（置于根 Box 最顶层，压暗遮罩对顶栏标题同样生效）
        val safeFilterIndex = appFilterIndex.coerceIn(0, APP_FILTER_OPTIONS.lastIndex)
        MiuixTopPopupMenu(
            visible = showAppFilterSheet && currentRoute is SubRoute.MainTabs && selectedTab == 1,
            onDismiss = { showAppFilterSheet = false },
            topOffset = latestTopBarHeight + 6.dp,
            width = 240.dp
        ) {
            APP_FILTER_OPTIONS.forEachIndexed { idx, label ->
                MiuixPopupOptionRow(
                    text = label,
                    selected = idx == safeFilterIndex,
                    onClick = {
                        appFilterIndex = idx
                        showAppFilterSheet = false
                    }
                )
            }

            MiuixPopupOptionRow(
                text = "显示系统应用",
                selected = includeSystemApps,
                onClick = {
                    includeSystemApps = !includeSystemApps
                    showAppFilterSheet = false
                }
            )
        }

        // 日志页右上角弹出菜单（置于根 Box 最顶层，压暗遮罩对顶栏标题同样生效）
        MiuixTopPopupMenu(
            visible = showLogTopMenu && currentRoute is SubRoute.Logs,
            onDismiss = { showLogTopMenu = false },
            topOffset = latestTopBarHeight + 6.dp,
            width = 228.dp
        ) {
            LogFilterLevel.entries.forEach { level ->
                MiuixPopupOptionRow(
                    text = level.label,
                    selected = level == logFilterLevel,
                    onClick = {
                        logFilterLevel = level
                        showLogTopMenu = false
                    }
                )
            }

            val currentFilteredLogs = filterLogLines(logs, config.logLevel, logFilterLevel)

            MiuixPopupActionRow(
                text = "滚动到顶部",
                onClick = {
                    showLogTopMenu = false
                    if (currentFilteredLogs.isNotEmpty()) {
                        scope.launch { logListState.animateScrollToItem(0) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "滚动到底部",
                onClick = {
                    showLogTopMenu = false
                    if (currentFilteredLogs.isNotEmpty()) {
                        scope.launch { logListState.animateScrollToItem(currentFilteredLogs.size - 1) }
                    }
                }
            )
            MiuixPopupActionRow(
                text = "导出日志文件",
                onClick = {
                    showLogTopMenu = false
                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    exportLogFileLauncher.launch("Smillet-Next_log_$ts.txt")
                }
            )
        }
    }
}

/**
 * 1:1 还原参考图片 (1000110451_53f0d8.png) 的连续渐进式顶栏背景模糊与边缘模糊：
 * 通过 Android 13+ 原生 AGSL RuntimeShader 在单一图层上按 Y 坐标平滑插值高斯模糊半径，不产生任何矩形分界线
 */
@Composable
private fun Modifier.progressiveTopBarBlur(
    topBarHeight: Dp,
    surfaceColor: Color,
    isDark: Boolean
): Modifier {
    val runtimeShader = remember {
        runCatching { RuntimeShader(PROGRESSIVE_TOP_BLUR_AGSL) }.getOrNull()
    }
    if (runtimeShader == null) return this

    return this.graphicsLayer {
        val topPx = topBarHeight.toPx()
        if (topPx > 0f) {
            compositingStrategy = CompositingStrategy.Offscreen
            val edgeFeatherPx = 28.dp.toPx()
            val blurStartPx = (topPx * 0.42f).coerceAtLeast(1f)
            val blurEndPx = topPx + edgeFeatherPx
            runtimeShader.setFloatUniform("blurStart", blurStartPx)
            runtimeShader.setFloatUniform("blurEnd", blurEndPx)
            runtimeShader.setFloatUniform("maxRadius", 26.dp.toPx())
            val tintAlpha = if (isDark) 0.72f else 0.76f
            runtimeShader.setFloatUniform(
                "surfaceTint",
                surfaceColor.red,
                surfaceColor.green,
                surfaceColor.blue,
                tintAlpha
            )
            renderEffect = AndroidRenderEffect
                .createRuntimeShaderEffect(runtimeShader, "content")
                .asComposeRenderEffect()
        }
    }
}

@Composable
private fun TopMenuActionButton(
    active: Boolean,
    isDark: Boolean,
    contentDescription: String,
    onClick: () -> Unit
) {
    val activeCircleColor = if (isDark) {
        Color.White.copy(alpha = 0.14f)
    } else {
        Color.Black.copy(alpha = 0.08f)
    }

    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) activeCircleColor else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = IconMoreCircle,
                contentDescription = contentDescription,
                tint = MiuixTheme.colorScheme.onSurface
            )
        }
    }
}
