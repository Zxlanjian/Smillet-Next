package com.sidesand.millet.ui.pages

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import com.sidesand.millet.ui.MainViewModel
import com.sidesand.millet.ui.theme.LocalAppDarkMode
import com.sidesand.millet.ui.theme.ThemeConfig
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.ScrollBehavior
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsPage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    scrollBehavior: ScrollBehavior,
    contentPadding: PaddingValues,
    onNavigateToAppearance: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    var showBackupDialog by remember { mutableStateOf(false) }
    var showPidWhyDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val json = viewModel.prefsManager.exportBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "备份文件已成功导出", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(context, "导出失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                    it.readText()
                }.orEmpty()
                if (viewModel.restoreFromBackupJson(text)) {
                    Toast.makeText(context, "已从文件恢复全部配置并同步生效", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "文件格式无效或 JSON 解析失败", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { err ->
                Toast.makeText(context, "读取备份文件失败：${err.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val logLevels = listOf("debug", "info", "warn", "error")
    val logLevelSummary = when (config.logLevel.lowercase(Locale.ROOT)) {
        "debug" -> "调试档位：输出完整调试日志、UID/PID 冻结明细与 Doze 状态流转"
        "info" -> "常规档位：输出精简冻结解冻状态与待机省电记录"
        "warn" -> "警告档位：仅输出后台异常唤醒拦截与警告信息"
        "error" -> "错误档位：仅输出运行异常与错误日志"
        else -> "常规档位：输出精简冻结解冻状态与待机省电记录"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SettingsSectionHeader(text = "冻结设置")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    OverlayDropdownPreference(
                        title = "冻结模式",
                        items = listOf("UID", "PID"),
                        selectedIndex = 0,
                        onSelectedIndexChange = { idx ->
                            if (idx == 1) {
                                showPidWhyDialog = true
                            }
                        }
                    )
                    OverlayDropdownPreference(
                        title = "电池优化模式",
                        items = listOf("按 App 配置", "系统默认"),
                        selectedIndex = if (config.blockAddPowerSaveWhitelistApps) 0 else 1,
                        onSelectedIndexChange = { idx ->
                            viewModel.updateBoolean(ConfigKeys.BLOCK_ADD_POWERSAVE_WHITELIST, idx == 0)
                        }
                    )
                    SwitchPreference(
                        title = "屏蔽 Millet 杀后台",
                        checked = config.disableKill,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_KILL, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽充电解冻",
                        checked = config.disableCharge,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_CHARGE, it) }
                    )
                    SwitchPreference(
                        title = "屏蔽音量解冻",
                        checked = config.disableVolume,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.DISABLE_VOLUME, it) }
                    )
                    SwitchPreference(
                        title = "记录电量变化",
                        checked = config.batteryChangeObserve,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BATTERY_CHANGE_OBSERVE, it)
                        }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "深度 Doze")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "息屏进入 DeepDoze",
                        checked = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.ENABLE_DOZE, it) }
                    )
                    SwitchPreference(
                        title = "跳过状态检查进入 DeepDoze",
                        checked = config.skipStateCheck,
                        enabled = config.enableDoze,
                        onCheckedChange = { viewModel.updateBoolean(ConfigKeys.SKIP_STATE_CHECK, it) }
                    )
                    SwitchPreference(
                        title = "避免运动退出 DeepDoze",
                        checked = config.disableMotionListener,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.DISABLE_MOTION_LISTENER, it)
                        }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "日志与备份")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    OverlayDropdownPreference(
                        title = "日志级别",
                        summary = logLevelSummary,
                        items = logLevels,
                        selectedIndex = logLevels.indexOf(config.logLevel.lowercase(Locale.ROOT)).coerceAtLeast(0),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateString(ConfigKeys.LOG_LEVEL, logLevels[idx])
                        }
                    )
                    ArrowPreference(
                        title = "备份与恢复",
                        summary = "备份配置到 JSON 文件或从文件恢复",
                        onClick = { showBackupDialog = true }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "外观与关于")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    ArrowPreference(
                        title = "外观与主题",
                        summary = ThemeConfig.summaryForConfig(config),
                        onClick = onNavigateToAppearance
                    )
                    ArrowPreference(
                        title = "关于",
                        summary = "Smillet-Next v1.0 · 架构致谢与开源许可",
                        onClick = onNavigateToAbout
                    )
                }
            }
        }
    }

    if (showPidWhyDialog) {
        OverlayDialog(
            show = true,
            title = "为什么冻结模式的 PID 无法选择？",
            summary = "HyperOS Greezer 与 Cgroup v2 冻结机制说明",
            onDismissRequest = { showPidWhyDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "1. 系统底层架构限制：\n小米 HyperOS 的原生墓碑服务 (GreezeManagerService) 与内核 Cgroup v2 Freezer (/sys/fs/cgroup/uid_<uid>/cgroup.freeze) 是按应用 UID 为最小原子粒度进行冻结与解冻调度的。\n\n" +
                        "2. 避免主子进程死锁与 ANR：\n同一应用的主进程与子进程（如推送服务、WebView 渲染进程）共享相同的 UID，存在高频的进程间 Binder 同步调用与共享文件锁。如果仅按 PID 单独冻结某一个子进程而主进程仍在运行，会导致主进程等待子进程响应超时，引发界面卡死与系统无响应 (ANR)。\n\n" +
                        "3. 结论：\n为保障系统稳定性与冻结彻底性，冻结模式固定为 UID 模式，不可切换为单 PID 模式。",
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(
                    text = "我知道了",
                    onClick = { showPidWhyDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary()
                )
            }
        }
    }

    if (showBackupDialog) {
        OverlayDialog(
            show = true,
            title = "本地备份",
            onDismissRequest = { showBackupDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                BackupActionRow(
                    title = "备份到文件",
                    icon = { IconBackupLayers(color = MiuixTheme.colorScheme.onSurface) },
                    onClick = {
                        showBackupDialog = false
                        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        exportFileLauncher.launch("Smillet-Next_backup_$ts.json")
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                BackupActionRow(
                    title = "从文件恢复",
                    icon = { IconRestoreFromFile(color = MiuixTheme.colorScheme.onSurface) },
                    onClick = {
                        showBackupDialog = false
                        importFileLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(
                    text = "取消",
                    onClick = { showBackupDialog = false },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

/**
 * 1:1 参考 YuKongA/Mishka 实现的「外观与主题」二级页面：
 * 支持深浅色模式（跟随系统/浅色/深色）、Monet 动态取色、自定义种子色、顶栏/底栏毛玻璃开关、平滑圆角开关以及隐藏最近任务卡片。
 */
@Composable
fun AppearancePage(
    viewModel: MainViewModel,
    config: MilletConfigSnapshot,
    scrollBehavior: ScrollBehavior,
    contentPadding: PaddingValues
) {
    val paletteLabels = remember { ThemeConfig.MONET_PALETTE_OPTIONS.map { it.first } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SettingsSectionHeader(text = "主题与色彩")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    OverlayDropdownPreference(
                        title = "深浅色模式",
                        summary = "控制应用全局深浅色表现，支持跟随系统或强制指定",
                        items = ThemeConfig.COLOR_MODE_LABELS,
                        selectedIndex = config.themeColorMode.coerceIn(0, 2),
                        onSelectedIndexChange = { idx ->
                            viewModel.updateInt(ConfigKeys.THEME_COLOR_MODE, idx)
                        }
                    )
                    SwitchPreference(
                        title = "Monet 动态取色",
                        summary = "启用动态色彩生成，使界面强调色与运行中状态卡片跟随动态色板",
                        checked = config.monetEnabled,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.MONET_ENABLED, it)
                        }
                    )
                    OverlayDropdownPreference(
                        title = "动态取色基准色",
                        summary = "选择 Monet 色板种子色（默认从系统壁纸提取）",
                        items = paletteLabels,
                        selectedIndex = config.monetColorIndex.coerceIn(0, paletteLabels.lastIndex),
                        enabled = config.monetEnabled,
                        onSelectedIndexChange = { idx ->
                            viewModel.updateInt(ConfigKeys.MONET_COLOR_INDEX, idx)
                        }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "界面与材质")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "高级材质毛玻璃",
                        summary = "为顶栏与底栏开启实时高斯毛玻璃模糊效果",
                        checked = config.blurEnabled,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.BLUR_ENABLED, it)
                        }
                    )
                    SwitchPreference(
                        title = "平滑圆角 (Squircle)",
                        summary = "启用 Miuix G2 连续曲率超椭圆平滑圆角表面",
                        checked = config.smoothCornerEnabled,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.SMOOTH_CORNER_ENABLED, it)
                        }
                    )
                }
            }
        }

        item {
            SettingsSectionHeader(text = "多任务与系统")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SwitchPreference(
                        title = "隐藏最近任务卡片",
                        summary = "在系统最近任务切换视图中隐藏本应用卡片（即时生效）",
                        checked = config.hideTaskCard,
                        onCheckedChange = {
                            viewModel.updateBoolean(ConfigKeys.HIDE_TASK_CARD, it)
                        }
                    )
                }
            }
        }
    }
}

/**
 * 1:1 参考 YuKongA/Mishka 实现的「关于」二级页面：
 * 包含随 LocalAppDarkMode 自动切换配色的 HyperOS 3 风格顶部视觉卡片、版本与架构参数、致谢开源项目跳转及 GPL-3.0 许可证弹窗。
 */
@Composable
fun AboutPage(
    scrollBehavior: ScrollBehavior,
    contentPadding: PaddingValues
) {
    val context = LocalContext.current
    val isDark = LocalAppDarkMode.current
    var showLicenseDialog by remember { mutableStateOf(false) }

    fun openExternalUrl(url: String) {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }.onFailure {
            Toast.makeText(context, "无法打开链接：$url", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. OS3 / Mishka 风格顶部视觉横幅卡片（跟随 LocalAppDarkMode）
        item {
            AboutOs3HeroCard(isDark = isDark)
        }

        // 2. 架构与环境信息
        item {
            SettingsSectionHeader(text = "版本与架构")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AboutMetaRow(label = "应用版本", value = "v1.0 (1)")
                    AboutMetaRow(label = "Xposed 接口", value = "libxposed Modern API 102")
                    AboutMetaRow(label = "UI 框架", value = "Miuix KMP v0.9.4 (Jetpack Compose)")
                    AboutMetaRow(label = "运行系统", value = "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
                }
            }
        }

        // 3. 致谢与参考项目（对应 Mishka 的致谢板块）
        item {
            SettingsSectionHeader(text = "致谢与开源组件")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    ArrowPreference(
                        title = "Miuix",
                        summary = "compose-miuix-ui/miuix · Compose Multiplatform UI 组件库",
                        onClick = { openExternalUrl("https://github.com/compose-miuix-ui/miuix") }
                    )
                    ArrowPreference(
                        title = "Mishka",
                        summary = "YuKongA/Mishka · 外观与主题、关于页及导航过渡架构参考",
                        onClick = { openExternalUrl("https://github.com/YuKongA/Mishka") }
                    )
                    ArrowPreference(
                        title = "libxposed",
                        summary = "libxposed/api · 现代 Xposed 模块框架接口标准",
                        onClick = { openExternalUrl("https://github.com/libxposed/api") }
                    )
                }
            }
        }

        // 4. 开源许可证
        item {
            SettingsSectionHeader(text = "许可证")
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    ArrowPreference(
                        title = "开源许可证",
                        summary = "GPL-3.0 License · 遵循 GNU 通用公共许可证第三版开源",
                        onClick = { showLicenseDialog = true }
                    )
                }
            }
        }
    }

    if (showLicenseDialog) {
        OverlayDialog(
            show = true,
            title = "GNU General Public License v3.0",
            summary = "Smillet-Next 开源许可协议声明",
            onDismissRequest = { showLicenseDialog = false }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "本软件基于 GNU General Public License v3.0 (GPL-3.0) 许可证开源发布。\n\n" +
                        "您可以自由地运行、研究、共享和修改本软件，但任何基于本软件分发的衍生版本也必须以相同的 GPL-3.0 许可证开放完整源代码，并保留原始版权与致谢声明。\n\n" +
                        "本软件按「原样」提供，不附带任何明示或暗示的担保。",
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        text = "查看完整协议",
                        onClick = {
                            showLicenseDialog = false
                            openExternalUrl("https://www.gnu.org/licenses/gpl-3.0.html")
                        },
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        text = "关闭",
                        onClick = { showLicenseDialog = false },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary()
                    )
                }
            }
        }
    }
}

@Composable
private fun AboutOs3HeroCard(isDark: Boolean) {
    val bgBrush = if (isDark) {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF1A253A),
                Color(0xFF162C2B),
                Color(0xFF202024)
            ),
            start = Offset(0f, 0f),
            end = Offset(900f, 600f)
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFFEAF2FF),
                Color(0xFFE6FAF5),
                Color(0xFFFFFFFF)
            ),
            start = Offset(0f, 0f),
            end = Offset(900f, 600f)
        )
    }
    val pillBg = if (isDark) Color.White.copy(alpha = 0.10f) else Color(0xFF3482FF).copy(alpha = 0.10f)
    val pillText = if (isDark) Color(0xFF8AB4F8) else Color(0xFF2874F0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(bgBrush)
            .padding(horizontal = 24.dp, vertical = 28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Squircle Emblem
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF3482FF),
                                Color(0xFF169976)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(38.dp)) {
                    val w = size.width
                    val h = size.height
                    val stroke = Stroke(
                        width = 3.0.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                    // Stylized frost/shield pulse icon
                    val path = Path().apply {
                        moveTo(w * 0.50f, h * 0.10f)
                        lineTo(w * 0.86f, h * 0.28f)
                        lineTo(w * 0.86f, h * 0.58f)
                        cubicTo(w * 0.86f, h * 0.78f, w * 0.68f, h * 0.90f, w * 0.50f, h * 0.94f)
                        cubicTo(w * 0.32f, h * 0.90f, w * 0.14f, h * 0.78f, w * 0.14f, h * 0.58f)
                        lineTo(w * 0.14f, h * 0.28f)
                        close()
                    }
                    val check = Path().apply {
                        moveTo(w * 0.34f, h * 0.52f)
                        lineTo(w * 0.46f, h * 0.64f)
                        lineTo(w * 0.68f, h * 0.40f)
                    }
                    drawPath(path, color = Color.White, style = stroke)
                    drawPath(check, color = Color.White, style = stroke)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Smillet-Next",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MiuixTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(pillBg)
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "v1.0 · API 102 · Miuix",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = pillText
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "基于 Miuix 与 HyperOS Greezer 的墓碑冻结及深度 Doze 增强模块",
                fontSize = 13.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AboutMetaRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 15.sp,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary
        )
        Text(
            text = value,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = MiuixTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun BackupActionRow(
    title: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(modifier = Modifier.width(18.dp))
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = MiuixTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        ChevronRightIcon(color = MiuixTheme.colorScheme.onSurfaceVariantSummary)
    }
}

@Composable
private fun IconBackupLayers(color: Color) {
    Canvas(modifier = Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(
            width = 1.95.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        val topLayer = Path().apply {
            moveTo(w * 0.50f, h * 0.14f)
            lineTo(w * 0.12f, h * 0.34f)
            lineTo(w * 0.50f, h * 0.54f)
            lineTo(w * 0.88f, h * 0.34f)
            close()
        }
        val midLayer = Path().apply {
            moveTo(w * 0.12f, h * 0.52f)
            lineTo(w * 0.50f, h * 0.72f)
            lineTo(w * 0.88f, h * 0.52f)
        }
        val botLayer = Path().apply {
            moveTo(w * 0.12f, h * 0.69f)
            lineTo(w * 0.50f, h * 0.89f)
            lineTo(w * 0.88f, h * 0.69f)
        }
        drawPath(topLayer, color = color, style = stroke)
        drawPath(midLayer, color = color, style = stroke)
        drawPath(botLayer, color = color, style = stroke)
    }
}

@Composable
private fun IconRestoreFromFile(color: Color) {
    Canvas(modifier = Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(
            width = 1.95.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        val boxPath = Path().apply {
            moveTo(w * 0.36f, h * 0.28f)
            lineTo(w * 0.36f, h * 0.24f)
            cubicTo(w * 0.36f, h * 0.16f, w * 0.42f, h * 0.12f, w * 0.50f, h * 0.12f)
            lineTo(w * 0.74f, h * 0.12f)
            cubicTo(w * 0.82f, h * 0.12f, w * 0.88f, h * 0.18f, w * 0.88f, h * 0.26f)
            lineTo(w * 0.88f, h * 0.74f)
            cubicTo(w * 0.88f, h * 0.82f, w * 0.82f, h * 0.88f, w * 0.74f, h * 0.88f)
            lineTo(w * 0.50f, h * 0.88f)
            cubicTo(w * 0.42f, h * 0.88f, w * 0.36f, h * 0.84f, w * 0.36f, h * 0.76f)
            lineTo(w * 0.36f, h * 0.72f)
        }
        val arrowPath = Path().apply {
            moveTo(w * 0.12f, h * 0.50f)
            lineTo(w * 0.64f, h * 0.50f)
            moveTo(w * 0.50f, h * 0.35f)
            lineTo(w * 0.65f, h * 0.50f)
            lineTo(w * 0.50f, h * 0.65f)
        }
        drawPath(boxPath, color = color, style = stroke)
        drawPath(arrowPath, color = color, style = stroke)
    }
}

@Composable
private fun ChevronRightIcon(color: Color) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.35f, h * 0.20f)
            lineTo(w * 0.68f, h * 0.50f)
            lineTo(w * 0.35f, h * 0.80f)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 1.8.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
private fun SettingsSectionHeader(text: String) {
    Text(
        text = text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        textAlign = TextAlign.Start,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, top = 6.dp, bottom = 2.dp)
    )
}
