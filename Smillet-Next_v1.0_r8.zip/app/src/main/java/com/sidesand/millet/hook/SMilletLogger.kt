package com.sidesand.millet.hook

import android.util.Log
import com.sidesand.millet.data.ConfigKeys
import com.sidesand.millet.data.MilletConfigSnapshot
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SMilletLogger {
    private const val TAG = "Smillet-Next"
    const val MAX_BUFFER_LINES = 3000
    private const val MAX_FILE_BYTES = 2 * 1024 * 1024L // 2 MB
    private const val ROTATE_KEEP_LINES = 2500
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    private val memoryBuffer = ArrayDeque<String>(MAX_BUFFER_LINES)
    private val canonicalLogRegex = Regex("20\\d{2}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3} \\[(DEBUG|INFO|WARN|ERROR)]")

    @Volatile
    var config: MilletConfigSnapshot = MilletConfigSnapshot()

    /**
     * 用于非 system_server 进程 (如 com.miui.powerkeeper) 将产生的日志实时转发至 system_server 集中存储
     */
    @Volatile
    var externalLogForwarder: ((String) -> Unit)? = null

    fun levelRank(levelStr: String): Int = when (levelStr.lowercase(Locale.ROOT).trim()) {
        "debug" -> 1
        "info" -> 2
        "warn", "warning" -> 3
        "error" -> 4
        else -> 2
    }

    /**
     * 调试日志已统一归入日志等级的 debug 档位
     */
    fun isDebugEnabled(): Boolean = levelRank(config.logLevel) <= 1

    private fun shouldLog(targetRank: Int): Boolean {
        return targetRank >= levelRank(config.logLevel)
    }

    /**
     * 归一化日志行格式，剥离 LSPosed 外部时间戳前缀，避免同一条日志在 IPC 与 Root 渠道重复计数
     */
    fun normalizeLogLine(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        val match = canonicalLogRegex.find(trimmed)
        if (match != null && match.range.first > 0) {
            return trimmed.substring(match.range.first).trim()
        }
        return trimmed
    }

    fun debug(msg: String) {
        if (!shouldLog(1)) return
        write(Log.DEBUG, "DEBUG", msg, null)
    }

    fun info(msg: String) {
        if (!shouldLog(2)) return
        write(Log.INFO, "INFO", msg, null)
    }

    fun warn(msg: String) {
        if (!shouldLog(3)) return
        write(Log.WARN, "WARN", msg, null)
    }

    fun error(msg: String, t: Throwable? = null) {
        if (!shouldLog(4)) return
        val full = if (t != null) "$msg: ${t.message}" else msg
        write(Log.ERROR, "ERROR", full, t)
    }

    fun recordExternalLog(formattedLine: String) {
        val normalized = normalizeLogLine(formattedLine)
        if (normalized.isEmpty()) return
        synchronized(memoryBuffer) {
            if (memoryBuffer.size >= MAX_BUFFER_LINES) {
                memoryBuffer.removeFirst()
            }
            memoryBuffer.addLast(normalized)
        }
        appendToLocalFile(normalized)
    }

    fun getBufferedLogs(): String {
        val fileLines = runCatching {
            val file = File(ConfigKeys.LOCAL_LOG_PATH)
            if (file.exists() && file.canRead()) {
                file.readLines()
                    .map { normalizeLogLine(it) }
                    .filter { it.isNotEmpty() }
                    .takeLast(MAX_BUFFER_LINES)
            } else {
                emptyList()
            }
        }.getOrDefault(emptyList())

        val memLines = synchronized(memoryBuffer) {
            memoryBuffer.toList()
        }

        if (fileLines.isEmpty()) {
            return memLines.joinToString("\n")
        }
        val merged = LinkedHashSet<String>(fileLines.size + memLines.size)
        merged.addAll(fileLines)
        merged.addAll(memLines)
        val sorted = merged.toList().sortedBy { line ->
            if (line.length >= 23 && line.startsWith("20")) line.substring(0, 23) else line
        }
        return sorted.takeLast(MAX_BUFFER_LINES).joinToString("\n")
    }

    fun clearBufferedLogs() {
        synchronized(memoryBuffer) {
            memoryBuffer.clear()
        }
        runCatching {
            val file = File(ConfigKeys.LOCAL_LOG_PATH)
            if (file.exists()) {
                file.writeText("")
            }
        }
    }

    private fun appendToLocalFile(formatted: String) {
        runCatching {
            val file = File(ConfigKeys.LOCAL_LOG_PATH)
            file.parentFile?.mkdirs()
            if (file.exists() && file.length() > MAX_FILE_BYTES) {
                val tail = runCatching { file.readLines().takeLast(ROTATE_KEEP_LINES) }.getOrDefault(emptyList())
                file.writeText(tail.joinToString("\n") + "\n")
            }
            FileWriter(file, true).use { it.appendLine(formatted) }
        }
    }

    private fun write(priority: Int, level: String, msg: String, t: Throwable?) {
        val formatted = "${dateFormat.format(Date())} [$level] [$TAG] $msg"
        synchronized(memoryBuffer) {
            if (memoryBuffer.size >= MAX_BUFFER_LINES) {
                memoryBuffer.removeFirst()
            }
            memoryBuffer.addLast(formatted)
        }
        XposedCompat.log(priority, TAG, formatted, t)
        val forwarder = externalLogForwarder
        if (forwarder != null) {
            runCatching { forwarder.invoke(formatted) }
        } else {
            appendToLocalFile(formatted)
        }
    }
}
